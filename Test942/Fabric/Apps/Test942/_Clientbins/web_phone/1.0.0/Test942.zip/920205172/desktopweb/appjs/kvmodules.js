/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('AsyncTestService/File/MF_Config',[], function() {
    var mappings = {
        "checksum": "checksum",
        "commit_properties": "commit_properties",
        "createdby": "createdby",
        "custom_field1": "custom_field1",
        "custom_field10": "custom_field10",
        "custom_field11": "custom_field11",
        "custom_field12": "custom_field12",
        "custom_field13": "custom_field13",
        "custom_field14": "custom_field14",
        "custom_field15": "custom_field15",
        "custom_field16": "custom_field16",
        "custom_field17": "custom_field17",
        "custom_field18": "custom_field18",
        "custom_field19": "custom_field19",
        "custom_field2": "custom_field2",
        "custom_field20": "custom_field20",
        "custom_field3": "custom_field3",
        "custom_field4": "custom_field4",
        "custom_field5": "custom_field5",
        "custom_field6": "custom_field6",
        "custom_field7": "custom_field7",
        "custom_field8": "custom_field8",
        "custom_field9": "custom_field9",
        "description": "description",
        "download_template": "download_template",
        "file_content": "file_content",
        "file_id": "file_id",
        "file_name": "file_name",
        "file_namespace": "file_namespace",
        "mime_type": "mime_type",
        "modifiedby": "modifiedby",
        "relative_path": "relative_path",
        "security_key": "security_key",
        "size": "size",
        "status": "status",
        "tags": "tags",
        "upload_template": "upload_template",
    };
    Object.freeze(mappings);
    var typings = {
        "checksum": "string",
        "commit_properties": "string",
        "createdby": "string",
        "custom_field1": "string",
        "custom_field10": "string",
        "custom_field11": "string",
        "custom_field12": "string",
        "custom_field13": "string",
        "custom_field14": "string",
        "custom_field15": "string",
        "custom_field16": "string",
        "custom_field17": "string",
        "custom_field18": "string",
        "custom_field19": "string",
        "custom_field2": "string",
        "custom_field20": "string",
        "custom_field3": "string",
        "custom_field4": "string",
        "custom_field5": "string",
        "custom_field6": "string",
        "custom_field7": "string",
        "custom_field8": "string",
        "custom_field9": "string",
        "description": "string",
        "download_template": "string",
        "file_content": "binary",
        "file_id": "string",
        "file_name": "string",
        "file_namespace": "string",
        "mime_type": "string",
        "modifiedby": "string",
        "relative_path": "string",
        "security_key": "string",
        "size": "string",
        "status": "number",
        "tags": "string",
        "upload_template": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["file_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "AsyncTestService",
        tableName: "File"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('AsyncTestService/File/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "File",
        "objectService": "AsyncTestService"
    };
    var setterFunctions = {
        checksum: function(val, state) {
            context["field"] = "checksum";
            context["metadata"] = (objectMetadata ? objectMetadata["checksum"] : null);
            state['checksum'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        commit_properties: function(val, state) {
            context["field"] = "commit_properties";
            context["metadata"] = (objectMetadata ? objectMetadata["commit_properties"] : null);
            state['commit_properties'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        createdby: function(val, state) {
            context["field"] = "createdby";
            context["metadata"] = (objectMetadata ? objectMetadata["createdby"] : null);
            state['createdby'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field1: function(val, state) {
            context["field"] = "custom_field1";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field1"] : null);
            state['custom_field1'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field10: function(val, state) {
            context["field"] = "custom_field10";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field10"] : null);
            state['custom_field10'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field11: function(val, state) {
            context["field"] = "custom_field11";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field11"] : null);
            state['custom_field11'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field12: function(val, state) {
            context["field"] = "custom_field12";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field12"] : null);
            state['custom_field12'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field13: function(val, state) {
            context["field"] = "custom_field13";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field13"] : null);
            state['custom_field13'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field14: function(val, state) {
            context["field"] = "custom_field14";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field14"] : null);
            state['custom_field14'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field15: function(val, state) {
            context["field"] = "custom_field15";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field15"] : null);
            state['custom_field15'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field16: function(val, state) {
            context["field"] = "custom_field16";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field16"] : null);
            state['custom_field16'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field17: function(val, state) {
            context["field"] = "custom_field17";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field17"] : null);
            state['custom_field17'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field18: function(val, state) {
            context["field"] = "custom_field18";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field18"] : null);
            state['custom_field18'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field19: function(val, state) {
            context["field"] = "custom_field19";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field19"] : null);
            state['custom_field19'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field2: function(val, state) {
            context["field"] = "custom_field2";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field2"] : null);
            state['custom_field2'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field20: function(val, state) {
            context["field"] = "custom_field20";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field20"] : null);
            state['custom_field20'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field3: function(val, state) {
            context["field"] = "custom_field3";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field3"] : null);
            state['custom_field3'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field4: function(val, state) {
            context["field"] = "custom_field4";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field4"] : null);
            state['custom_field4'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field5: function(val, state) {
            context["field"] = "custom_field5";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field5"] : null);
            state['custom_field5'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field6: function(val, state) {
            context["field"] = "custom_field6";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field6"] : null);
            state['custom_field6'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field7: function(val, state) {
            context["field"] = "custom_field7";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field7"] : null);
            state['custom_field7'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field8: function(val, state) {
            context["field"] = "custom_field8";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field8"] : null);
            state['custom_field8'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        custom_field9: function(val, state) {
            context["field"] = "custom_field9";
            context["metadata"] = (objectMetadata ? objectMetadata["custom_field9"] : null);
            state['custom_field9'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        description: function(val, state) {
            context["field"] = "description";
            context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
            state['description'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        download_template: function(val, state) {
            context["field"] = "download_template";
            context["metadata"] = (objectMetadata ? objectMetadata["download_template"] : null);
            state['download_template'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        file_content: function(val, state) {
            context["field"] = "file_content";
            context["metadata"] = (objectMetadata ? objectMetadata["file_content"] : null);
            state['file_content'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        file_id: function(val, state) {
            context["field"] = "file_id";
            context["metadata"] = (objectMetadata ? objectMetadata["file_id"] : null);
            state['file_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        file_name: function(val, state) {
            context["field"] = "file_name";
            context["metadata"] = (objectMetadata ? objectMetadata["file_name"] : null);
            state['file_name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        file_namespace: function(val, state) {
            context["field"] = "file_namespace";
            context["metadata"] = (objectMetadata ? objectMetadata["file_namespace"] : null);
            state['file_namespace'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        mime_type: function(val, state) {
            context["field"] = "mime_type";
            context["metadata"] = (objectMetadata ? objectMetadata["mime_type"] : null);
            state['mime_type'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modifiedby: function(val, state) {
            context["field"] = "modifiedby";
            context["metadata"] = (objectMetadata ? objectMetadata["modifiedby"] : null);
            state['modifiedby'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        relative_path: function(val, state) {
            context["field"] = "relative_path";
            context["metadata"] = (objectMetadata ? objectMetadata["relative_path"] : null);
            state['relative_path'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        security_key: function(val, state) {
            context["field"] = "security_key";
            context["metadata"] = (objectMetadata ? objectMetadata["security_key"] : null);
            state['security_key'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        size: function(val, state) {
            context["field"] = "size";
            context["metadata"] = (objectMetadata ? objectMetadata["size"] : null);
            state['size'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        status: function(val, state) {
            context["field"] = "status";
            context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
            state['status'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        tags: function(val, state) {
            context["field"] = "tags";
            context["metadata"] = (objectMetadata ? objectMetadata["tags"] : null);
            state['tags'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        upload_template: function(val, state) {
            context["field"] = "upload_template";
            context["metadata"] = (objectMetadata ? objectMetadata["upload_template"] : null);
            state['upload_template'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function File(defaultValues) {
        var privateState = {};
        context["field"] = "checksum";
        context["metadata"] = (objectMetadata ? objectMetadata["checksum"] : null);
        privateState.checksum = defaultValues ? (defaultValues["checksum"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["checksum"], context) : null) : null;
        context["field"] = "commit_properties";
        context["metadata"] = (objectMetadata ? objectMetadata["commit_properties"] : null);
        privateState.commit_properties = defaultValues ? (defaultValues["commit_properties"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["commit_properties"], context) : null) : null;
        context["field"] = "createdby";
        context["metadata"] = (objectMetadata ? objectMetadata["createdby"] : null);
        privateState.createdby = defaultValues ? (defaultValues["createdby"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["createdby"], context) : null) : null;
        context["field"] = "custom_field1";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field1"] : null);
        privateState.custom_field1 = defaultValues ? (defaultValues["custom_field1"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field1"], context) : null) : null;
        context["field"] = "custom_field10";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field10"] : null);
        privateState.custom_field10 = defaultValues ? (defaultValues["custom_field10"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field10"], context) : null) : null;
        context["field"] = "custom_field11";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field11"] : null);
        privateState.custom_field11 = defaultValues ? (defaultValues["custom_field11"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field11"], context) : null) : null;
        context["field"] = "custom_field12";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field12"] : null);
        privateState.custom_field12 = defaultValues ? (defaultValues["custom_field12"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field12"], context) : null) : null;
        context["field"] = "custom_field13";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field13"] : null);
        privateState.custom_field13 = defaultValues ? (defaultValues["custom_field13"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field13"], context) : null) : null;
        context["field"] = "custom_field14";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field14"] : null);
        privateState.custom_field14 = defaultValues ? (defaultValues["custom_field14"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field14"], context) : null) : null;
        context["field"] = "custom_field15";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field15"] : null);
        privateState.custom_field15 = defaultValues ? (defaultValues["custom_field15"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field15"], context) : null) : null;
        context["field"] = "custom_field16";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field16"] : null);
        privateState.custom_field16 = defaultValues ? (defaultValues["custom_field16"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field16"], context) : null) : null;
        context["field"] = "custom_field17";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field17"] : null);
        privateState.custom_field17 = defaultValues ? (defaultValues["custom_field17"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field17"], context) : null) : null;
        context["field"] = "custom_field18";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field18"] : null);
        privateState.custom_field18 = defaultValues ? (defaultValues["custom_field18"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field18"], context) : null) : null;
        context["field"] = "custom_field19";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field19"] : null);
        privateState.custom_field19 = defaultValues ? (defaultValues["custom_field19"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field19"], context) : null) : null;
        context["field"] = "custom_field2";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field2"] : null);
        privateState.custom_field2 = defaultValues ? (defaultValues["custom_field2"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field2"], context) : null) : null;
        context["field"] = "custom_field20";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field20"] : null);
        privateState.custom_field20 = defaultValues ? (defaultValues["custom_field20"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field20"], context) : null) : null;
        context["field"] = "custom_field3";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field3"] : null);
        privateState.custom_field3 = defaultValues ? (defaultValues["custom_field3"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field3"], context) : null) : null;
        context["field"] = "custom_field4";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field4"] : null);
        privateState.custom_field4 = defaultValues ? (defaultValues["custom_field4"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field4"], context) : null) : null;
        context["field"] = "custom_field5";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field5"] : null);
        privateState.custom_field5 = defaultValues ? (defaultValues["custom_field5"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field5"], context) : null) : null;
        context["field"] = "custom_field6";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field6"] : null);
        privateState.custom_field6 = defaultValues ? (defaultValues["custom_field6"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field6"], context) : null) : null;
        context["field"] = "custom_field7";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field7"] : null);
        privateState.custom_field7 = defaultValues ? (defaultValues["custom_field7"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field7"], context) : null) : null;
        context["field"] = "custom_field8";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field8"] : null);
        privateState.custom_field8 = defaultValues ? (defaultValues["custom_field8"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field8"], context) : null) : null;
        context["field"] = "custom_field9";
        context["metadata"] = (objectMetadata ? objectMetadata["custom_field9"] : null);
        privateState.custom_field9 = defaultValues ? (defaultValues["custom_field9"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["custom_field9"], context) : null) : null;
        context["field"] = "description";
        context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
        privateState.description = defaultValues ? (defaultValues["description"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["description"], context) : null) : null;
        context["field"] = "download_template";
        context["metadata"] = (objectMetadata ? objectMetadata["download_template"] : null);
        privateState.download_template = defaultValues ? (defaultValues["download_template"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["download_template"], context) : null) : null;
        context["field"] = "file_content";
        context["metadata"] = (objectMetadata ? objectMetadata["file_content"] : null);
        privateState.file_content = defaultValues ? (defaultValues["file_content"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["file_content"], context) : null) : null;
        context["field"] = "file_id";
        context["metadata"] = (objectMetadata ? objectMetadata["file_id"] : null);
        privateState.file_id = defaultValues ? (defaultValues["file_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["file_id"], context) : null) : null;
        context["field"] = "file_name";
        context["metadata"] = (objectMetadata ? objectMetadata["file_name"] : null);
        privateState.file_name = defaultValues ? (defaultValues["file_name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["file_name"], context) : null) : null;
        context["field"] = "file_namespace";
        context["metadata"] = (objectMetadata ? objectMetadata["file_namespace"] : null);
        privateState.file_namespace = defaultValues ? (defaultValues["file_namespace"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["file_namespace"], context) : null) : null;
        context["field"] = "mime_type";
        context["metadata"] = (objectMetadata ? objectMetadata["mime_type"] : null);
        privateState.mime_type = defaultValues ? (defaultValues["mime_type"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["mime_type"], context) : null) : null;
        context["field"] = "modifiedby";
        context["metadata"] = (objectMetadata ? objectMetadata["modifiedby"] : null);
        privateState.modifiedby = defaultValues ? (defaultValues["modifiedby"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modifiedby"], context) : null) : null;
        context["field"] = "relative_path";
        context["metadata"] = (objectMetadata ? objectMetadata["relative_path"] : null);
        privateState.relative_path = defaultValues ? (defaultValues["relative_path"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["relative_path"], context) : null) : null;
        context["field"] = "security_key";
        context["metadata"] = (objectMetadata ? objectMetadata["security_key"] : null);
        privateState.security_key = defaultValues ? (defaultValues["security_key"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["security_key"], context) : null) : null;
        context["field"] = "size";
        context["metadata"] = (objectMetadata ? objectMetadata["size"] : null);
        privateState.size = defaultValues ? (defaultValues["size"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["size"], context) : null) : null;
        context["field"] = "status";
        context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
        privateState.status = defaultValues ? (defaultValues["status"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["status"], context) : null) : null;
        context["field"] = "tags";
        context["metadata"] = (objectMetadata ? objectMetadata["tags"] : null);
        privateState.tags = defaultValues ? (defaultValues["tags"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["tags"], context) : null) : null;
        context["field"] = "upload_template";
        context["metadata"] = (objectMetadata ? objectMetadata["upload_template"] : null);
        privateState.upload_template = defaultValues ? (defaultValues["upload_template"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["upload_template"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "checksum": {
                get: function() {
                    context["field"] = "checksum";
                    context["metadata"] = (objectMetadata ? objectMetadata["checksum"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.checksum, context);
                },
                set: function(val) {
                    setterFunctions['checksum'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "commit_properties": {
                get: function() {
                    context["field"] = "commit_properties";
                    context["metadata"] = (objectMetadata ? objectMetadata["commit_properties"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.commit_properties, context);
                },
                set: function(val) {
                    setterFunctions['commit_properties'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "createdby": {
                get: function() {
                    context["field"] = "createdby";
                    context["metadata"] = (objectMetadata ? objectMetadata["createdby"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.createdby, context);
                },
                set: function(val) {
                    setterFunctions['createdby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field1": {
                get: function() {
                    context["field"] = "custom_field1";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field1"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field1, context);
                },
                set: function(val) {
                    setterFunctions['custom_field1'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field10": {
                get: function() {
                    context["field"] = "custom_field10";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field10"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field10, context);
                },
                set: function(val) {
                    setterFunctions['custom_field10'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field11": {
                get: function() {
                    context["field"] = "custom_field11";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field11"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field11, context);
                },
                set: function(val) {
                    setterFunctions['custom_field11'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field12": {
                get: function() {
                    context["field"] = "custom_field12";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field12"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field12, context);
                },
                set: function(val) {
                    setterFunctions['custom_field12'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field13": {
                get: function() {
                    context["field"] = "custom_field13";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field13"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field13, context);
                },
                set: function(val) {
                    setterFunctions['custom_field13'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field14": {
                get: function() {
                    context["field"] = "custom_field14";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field14"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field14, context);
                },
                set: function(val) {
                    setterFunctions['custom_field14'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field15": {
                get: function() {
                    context["field"] = "custom_field15";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field15"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field15, context);
                },
                set: function(val) {
                    setterFunctions['custom_field15'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field16": {
                get: function() {
                    context["field"] = "custom_field16";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field16"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field16, context);
                },
                set: function(val) {
                    setterFunctions['custom_field16'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field17": {
                get: function() {
                    context["field"] = "custom_field17";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field17"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field17, context);
                },
                set: function(val) {
                    setterFunctions['custom_field17'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field18": {
                get: function() {
                    context["field"] = "custom_field18";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field18"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field18, context);
                },
                set: function(val) {
                    setterFunctions['custom_field18'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field19": {
                get: function() {
                    context["field"] = "custom_field19";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field19"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field19, context);
                },
                set: function(val) {
                    setterFunctions['custom_field19'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field2": {
                get: function() {
                    context["field"] = "custom_field2";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field2"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field2, context);
                },
                set: function(val) {
                    setterFunctions['custom_field2'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field20": {
                get: function() {
                    context["field"] = "custom_field20";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field20"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field20, context);
                },
                set: function(val) {
                    setterFunctions['custom_field20'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field3": {
                get: function() {
                    context["field"] = "custom_field3";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field3"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field3, context);
                },
                set: function(val) {
                    setterFunctions['custom_field3'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field4": {
                get: function() {
                    context["field"] = "custom_field4";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field4"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field4, context);
                },
                set: function(val) {
                    setterFunctions['custom_field4'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field5": {
                get: function() {
                    context["field"] = "custom_field5";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field5"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field5, context);
                },
                set: function(val) {
                    setterFunctions['custom_field5'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field6": {
                get: function() {
                    context["field"] = "custom_field6";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field6"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field6, context);
                },
                set: function(val) {
                    setterFunctions['custom_field6'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field7": {
                get: function() {
                    context["field"] = "custom_field7";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field7"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field7, context);
                },
                set: function(val) {
                    setterFunctions['custom_field7'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field8": {
                get: function() {
                    context["field"] = "custom_field8";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field8"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field8, context);
                },
                set: function(val) {
                    setterFunctions['custom_field8'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "custom_field9": {
                get: function() {
                    context["field"] = "custom_field9";
                    context["metadata"] = (objectMetadata ? objectMetadata["custom_field9"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.custom_field9, context);
                },
                set: function(val) {
                    setterFunctions['custom_field9'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "description": {
                get: function() {
                    context["field"] = "description";
                    context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.description, context);
                },
                set: function(val) {
                    setterFunctions['description'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "download_template": {
                get: function() {
                    context["field"] = "download_template";
                    context["metadata"] = (objectMetadata ? objectMetadata["download_template"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.download_template, context);
                },
                set: function(val) {
                    setterFunctions['download_template'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "file_content": {
                get: function() {
                    context["field"] = "file_content";
                    context["metadata"] = (objectMetadata ? objectMetadata["file_content"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.file_content, context);
                },
                set: function(val) {
                    setterFunctions['file_content'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "file_id": {
                get: function() {
                    context["field"] = "file_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["file_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.file_id, context);
                },
                set: function(val) {
                    setterFunctions['file_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "file_name": {
                get: function() {
                    context["field"] = "file_name";
                    context["metadata"] = (objectMetadata ? objectMetadata["file_name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.file_name, context);
                },
                set: function(val) {
                    setterFunctions['file_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "file_namespace": {
                get: function() {
                    context["field"] = "file_namespace";
                    context["metadata"] = (objectMetadata ? objectMetadata["file_namespace"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.file_namespace, context);
                },
                set: function(val) {
                    setterFunctions['file_namespace'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "mime_type": {
                get: function() {
                    context["field"] = "mime_type";
                    context["metadata"] = (objectMetadata ? objectMetadata["mime_type"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.mime_type, context);
                },
                set: function(val) {
                    setterFunctions['mime_type'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modifiedby": {
                get: function() {
                    context["field"] = "modifiedby";
                    context["metadata"] = (objectMetadata ? objectMetadata["modifiedby"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modifiedby, context);
                },
                set: function(val) {
                    setterFunctions['modifiedby'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "relative_path": {
                get: function() {
                    context["field"] = "relative_path";
                    context["metadata"] = (objectMetadata ? objectMetadata["relative_path"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.relative_path, context);
                },
                set: function(val) {
                    setterFunctions['relative_path'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "security_key": {
                get: function() {
                    context["field"] = "security_key";
                    context["metadata"] = (objectMetadata ? objectMetadata["security_key"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.security_key, context);
                },
                set: function(val) {
                    setterFunctions['security_key'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "size": {
                get: function() {
                    context["field"] = "size";
                    context["metadata"] = (objectMetadata ? objectMetadata["size"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.size, context);
                },
                set: function(val) {
                    setterFunctions['size'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "status": {
                get: function() {
                    context["field"] = "status";
                    context["metadata"] = (objectMetadata ? objectMetadata["status"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.status, context);
                },
                set: function(val) {
                    setterFunctions['status'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "tags": {
                get: function() {
                    context["field"] = "tags";
                    context["metadata"] = (objectMetadata ? objectMetadata["tags"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.tags, context);
                },
                set: function(val) {
                    setterFunctions['tags'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "upload_template": {
                get: function() {
                    context["field"] = "upload_template";
                    context["metadata"] = (objectMetadata ? objectMetadata["upload_template"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.upload_template, context);
                },
                set: function(val) {
                    setterFunctions['upload_template'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.checksum = value ? (value["checksum"] ? value["checksum"] : null) : null;
            privateState.commit_properties = value ? (value["commit_properties"] ? value["commit_properties"] : null) : null;
            privateState.createdby = value ? (value["createdby"] ? value["createdby"] : null) : null;
            privateState.custom_field1 = value ? (value["custom_field1"] ? value["custom_field1"] : null) : null;
            privateState.custom_field10 = value ? (value["custom_field10"] ? value["custom_field10"] : null) : null;
            privateState.custom_field11 = value ? (value["custom_field11"] ? value["custom_field11"] : null) : null;
            privateState.custom_field12 = value ? (value["custom_field12"] ? value["custom_field12"] : null) : null;
            privateState.custom_field13 = value ? (value["custom_field13"] ? value["custom_field13"] : null) : null;
            privateState.custom_field14 = value ? (value["custom_field14"] ? value["custom_field14"] : null) : null;
            privateState.custom_field15 = value ? (value["custom_field15"] ? value["custom_field15"] : null) : null;
            privateState.custom_field16 = value ? (value["custom_field16"] ? value["custom_field16"] : null) : null;
            privateState.custom_field17 = value ? (value["custom_field17"] ? value["custom_field17"] : null) : null;
            privateState.custom_field18 = value ? (value["custom_field18"] ? value["custom_field18"] : null) : null;
            privateState.custom_field19 = value ? (value["custom_field19"] ? value["custom_field19"] : null) : null;
            privateState.custom_field2 = value ? (value["custom_field2"] ? value["custom_field2"] : null) : null;
            privateState.custom_field20 = value ? (value["custom_field20"] ? value["custom_field20"] : null) : null;
            privateState.custom_field3 = value ? (value["custom_field3"] ? value["custom_field3"] : null) : null;
            privateState.custom_field4 = value ? (value["custom_field4"] ? value["custom_field4"] : null) : null;
            privateState.custom_field5 = value ? (value["custom_field5"] ? value["custom_field5"] : null) : null;
            privateState.custom_field6 = value ? (value["custom_field6"] ? value["custom_field6"] : null) : null;
            privateState.custom_field7 = value ? (value["custom_field7"] ? value["custom_field7"] : null) : null;
            privateState.custom_field8 = value ? (value["custom_field8"] ? value["custom_field8"] : null) : null;
            privateState.custom_field9 = value ? (value["custom_field9"] ? value["custom_field9"] : null) : null;
            privateState.description = value ? (value["description"] ? value["description"] : null) : null;
            privateState.download_template = value ? (value["download_template"] ? value["download_template"] : null) : null;
            privateState.file_content = value ? (value["file_content"] ? value["file_content"] : null) : null;
            privateState.file_id = value ? (value["file_id"] ? value["file_id"] : null) : null;
            privateState.file_name = value ? (value["file_name"] ? value["file_name"] : null) : null;
            privateState.file_namespace = value ? (value["file_namespace"] ? value["file_namespace"] : null) : null;
            privateState.mime_type = value ? (value["mime_type"] ? value["mime_type"] : null) : null;
            privateState.modifiedby = value ? (value["modifiedby"] ? value["modifiedby"] : null) : null;
            privateState.relative_path = value ? (value["relative_path"] ? value["relative_path"] : null) : null;
            privateState.security_key = value ? (value["security_key"] ? value["security_key"] : null) : null;
            privateState.size = value ? (value["size"] ? value["size"] : null) : null;
            privateState.status = value ? (value["status"] ? value["status"] : null) : null;
            privateState.tags = value ? (value["tags"] ? value["tags"] : null) : null;
            privateState.upload_template = value ? (value["upload_template"] ? value["upload_template"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(File);
    //Create new class level validator object
    BaseModel.Validator.call(File);
    var registerValidatorBackup = File.registerValidator;
    File.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (File.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
        //For Operation 'createBinary' with service id 'createBinaryFile9913'
    File.createBinary = function(params, onCompletion) {
        return File.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinaryFile7856'
    File.getBinary = function(params, onCompletion) {
        return File.customVerb('getBinary', params, onCompletion);
    };
    var relations = [];
    File.relations = relations;
    File.prototype.isValid = function() {
        return File.isValid(this);
    };
    File.prototype.objModelName = "File";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    File.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("AsyncTestService", "File", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    File.clone = function(objectToClone) {
        var clonedObj = new File();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return File;
});

define('AsyncTestService/File/Repository',[], function() {
    var BaseRepository = kony.mvc.Data.BaseRepository;
    //Create the Repository Class
    function FileRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
        BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
    };
    //Setting BaseRepository as Parent to this Repository
    FileRepository.prototype = Object.create(BaseRepository.prototype);
    FileRepository.prototype.constructor = FileRepository;
    //For Operation 'createBinary' with service id 'createBinaryFile9913'
    FileRepository.prototype.createBinary = function(params, onCompletion) {
        return FileRepository.prototype.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinaryFile7856'
    FileRepository.prototype.getBinary = function(params, onCompletion) {
        return FileRepository.prototype.customVerb('getBinary', params, onCompletion);
    };
    return FileRepository;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('BooleanConversionService/designations/MF_Config',[], function() {
    var mappings = {
        "designation": "designation",
        "early_promotion": "early_promotion",
        "employee_id": "employee_id",
        "from_date": "from_date",
        "lastupdatetimestamp": "lastupdatetimestamp",
        "meets_expectation": "meets_expectation",
        "softdeleteflag": "softdeleteflag",
        "to_date": "to_date",
    };
    Object.freeze(mappings);
    var typings = {
        "designation": "string",
        "early_promotion": "boolean",
        "employee_id": "number",
        "from_date": "date",
        "lastupdatetimestamp": "date",
        "meets_expectation": "boolean",
        "softdeleteflag": "boolean",
        "to_date": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["employee_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "BooleanConversionService",
        tableName: "designations"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('BooleanConversionService/designations/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "designations",
        "objectService": "BooleanConversionService"
    };
    var setterFunctions = {
        designation: function(val, state) {
            context["field"] = "designation";
            context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
            state['designation'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        early_promotion: function(val, state) {
            context["field"] = "early_promotion";
            context["metadata"] = (objectMetadata ? objectMetadata["early_promotion"] : null);
            state['early_promotion'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        employee_id: function(val, state) {
            context["field"] = "employee_id";
            context["metadata"] = (objectMetadata ? objectMetadata["employee_id"] : null);
            state['employee_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        from_date: function(val, state) {
            context["field"] = "from_date";
            context["metadata"] = (objectMetadata ? objectMetadata["from_date"] : null);
            state['from_date'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        lastupdatetimestamp: function(val, state) {
            context["field"] = "lastupdatetimestamp";
            context["metadata"] = (objectMetadata ? objectMetadata["lastupdatetimestamp"] : null);
            state['lastupdatetimestamp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        meets_expectation: function(val, state) {
            context["field"] = "meets_expectation";
            context["metadata"] = (objectMetadata ? objectMetadata["meets_expectation"] : null);
            state['meets_expectation'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        softdeleteflag: function(val, state) {
            context["field"] = "softdeleteflag";
            context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
            state['softdeleteflag'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        to_date: function(val, state) {
            context["field"] = "to_date";
            context["metadata"] = (objectMetadata ? objectMetadata["to_date"] : null);
            state['to_date'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function designations(defaultValues) {
        var privateState = {};
        context["field"] = "designation";
        context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
        privateState.designation = defaultValues ? (defaultValues["designation"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["designation"], context) : null) : null;
        context["field"] = "early_promotion";
        context["metadata"] = (objectMetadata ? objectMetadata["early_promotion"] : null);
        privateState.early_promotion = defaultValues ? (defaultValues["early_promotion"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["early_promotion"], context) : null) : null;
        context["field"] = "employee_id";
        context["metadata"] = (objectMetadata ? objectMetadata["employee_id"] : null);
        privateState.employee_id = defaultValues ? (defaultValues["employee_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["employee_id"], context) : null) : null;
        context["field"] = "from_date";
        context["metadata"] = (objectMetadata ? objectMetadata["from_date"] : null);
        privateState.from_date = defaultValues ? (defaultValues["from_date"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["from_date"], context) : null) : null;
        context["field"] = "lastupdatetimestamp";
        context["metadata"] = (objectMetadata ? objectMetadata["lastupdatetimestamp"] : null);
        privateState.lastupdatetimestamp = defaultValues ? (defaultValues["lastupdatetimestamp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["lastupdatetimestamp"], context) : null) : null;
        context["field"] = "meets_expectation";
        context["metadata"] = (objectMetadata ? objectMetadata["meets_expectation"] : null);
        privateState.meets_expectation = defaultValues ? (defaultValues["meets_expectation"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["meets_expectation"], context) : null) : null;
        context["field"] = "softdeleteflag";
        context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["softdeleteflag"], context) : null) : null;
        context["field"] = "to_date";
        context["metadata"] = (objectMetadata ? objectMetadata["to_date"] : null);
        privateState.to_date = defaultValues ? (defaultValues["to_date"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["to_date"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "designation": {
                get: function() {
                    context["field"] = "designation";
                    context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.designation, context);
                },
                set: function(val) {
                    setterFunctions['designation'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "early_promotion": {
                get: function() {
                    context["field"] = "early_promotion";
                    context["metadata"] = (objectMetadata ? objectMetadata["early_promotion"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.early_promotion, context);
                },
                set: function(val) {
                    setterFunctions['early_promotion'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "employee_id": {
                get: function() {
                    context["field"] = "employee_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["employee_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.employee_id, context);
                },
                set: function(val) {
                    setterFunctions['employee_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "from_date": {
                get: function() {
                    context["field"] = "from_date";
                    context["metadata"] = (objectMetadata ? objectMetadata["from_date"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.from_date, context);
                },
                set: function(val) {
                    setterFunctions['from_date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatetimestamp": {
                get: function() {
                    context["field"] = "lastupdatetimestamp";
                    context["metadata"] = (objectMetadata ? objectMetadata["lastupdatetimestamp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.lastupdatetimestamp, context);
                },
                set: function(val) {
                    setterFunctions['lastupdatetimestamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "meets_expectation": {
                get: function() {
                    context["field"] = "meets_expectation";
                    context["metadata"] = (objectMetadata ? objectMetadata["meets_expectation"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.meets_expectation, context);
                },
                set: function(val) {
                    setterFunctions['meets_expectation'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    context["field"] = "softdeleteflag";
                    context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.softdeleteflag, context);
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "to_date": {
                get: function() {
                    context["field"] = "to_date";
                    context["metadata"] = (objectMetadata ? objectMetadata["to_date"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.to_date, context);
                },
                set: function(val) {
                    setterFunctions['to_date'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.designation = value ? (value["designation"] ? value["designation"] : null) : null;
            privateState.early_promotion = value ? (value["early_promotion"] ? value["early_promotion"] : null) : null;
            privateState.employee_id = value ? (value["employee_id"] ? value["employee_id"] : null) : null;
            privateState.from_date = value ? (value["from_date"] ? value["from_date"] : null) : null;
            privateState.lastupdatetimestamp = value ? (value["lastupdatetimestamp"] ? value["lastupdatetimestamp"] : null) : null;
            privateState.meets_expectation = value ? (value["meets_expectation"] ? value["meets_expectation"] : null) : null;
            privateState.softdeleteflag = value ? (value["softdeleteflag"] ? value["softdeleteflag"] : null) : null;
            privateState.to_date = value ? (value["to_date"] ? value["to_date"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(designations);
    //Create new class level validator object
    BaseModel.Validator.call(designations);
    var registerValidatorBackup = designations.registerValidator;
    designations.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (designations.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    designations.relations = relations;
    designations.prototype.isValid = function() {
        return designations.isValid(this);
    };
    designations.prototype.objModelName = "designations";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    designations.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("BooleanConversionService", "designations", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    designations.clone = function(objectToClone) {
        var clonedObj = new designations();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return designations;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('BooleanConversionService/employees/MF_Config',[], function() {
    var mappings = {
        "employee_id": "employee_id",
        "employee_name": "employee_name",
        "lastupdatetimestamp": "lastupdatetimestamp",
        "married": "married",
        "permanent": "permanent",
        "softdeleteflag": "softdeleteflag",
    };
    Object.freeze(mappings);
    var typings = {
        "employee_id": "number",
        "employee_name": "string",
        "lastupdatetimestamp": "date",
        "married": "boolean",
        "permanent": "boolean",
        "softdeleteflag": "boolean",
    }
    Object.freeze(typings);
    var primaryKeys = ["employee_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "BooleanConversionService",
        tableName: "employees"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('BooleanConversionService/employees/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "employees",
        "objectService": "BooleanConversionService"
    };
    var setterFunctions = {
        employee_id: function(val, state) {
            context["field"] = "employee_id";
            context["metadata"] = (objectMetadata ? objectMetadata["employee_id"] : null);
            state['employee_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        employee_name: function(val, state) {
            context["field"] = "employee_name";
            context["metadata"] = (objectMetadata ? objectMetadata["employee_name"] : null);
            state['employee_name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        lastupdatetimestamp: function(val, state) {
            context["field"] = "lastupdatetimestamp";
            context["metadata"] = (objectMetadata ? objectMetadata["lastupdatetimestamp"] : null);
            state['lastupdatetimestamp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        married: function(val, state) {
            context["field"] = "married";
            context["metadata"] = (objectMetadata ? objectMetadata["married"] : null);
            state['married'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        permanent: function(val, state) {
            context["field"] = "permanent";
            context["metadata"] = (objectMetadata ? objectMetadata["permanent"] : null);
            state['permanent'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        softdeleteflag: function(val, state) {
            context["field"] = "softdeleteflag";
            context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
            state['softdeleteflag'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function employees(defaultValues) {
        var privateState = {};
        context["field"] = "employee_id";
        context["metadata"] = (objectMetadata ? objectMetadata["employee_id"] : null);
        privateState.employee_id = defaultValues ? (defaultValues["employee_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["employee_id"], context) : null) : null;
        context["field"] = "employee_name";
        context["metadata"] = (objectMetadata ? objectMetadata["employee_name"] : null);
        privateState.employee_name = defaultValues ? (defaultValues["employee_name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["employee_name"], context) : null) : null;
        context["field"] = "lastupdatetimestamp";
        context["metadata"] = (objectMetadata ? objectMetadata["lastupdatetimestamp"] : null);
        privateState.lastupdatetimestamp = defaultValues ? (defaultValues["lastupdatetimestamp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["lastupdatetimestamp"], context) : null) : null;
        context["field"] = "married";
        context["metadata"] = (objectMetadata ? objectMetadata["married"] : null);
        privateState.married = defaultValues ? (defaultValues["married"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["married"], context) : null) : null;
        context["field"] = "permanent";
        context["metadata"] = (objectMetadata ? objectMetadata["permanent"] : null);
        privateState.permanent = defaultValues ? (defaultValues["permanent"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["permanent"], context) : null) : null;
        context["field"] = "softdeleteflag";
        context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["softdeleteflag"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "employee_id": {
                get: function() {
                    context["field"] = "employee_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["employee_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.employee_id, context);
                },
                set: function(val) {
                    setterFunctions['employee_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "employee_name": {
                get: function() {
                    context["field"] = "employee_name";
                    context["metadata"] = (objectMetadata ? objectMetadata["employee_name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.employee_name, context);
                },
                set: function(val) {
                    setterFunctions['employee_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "lastupdatetimestamp": {
                get: function() {
                    context["field"] = "lastupdatetimestamp";
                    context["metadata"] = (objectMetadata ? objectMetadata["lastupdatetimestamp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.lastupdatetimestamp, context);
                },
                set: function(val) {
                    setterFunctions['lastupdatetimestamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "married": {
                get: function() {
                    context["field"] = "married";
                    context["metadata"] = (objectMetadata ? objectMetadata["married"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.married, context);
                },
                set: function(val) {
                    setterFunctions['married'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "permanent": {
                get: function() {
                    context["field"] = "permanent";
                    context["metadata"] = (objectMetadata ? objectMetadata["permanent"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.permanent, context);
                },
                set: function(val) {
                    setterFunctions['permanent'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    context["field"] = "softdeleteflag";
                    context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.softdeleteflag, context);
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.employee_id = value ? (value["employee_id"] ? value["employee_id"] : null) : null;
            privateState.employee_name = value ? (value["employee_name"] ? value["employee_name"] : null) : null;
            privateState.lastupdatetimestamp = value ? (value["lastupdatetimestamp"] ? value["lastupdatetimestamp"] : null) : null;
            privateState.married = value ? (value["married"] ? value["married"] : null) : null;
            privateState.permanent = value ? (value["permanent"] ? value["permanent"] : null) : null;
            privateState.softdeleteflag = value ? (value["softdeleteflag"] ? value["softdeleteflag"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(employees);
    //Create new class level validator object
    BaseModel.Validator.call(employees);
    var registerValidatorBackup = employees.registerValidator;
    employees.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (employees.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    employees.relations = relations;
    employees.prototype.isValid = function() {
        return employees.isValid(this);
    };
    employees.prototype.objModelName = "employees";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    employees.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("BooleanConversionService", "employees", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    employees.clone = function(objectToClone) {
        var clonedObj = new employees();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return employees;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('ContactOS/binaryContact/MF_Config',[], function() {
    var mappings = {
        "contactPic": "contactPic",
        "contact_id": "contact_id",
        "designation": "designation",
        "event_id": "event_id",
        "is_disabled": "is_disabled",
        "modifiedDate": "modifiedDate",
        "name": "name",
    };
    Object.freeze(mappings);
    var typings = {
        "contactPic": "binary",
        "contact_id": "number",
        "designation": "string",
        "event_id": "number",
        "is_disabled": "boolean",
        "modifiedDate": "date",
        "name": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["contact_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "ContactOS",
        tableName: "binaryContact"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('ContactOS/binaryContact/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "binaryContact",
        "objectService": "ContactOS"
    };
    var setterFunctions = {
        contactPic: function(val, state) {
            context["field"] = "contactPic";
            context["metadata"] = (objectMetadata ? objectMetadata["contactPic"] : null);
            state['contactPic'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        contact_id: function(val, state) {
            context["field"] = "contact_id";
            context["metadata"] = (objectMetadata ? objectMetadata["contact_id"] : null);
            state['contact_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        designation: function(val, state) {
            context["field"] = "designation";
            context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
            state['designation'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        event_id: function(val, state) {
            context["field"] = "event_id";
            context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
            state['event_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modifiedDate: function(val, state) {
            context["field"] = "modifiedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
            state['modifiedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        name: function(val, state) {
            context["field"] = "name";
            context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
            state['name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function binaryContact(defaultValues) {
        var privateState = {};
        context["field"] = "contactPic";
        context["metadata"] = (objectMetadata ? objectMetadata["contactPic"] : null);
        privateState.contactPic = defaultValues ? (defaultValues["contactPic"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["contactPic"], context) : null) : null;
        context["field"] = "contact_id";
        context["metadata"] = (objectMetadata ? objectMetadata["contact_id"] : null);
        privateState.contact_id = defaultValues ? (defaultValues["contact_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["contact_id"], context) : null) : null;
        context["field"] = "designation";
        context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
        privateState.designation = defaultValues ? (defaultValues["designation"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["designation"], context) : null) : null;
        context["field"] = "event_id";
        context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
        privateState.event_id = defaultValues ? (defaultValues["event_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["event_id"], context) : null) : null;
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "modifiedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
        privateState.modifiedDate = defaultValues ? (defaultValues["modifiedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modifiedDate"], context) : null) : null;
        context["field"] = "name";
        context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
        privateState.name = defaultValues ? (defaultValues["name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["name"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "contactPic": {
                get: function() {
                    context["field"] = "contactPic";
                    context["metadata"] = (objectMetadata ? objectMetadata["contactPic"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.contactPic, context);
                },
                set: function(val) {
                    setterFunctions['contactPic'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "contact_id": {
                get: function() {
                    context["field"] = "contact_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["contact_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.contact_id, context);
                },
                set: function(val) {
                    setterFunctions['contact_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "designation": {
                get: function() {
                    context["field"] = "designation";
                    context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.designation, context);
                },
                set: function(val) {
                    setterFunctions['designation'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "event_id": {
                get: function() {
                    context["field"] = "event_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.event_id, context);
                },
                set: function(val) {
                    setterFunctions['event_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modifiedDate": {
                get: function() {
                    context["field"] = "modifiedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modifiedDate, context);
                },
                set: function(val) {
                    setterFunctions['modifiedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "name": {
                get: function() {
                    context["field"] = "name";
                    context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.name, context);
                },
                set: function(val) {
                    setterFunctions['name'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.contactPic = value ? (value["contactPic"] ? value["contactPic"] : null) : null;
            privateState.contact_id = value ? (value["contact_id"] ? value["contact_id"] : null) : null;
            privateState.designation = value ? (value["designation"] ? value["designation"] : null) : null;
            privateState.event_id = value ? (value["event_id"] ? value["event_id"] : null) : null;
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.modifiedDate = value ? (value["modifiedDate"] ? value["modifiedDate"] : null) : null;
            privateState.name = value ? (value["name"] ? value["name"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(binaryContact);
    //Create new class level validator object
    BaseModel.Validator.call(binaryContact);
    var registerValidatorBackup = binaryContact.registerValidator;
    binaryContact.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (binaryContact.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
        //For Operation 'createBinary' with service id 'createBinarybinaryContact8002'
    binaryContact.createBinary = function(params, onCompletion) {
        return binaryContact.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinarybinaryContact1414'
    binaryContact.getBinary = function(params, onCompletion) {
        return binaryContact.customVerb('getBinary', params, onCompletion);
    };
    //For Operation 'updateBinary' with service id 'updateBinarybinaryContact2335'
    binaryContact.updateBinary = function(params, onCompletion) {
        return binaryContact.customVerb('updateBinary', params, onCompletion);
    };
    //For Operation 'deleteBinary' with service id 'deleteBinarybinaryContact8480'
    binaryContact.deleteBinary = function(params, onCompletion) {
        return binaryContact.customVerb('deleteBinary', params, onCompletion);
    };
    var relations = [];
    binaryContact.relations = relations;
    binaryContact.prototype.isValid = function() {
        return binaryContact.isValid(this);
    };
    binaryContact.prototype.objModelName = "binaryContact";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    binaryContact.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("ContactOS", "binaryContact", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    binaryContact.clone = function(objectToClone) {
        var clonedObj = new binaryContact();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return binaryContact;
});

define('ContactOS/binaryContact/Repository',[], function() {
    var BaseRepository = kony.mvc.Data.BaseRepository;
    //Create the Repository Class
    function binaryContactRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
        BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
    };
    //Setting BaseRepository as Parent to this Repository
    binaryContactRepository.prototype = Object.create(BaseRepository.prototype);
    binaryContactRepository.prototype.constructor = binaryContactRepository;
    //For Operation 'createBinary' with service id 'createBinarybinaryContact8002'
    binaryContactRepository.prototype.createBinary = function(params, onCompletion) {
        return binaryContactRepository.prototype.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinarybinaryContact1414'
    binaryContactRepository.prototype.getBinary = function(params, onCompletion) {
        return binaryContactRepository.prototype.customVerb('getBinary', params, onCompletion);
    };
    //For Operation 'updateBinary' with service id 'updateBinarybinaryContact2335'
    binaryContactRepository.prototype.updateBinary = function(params, onCompletion) {
        return binaryContactRepository.prototype.customVerb('updateBinary', params, onCompletion);
    };
    //For Operation 'deleteBinary' with service id 'deleteBinarybinaryContact8480'
    binaryContactRepository.prototype.deleteBinary = function(params, onCompletion) {
        return binaryContactRepository.prototype.customVerb('deleteBinary', params, onCompletion);
    };
    return binaryContactRepository;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('ContactOS/contact/MF_Config',[], function() {
    var mappings = {
        "contact_id": "contact_id",
        "designation": "designation",
        "event_id": "event_id",
        "is_disabled": "is_disabled",
        "modifiedDate": "modifiedDate",
        "name": "name",
    };
    Object.freeze(mappings);
    var typings = {
        "contact_id": "number",
        "designation": "string",
        "event_id": "number",
        "is_disabled": "boolean",
        "modifiedDate": "date",
        "name": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["contact_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "ContactOS",
        tableName: "contact"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('ContactOS/contact/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "contact",
        "objectService": "ContactOS"
    };
    var setterFunctions = {
        contact_id: function(val, state) {
            context["field"] = "contact_id";
            context["metadata"] = (objectMetadata ? objectMetadata["contact_id"] : null);
            state['contact_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        designation: function(val, state) {
            context["field"] = "designation";
            context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
            state['designation'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        event_id: function(val, state) {
            context["field"] = "event_id";
            context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
            state['event_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modifiedDate: function(val, state) {
            context["field"] = "modifiedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
            state['modifiedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        name: function(val, state) {
            context["field"] = "name";
            context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
            state['name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function contact(defaultValues) {
        var privateState = {};
        context["field"] = "contact_id";
        context["metadata"] = (objectMetadata ? objectMetadata["contact_id"] : null);
        privateState.contact_id = defaultValues ? (defaultValues["contact_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["contact_id"], context) : null) : null;
        context["field"] = "designation";
        context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
        privateState.designation = defaultValues ? (defaultValues["designation"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["designation"], context) : null) : null;
        context["field"] = "event_id";
        context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
        privateState.event_id = defaultValues ? (defaultValues["event_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["event_id"], context) : null) : null;
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "modifiedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
        privateState.modifiedDate = defaultValues ? (defaultValues["modifiedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modifiedDate"], context) : null) : null;
        context["field"] = "name";
        context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
        privateState.name = defaultValues ? (defaultValues["name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["name"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "contact_id": {
                get: function() {
                    context["field"] = "contact_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["contact_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.contact_id, context);
                },
                set: function(val) {
                    setterFunctions['contact_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "designation": {
                get: function() {
                    context["field"] = "designation";
                    context["metadata"] = (objectMetadata ? objectMetadata["designation"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.designation, context);
                },
                set: function(val) {
                    setterFunctions['designation'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "event_id": {
                get: function() {
                    context["field"] = "event_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.event_id, context);
                },
                set: function(val) {
                    setterFunctions['event_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modifiedDate": {
                get: function() {
                    context["field"] = "modifiedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modifiedDate, context);
                },
                set: function(val) {
                    setterFunctions['modifiedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "name": {
                get: function() {
                    context["field"] = "name";
                    context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.name, context);
                },
                set: function(val) {
                    setterFunctions['name'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.contact_id = value ? (value["contact_id"] ? value["contact_id"] : null) : null;
            privateState.designation = value ? (value["designation"] ? value["designation"] : null) : null;
            privateState.event_id = value ? (value["event_id"] ? value["event_id"] : null) : null;
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.modifiedDate = value ? (value["modifiedDate"] ? value["modifiedDate"] : null) : null;
            privateState.name = value ? (value["name"] ? value["name"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(contact);
    //Create new class level validator object
    BaseModel.Validator.call(contact);
    var registerValidatorBackup = contact.registerValidator;
    contact.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (contact.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    contact.relations = relations;
    contact.prototype.isValid = function() {
        return contact.isValid(this);
    };
    contact.prototype.objModelName = "contact";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    contact.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("ContactOS", "contact", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    contact.clone = function(objectToClone) {
        var clonedObj = new contact();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return contact;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/event/MF_Config',[], function() {
    var mappings = {
        "addedDateTime": "addedDateTime",
        "title": "title",
        "end_date": "end_date",
        "event_id": "event_id",
        "is_disabled": "is_disabled",
        "long_desc": "long_desc",
        "start_date": "start_date",
        "venue_id": "venue_id",
    };
    Object.freeze(mappings);
    var typings = {
        "addedDateTime": "date",
        "title": "string",
        "end_date": "date",
        "event_id": "number",
        "is_disabled": "boolean",
        "long_desc": "string",
        "start_date": "date",
        "venue_id": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["event_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "EventOS",
        tableName: "event"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/event/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "event",
        "objectService": "EventOS"
    };
    var setterFunctions = {
        addedDateTime: function(val, state) {
            context["field"] = "addedDateTime";
            context["metadata"] = (objectMetadata ? objectMetadata["addedDateTime"] : null);
            state['addedDateTime'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        title: function(val, state) {
            context["field"] = "title";
            context["metadata"] = (objectMetadata ? objectMetadata["title"] : null);
            state['title'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        end_date: function(val, state) {
            context["field"] = "end_date";
            context["metadata"] = (objectMetadata ? objectMetadata["end_date"] : null);
            state['end_date'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        event_id: function(val, state) {
            context["field"] = "event_id";
            context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
            state['event_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        long_desc: function(val, state) {
            context["field"] = "long_desc";
            context["metadata"] = (objectMetadata ? objectMetadata["long_desc"] : null);
            state['long_desc'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        start_date: function(val, state) {
            context["field"] = "start_date";
            context["metadata"] = (objectMetadata ? objectMetadata["start_date"] : null);
            state['start_date'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        venue_id: function(val, state) {
            context["field"] = "venue_id";
            context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
            state['venue_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function event(defaultValues) {
        var privateState = {};
        context["field"] = "addedDateTime";
        context["metadata"] = (objectMetadata ? objectMetadata["addedDateTime"] : null);
        privateState.addedDateTime = defaultValues ? (defaultValues["addedDateTime"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["addedDateTime"], context) : null) : null;
        context["field"] = "title";
        context["metadata"] = (objectMetadata ? objectMetadata["title"] : null);
        privateState.title = defaultValues ? (defaultValues["title"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["title"], context) : null) : null;
        context["field"] = "end_date";
        context["metadata"] = (objectMetadata ? objectMetadata["end_date"] : null);
        privateState.end_date = defaultValues ? (defaultValues["end_date"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["end_date"], context) : null) : null;
        context["field"] = "event_id";
        context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
        privateState.event_id = defaultValues ? (defaultValues["event_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["event_id"], context) : null) : null;
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "long_desc";
        context["metadata"] = (objectMetadata ? objectMetadata["long_desc"] : null);
        privateState.long_desc = defaultValues ? (defaultValues["long_desc"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["long_desc"], context) : null) : null;
        context["field"] = "start_date";
        context["metadata"] = (objectMetadata ? objectMetadata["start_date"] : null);
        privateState.start_date = defaultValues ? (defaultValues["start_date"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["start_date"], context) : null) : null;
        context["field"] = "venue_id";
        context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
        privateState.venue_id = defaultValues ? (defaultValues["venue_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["venue_id"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "addedDateTime": {
                get: function() {
                    context["field"] = "addedDateTime";
                    context["metadata"] = (objectMetadata ? objectMetadata["addedDateTime"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.addedDateTime, context);
                },
                set: function(val) {
                    setterFunctions['addedDateTime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "title": {
                get: function() {
                    context["field"] = "title";
                    context["metadata"] = (objectMetadata ? objectMetadata["title"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.title, context);
                },
                set: function(val) {
                    setterFunctions['title'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "end_date": {
                get: function() {
                    context["field"] = "end_date";
                    context["metadata"] = (objectMetadata ? objectMetadata["end_date"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.end_date, context);
                },
                set: function(val) {
                    setterFunctions['end_date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "event_id": {
                get: function() {
                    context["field"] = "event_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.event_id, context);
                },
                set: function(val) {
                    setterFunctions['event_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "long_desc": {
                get: function() {
                    context["field"] = "long_desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["long_desc"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.long_desc, context);
                },
                set: function(val) {
                    setterFunctions['long_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "start_date": {
                get: function() {
                    context["field"] = "start_date";
                    context["metadata"] = (objectMetadata ? objectMetadata["start_date"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.start_date, context);
                },
                set: function(val) {
                    setterFunctions['start_date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "venue_id": {
                get: function() {
                    context["field"] = "venue_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.venue_id, context);
                },
                set: function(val) {
                    setterFunctions['venue_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.addedDateTime = value ? (value["addedDateTime"] ? value["addedDateTime"] : null) : null;
            privateState.title = value ? (value["title"] ? value["title"] : null) : null;
            privateState.end_date = value ? (value["end_date"] ? value["end_date"] : null) : null;
            privateState.event_id = value ? (value["event_id"] ? value["event_id"] : null) : null;
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.long_desc = value ? (value["long_desc"] ? value["long_desc"] : null) : null;
            privateState.start_date = value ? (value["start_date"] ? value["start_date"] : null) : null;
            privateState.venue_id = value ? (value["venue_id"] ? value["venue_id"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(event);
    //Create new class level validator object
    BaseModel.Validator.call(event);
    var registerValidatorBackup = event.registerValidator;
    event.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (event.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    event.relations = relations;
    event.prototype.isValid = function() {
        return event.isValid(this);
    };
    event.prototype.objModelName = "event";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    event.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("EventOS", "event", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    event.clone = function(objectToClone) {
        var clonedObj = new event();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return event;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/event_speaker/MF_Config',[], function() {
    var mappings = {
        "event_id": "event_id",
        "is_disabled": "is_disabled",
        "modified_time": "modified_time",
        "session_speaker_id": "session_speaker_id",
        "speaker_id": "speaker_id",
    };
    Object.freeze(mappings);
    var typings = {
        "event_id": "number",
        "is_disabled": "boolean",
        "modified_time": "date",
        "session_speaker_id": "number",
        "speaker_id": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["event_id", "speaker_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "EventOS",
        tableName: "event_speaker"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/event_speaker/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "event_speaker",
        "objectService": "EventOS"
    };
    var setterFunctions = {
        event_id: function(val, state) {
            context["field"] = "event_id";
            context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
            state['event_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modified_time: function(val, state) {
            context["field"] = "modified_time";
            context["metadata"] = (objectMetadata ? objectMetadata["modified_time"] : null);
            state['modified_time'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        session_speaker_id: function(val, state) {
            context["field"] = "session_speaker_id";
            context["metadata"] = (objectMetadata ? objectMetadata["session_speaker_id"] : null);
            state['session_speaker_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        speaker_id: function(val, state) {
            context["field"] = "speaker_id";
            context["metadata"] = (objectMetadata ? objectMetadata["speaker_id"] : null);
            state['speaker_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function event_speaker(defaultValues) {
        var privateState = {};
        context["field"] = "event_id";
        context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
        privateState.event_id = defaultValues ? (defaultValues["event_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["event_id"], context) : null) : null;
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "modified_time";
        context["metadata"] = (objectMetadata ? objectMetadata["modified_time"] : null);
        privateState.modified_time = defaultValues ? (defaultValues["modified_time"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modified_time"], context) : null) : null;
        context["field"] = "session_speaker_id";
        context["metadata"] = (objectMetadata ? objectMetadata["session_speaker_id"] : null);
        privateState.session_speaker_id = defaultValues ? (defaultValues["session_speaker_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["session_speaker_id"], context) : null) : null;
        context["field"] = "speaker_id";
        context["metadata"] = (objectMetadata ? objectMetadata["speaker_id"] : null);
        privateState.speaker_id = defaultValues ? (defaultValues["speaker_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["speaker_id"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "event_id": {
                get: function() {
                    context["field"] = "event_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.event_id, context);
                },
                set: function(val) {
                    setterFunctions['event_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modified_time": {
                get: function() {
                    context["field"] = "modified_time";
                    context["metadata"] = (objectMetadata ? objectMetadata["modified_time"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modified_time, context);
                },
                set: function(val) {
                    setterFunctions['modified_time'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "session_speaker_id": {
                get: function() {
                    context["field"] = "session_speaker_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["session_speaker_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.session_speaker_id, context);
                },
                set: function(val) {
                    setterFunctions['session_speaker_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "speaker_id": {
                get: function() {
                    context["field"] = "speaker_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["speaker_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.speaker_id, context);
                },
                set: function(val) {
                    setterFunctions['speaker_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.event_id = value ? (value["event_id"] ? value["event_id"] : null) : null;
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.modified_time = value ? (value["modified_time"] ? value["modified_time"] : null) : null;
            privateState.session_speaker_id = value ? (value["session_speaker_id"] ? value["session_speaker_id"] : null) : null;
            privateState.speaker_id = value ? (value["speaker_id"] ? value["speaker_id"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(event_speaker);
    //Create new class level validator object
    BaseModel.Validator.call(event_speaker);
    var registerValidatorBackup = event_speaker.registerValidator;
    event_speaker.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (event_speaker.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    event_speaker.relations = relations;
    event_speaker.prototype.isValid = function() {
        return event_speaker.isValid(this);
    };
    event_speaker.prototype.objModelName = "event_speaker";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    event_speaker.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("EventOS", "event_speaker", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    event_speaker.clone = function(objectToClone) {
        var clonedObj = new event_speaker();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return event_speaker;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/speaker/MF_Config',[], function() {
    var mappings = {
        "is_disabled": "is_disabled",
        "modified_time": "modified_time",
        "rating_id": "rating_id",
        "speaker_details": "speaker_details",
        "speaker_id": "speaker_id",
        "speaker_name": "speaker_name",
    };
    Object.freeze(mappings);
    var typings = {
        "is_disabled": "boolean",
        "modified_time": "date",
        "rating_id": "number",
        "speaker_details": "string",
        "speaker_id": "number",
        "speaker_name": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["speaker_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "EventOS",
        tableName: "speaker"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/speaker/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "speaker",
        "objectService": "EventOS"
    };
    var setterFunctions = {
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modified_time: function(val, state) {
            context["field"] = "modified_time";
            context["metadata"] = (objectMetadata ? objectMetadata["modified_time"] : null);
            state['modified_time'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        rating_id: function(val, state) {
            context["field"] = "rating_id";
            context["metadata"] = (objectMetadata ? objectMetadata["rating_id"] : null);
            state['rating_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        speaker_details: function(val, state) {
            context["field"] = "speaker_details";
            context["metadata"] = (objectMetadata ? objectMetadata["speaker_details"] : null);
            state['speaker_details'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        speaker_id: function(val, state) {
            context["field"] = "speaker_id";
            context["metadata"] = (objectMetadata ? objectMetadata["speaker_id"] : null);
            state['speaker_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        speaker_name: function(val, state) {
            context["field"] = "speaker_name";
            context["metadata"] = (objectMetadata ? objectMetadata["speaker_name"] : null);
            state['speaker_name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function speaker(defaultValues) {
        var privateState = {};
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "modified_time";
        context["metadata"] = (objectMetadata ? objectMetadata["modified_time"] : null);
        privateState.modified_time = defaultValues ? (defaultValues["modified_time"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modified_time"], context) : null) : null;
        context["field"] = "rating_id";
        context["metadata"] = (objectMetadata ? objectMetadata["rating_id"] : null);
        privateState.rating_id = defaultValues ? (defaultValues["rating_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["rating_id"], context) : null) : null;
        context["field"] = "speaker_details";
        context["metadata"] = (objectMetadata ? objectMetadata["speaker_details"] : null);
        privateState.speaker_details = defaultValues ? (defaultValues["speaker_details"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["speaker_details"], context) : null) : null;
        context["field"] = "speaker_id";
        context["metadata"] = (objectMetadata ? objectMetadata["speaker_id"] : null);
        privateState.speaker_id = defaultValues ? (defaultValues["speaker_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["speaker_id"], context) : null) : null;
        context["field"] = "speaker_name";
        context["metadata"] = (objectMetadata ? objectMetadata["speaker_name"] : null);
        privateState.speaker_name = defaultValues ? (defaultValues["speaker_name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["speaker_name"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modified_time": {
                get: function() {
                    context["field"] = "modified_time";
                    context["metadata"] = (objectMetadata ? objectMetadata["modified_time"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modified_time, context);
                },
                set: function(val) {
                    setterFunctions['modified_time'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "rating_id": {
                get: function() {
                    context["field"] = "rating_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["rating_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.rating_id, context);
                },
                set: function(val) {
                    setterFunctions['rating_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "speaker_details": {
                get: function() {
                    context["field"] = "speaker_details";
                    context["metadata"] = (objectMetadata ? objectMetadata["speaker_details"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.speaker_details, context);
                },
                set: function(val) {
                    setterFunctions['speaker_details'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "speaker_id": {
                get: function() {
                    context["field"] = "speaker_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["speaker_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.speaker_id, context);
                },
                set: function(val) {
                    setterFunctions['speaker_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "speaker_name": {
                get: function() {
                    context["field"] = "speaker_name";
                    context["metadata"] = (objectMetadata ? objectMetadata["speaker_name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.speaker_name, context);
                },
                set: function(val) {
                    setterFunctions['speaker_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.modified_time = value ? (value["modified_time"] ? value["modified_time"] : null) : null;
            privateState.rating_id = value ? (value["rating_id"] ? value["rating_id"] : null) : null;
            privateState.speaker_details = value ? (value["speaker_details"] ? value["speaker_details"] : null) : null;
            privateState.speaker_id = value ? (value["speaker_id"] ? value["speaker_id"] : null) : null;
            privateState.speaker_name = value ? (value["speaker_name"] ? value["speaker_name"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(speaker);
    //Create new class level validator object
    BaseModel.Validator.call(speaker);
    var registerValidatorBackup = speaker.registerValidator;
    speaker.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (speaker.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    speaker.relations = relations;
    speaker.prototype.isValid = function() {
        return speaker.isValid(this);
    };
    speaker.prototype.objModelName = "speaker";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    speaker.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("EventOS", "speaker", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    speaker.clone = function(objectToClone) {
        var clonedObj = new speaker();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return speaker;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/venue/MF_Config',[], function() {
    var mappings = {
        "is_disabled": "is_disabled",
        "modifiedDate": "modifiedDate",
        "venue_id": "venue_id",
        "venue_name": "venue_name",
    };
    Object.freeze(mappings);
    var typings = {
        "is_disabled": "boolean",
        "modifiedDate": "date",
        "venue_id": "number",
        "venue_name": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["venue_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "EventOS",
        tableName: "venue"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('EventOS/venue/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "venue",
        "objectService": "EventOS"
    };
    var setterFunctions = {
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modifiedDate: function(val, state) {
            context["field"] = "modifiedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
            state['modifiedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        venue_id: function(val, state) {
            context["field"] = "venue_id";
            context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
            state['venue_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        venue_name: function(val, state) {
            context["field"] = "venue_name";
            context["metadata"] = (objectMetadata ? objectMetadata["venue_name"] : null);
            state['venue_name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function venue(defaultValues) {
        var privateState = {};
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "modifiedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
        privateState.modifiedDate = defaultValues ? (defaultValues["modifiedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modifiedDate"], context) : null) : null;
        context["field"] = "venue_id";
        context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
        privateState.venue_id = defaultValues ? (defaultValues["venue_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["venue_id"], context) : null) : null;
        context["field"] = "venue_name";
        context["metadata"] = (objectMetadata ? objectMetadata["venue_name"] : null);
        privateState.venue_name = defaultValues ? (defaultValues["venue_name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["venue_name"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modifiedDate": {
                get: function() {
                    context["field"] = "modifiedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modifiedDate, context);
                },
                set: function(val) {
                    setterFunctions['modifiedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "venue_id": {
                get: function() {
                    context["field"] = "venue_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.venue_id, context);
                },
                set: function(val) {
                    setterFunctions['venue_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "venue_name": {
                get: function() {
                    context["field"] = "venue_name";
                    context["metadata"] = (objectMetadata ? objectMetadata["venue_name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.venue_name, context);
                },
                set: function(val) {
                    setterFunctions['venue_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.modifiedDate = value ? (value["modifiedDate"] ? value["modifiedDate"] : null) : null;
            privateState.venue_id = value ? (value["venue_id"] ? value["venue_id"] : null) : null;
            privateState.venue_name = value ? (value["venue_name"] ? value["venue_name"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(venue);
    //Create new class level validator object
    BaseModel.Validator.call(venue);
    var registerValidatorBackup = venue.registerValidator;
    venue.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (venue.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    venue.relations = relations;
    venue.prototype.isValid = function() {
        return venue.isValid(this);
    };
    venue.prototype.objModelName = "venue";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    venue.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("EventOS", "venue", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    venue.clone = function(objectToClone) {
        var clonedObj = new venue();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return venue;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSHierarchy/eventhierarchy/MF_Config',[], function() {
    var mappings = {
        "addedDateTime": "addedDateTime",
        "end_date": "end_date",
        "event_id": "event_id",
        "is_disabled": "is_disabled",
        "long_desc": "long_desc",
        "start_date": "start_date",
        "title": "title",
        "venue_id": "venue_id",
    };
    Object.freeze(mappings);
    var typings = {
        "addedDateTime": "date",
        "end_date": "date",
        "event_id": "number",
        "is_disabled": "boolean",
        "long_desc": "string",
        "start_date": "date",
        "title": "string",
        "venue_id": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["event_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "RDBMSHierarchy",
        tableName: "eventhierarchy"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSHierarchy/eventhierarchy/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "eventhierarchy",
        "objectService": "RDBMSHierarchy"
    };
    var setterFunctions = {
        addedDateTime: function(val, state) {
            context["field"] = "addedDateTime";
            context["metadata"] = (objectMetadata ? objectMetadata["addedDateTime"] : null);
            state['addedDateTime'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        end_date: function(val, state) {
            context["field"] = "end_date";
            context["metadata"] = (objectMetadata ? objectMetadata["end_date"] : null);
            state['end_date'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        event_id: function(val, state) {
            context["field"] = "event_id";
            context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
            state['event_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        long_desc: function(val, state) {
            context["field"] = "long_desc";
            context["metadata"] = (objectMetadata ? objectMetadata["long_desc"] : null);
            state['long_desc'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        start_date: function(val, state) {
            context["field"] = "start_date";
            context["metadata"] = (objectMetadata ? objectMetadata["start_date"] : null);
            state['start_date'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        title: function(val, state) {
            context["field"] = "title";
            context["metadata"] = (objectMetadata ? objectMetadata["title"] : null);
            state['title'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        venue_id: function(val, state) {
            context["field"] = "venue_id";
            context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
            state['venue_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function eventhierarchy(defaultValues) {
        var privateState = {};
        context["field"] = "addedDateTime";
        context["metadata"] = (objectMetadata ? objectMetadata["addedDateTime"] : null);
        privateState.addedDateTime = defaultValues ? (defaultValues["addedDateTime"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["addedDateTime"], context) : null) : null;
        context["field"] = "end_date";
        context["metadata"] = (objectMetadata ? objectMetadata["end_date"] : null);
        privateState.end_date = defaultValues ? (defaultValues["end_date"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["end_date"], context) : null) : null;
        context["field"] = "event_id";
        context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
        privateState.event_id = defaultValues ? (defaultValues["event_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["event_id"], context) : null) : null;
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "long_desc";
        context["metadata"] = (objectMetadata ? objectMetadata["long_desc"] : null);
        privateState.long_desc = defaultValues ? (defaultValues["long_desc"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["long_desc"], context) : null) : null;
        context["field"] = "start_date";
        context["metadata"] = (objectMetadata ? objectMetadata["start_date"] : null);
        privateState.start_date = defaultValues ? (defaultValues["start_date"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["start_date"], context) : null) : null;
        context["field"] = "title";
        context["metadata"] = (objectMetadata ? objectMetadata["title"] : null);
        privateState.title = defaultValues ? (defaultValues["title"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["title"], context) : null) : null;
        context["field"] = "venue_id";
        context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
        privateState.venue_id = defaultValues ? (defaultValues["venue_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["venue_id"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "addedDateTime": {
                get: function() {
                    context["field"] = "addedDateTime";
                    context["metadata"] = (objectMetadata ? objectMetadata["addedDateTime"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.addedDateTime, context);
                },
                set: function(val) {
                    setterFunctions['addedDateTime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "end_date": {
                get: function() {
                    context["field"] = "end_date";
                    context["metadata"] = (objectMetadata ? objectMetadata["end_date"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.end_date, context);
                },
                set: function(val) {
                    setterFunctions['end_date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "event_id": {
                get: function() {
                    context["field"] = "event_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["event_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.event_id, context);
                },
                set: function(val) {
                    setterFunctions['event_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "long_desc": {
                get: function() {
                    context["field"] = "long_desc";
                    context["metadata"] = (objectMetadata ? objectMetadata["long_desc"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.long_desc, context);
                },
                set: function(val) {
                    setterFunctions['long_desc'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "start_date": {
                get: function() {
                    context["field"] = "start_date";
                    context["metadata"] = (objectMetadata ? objectMetadata["start_date"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.start_date, context);
                },
                set: function(val) {
                    setterFunctions['start_date'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "title": {
                get: function() {
                    context["field"] = "title";
                    context["metadata"] = (objectMetadata ? objectMetadata["title"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.title, context);
                },
                set: function(val) {
                    setterFunctions['title'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "venue_id": {
                get: function() {
                    context["field"] = "venue_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.venue_id, context);
                },
                set: function(val) {
                    setterFunctions['venue_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.addedDateTime = value ? (value["addedDateTime"] ? value["addedDateTime"] : null) : null;
            privateState.end_date = value ? (value["end_date"] ? value["end_date"] : null) : null;
            privateState.event_id = value ? (value["event_id"] ? value["event_id"] : null) : null;
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.long_desc = value ? (value["long_desc"] ? value["long_desc"] : null) : null;
            privateState.start_date = value ? (value["start_date"] ? value["start_date"] : null) : null;
            privateState.title = value ? (value["title"] ? value["title"] : null) : null;
            privateState.venue_id = value ? (value["venue_id"] ? value["venue_id"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(eventhierarchy);
    //Create new class level validator object
    BaseModel.Validator.call(eventhierarchy);
    var registerValidatorBackup = eventhierarchy.registerValidator;
    eventhierarchy.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (eventhierarchy.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    eventhierarchy.relations = relations;
    eventhierarchy.prototype.isValid = function() {
        return eventhierarchy.isValid(this);
    };
    eventhierarchy.prototype.objModelName = "eventhierarchy";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    eventhierarchy.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("RDBMSHierarchy", "eventhierarchy", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    eventhierarchy.clone = function(objectToClone) {
        var clonedObj = new eventhierarchy();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return eventhierarchy;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSHierarchy/venuehierarchy/MF_Config',[], function() {
    var mappings = {
        "is_disabled": "is_disabled",
        "modifiedDate": "modifiedDate",
        "venue_id": "venue_id",
        "venue_name": "venue_name",
    };
    Object.freeze(mappings);
    var typings = {
        "is_disabled": "boolean",
        "modifiedDate": "date",
        "venue_id": "number",
        "venue_name": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["venue_id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "RDBMSHierarchy",
        tableName: "venuehierarchy"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSHierarchy/venuehierarchy/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "venuehierarchy",
        "objectService": "RDBMSHierarchy"
    };
    var setterFunctions = {
        is_disabled: function(val, state) {
            context["field"] = "is_disabled";
            context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
            state['is_disabled'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        modifiedDate: function(val, state) {
            context["field"] = "modifiedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
            state['modifiedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        venue_id: function(val, state) {
            context["field"] = "venue_id";
            context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
            state['venue_id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        venue_name: function(val, state) {
            context["field"] = "venue_name";
            context["metadata"] = (objectMetadata ? objectMetadata["venue_name"] : null);
            state['venue_name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function venuehierarchy(defaultValues) {
        var privateState = {};
        context["field"] = "is_disabled";
        context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
        privateState.is_disabled = defaultValues ? (defaultValues["is_disabled"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["is_disabled"], context) : null) : null;
        context["field"] = "modifiedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
        privateState.modifiedDate = defaultValues ? (defaultValues["modifiedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["modifiedDate"], context) : null) : null;
        context["field"] = "venue_id";
        context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
        privateState.venue_id = defaultValues ? (defaultValues["venue_id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["venue_id"], context) : null) : null;
        context["field"] = "venue_name";
        context["metadata"] = (objectMetadata ? objectMetadata["venue_name"] : null);
        privateState.venue_name = defaultValues ? (defaultValues["venue_name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["venue_name"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "is_disabled": {
                get: function() {
                    context["field"] = "is_disabled";
                    context["metadata"] = (objectMetadata ? objectMetadata["is_disabled"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.is_disabled, context);
                },
                set: function(val) {
                    setterFunctions['is_disabled'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "modifiedDate": {
                get: function() {
                    context["field"] = "modifiedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["modifiedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.modifiedDate, context);
                },
                set: function(val) {
                    setterFunctions['modifiedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "venue_id": {
                get: function() {
                    context["field"] = "venue_id";
                    context["metadata"] = (objectMetadata ? objectMetadata["venue_id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.venue_id, context);
                },
                set: function(val) {
                    setterFunctions['venue_id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "venue_name": {
                get: function() {
                    context["field"] = "venue_name";
                    context["metadata"] = (objectMetadata ? objectMetadata["venue_name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.venue_name, context);
                },
                set: function(val) {
                    setterFunctions['venue_name'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.is_disabled = value ? (value["is_disabled"] ? value["is_disabled"] : null) : null;
            privateState.modifiedDate = value ? (value["modifiedDate"] ? value["modifiedDate"] : null) : null;
            privateState.venue_id = value ? (value["venue_id"] ? value["venue_id"] : null) : null;
            privateState.venue_name = value ? (value["venue_name"] ? value["venue_name"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(venuehierarchy);
    //Create new class level validator object
    BaseModel.Validator.call(venuehierarchy);
    var registerValidatorBackup = venuehierarchy.registerValidator;
    venuehierarchy.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (venuehierarchy.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    venuehierarchy.relations = relations;
    venuehierarchy.prototype.isValid = function() {
        return venuehierarchy.isValid(this);
    };
    venuehierarchy.prototype.objModelName = "venuehierarchy";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    venuehierarchy.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("RDBMSHierarchy", "venuehierarchy", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    venuehierarchy.clone = function(objectToClone) {
        var clonedObj = new venuehierarchy();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return venuehierarchy;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSObjectService/media/MF_Config',[], function() {
    var mappings = {
        "createdtimestamp": "createdtimestamp",
        "description": "description",
        "name": "name",
        "softdeleteflag": "softdeleteflag",
        "updatedtimestamp": "updatedtimestamp",
        "url": "url",
    };
    Object.freeze(mappings);
    var typings = {
        "createdtimestamp": "date",
        "description": "string",
        "name": "number",
        "softdeleteflag": "number",
        "updatedtimestamp": "date",
        "url": "binary",
    }
    Object.freeze(typings);
    var primaryKeys = ["name", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "RDBMSObjectService",
        tableName: "media"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSObjectService/media/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "media",
        "objectService": "RDBMSObjectService"
    };
    var setterFunctions = {
        createdtimestamp: function(val, state) {
            context["field"] = "createdtimestamp";
            context["metadata"] = (objectMetadata ? objectMetadata["createdtimestamp"] : null);
            state['createdtimestamp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        description: function(val, state) {
            context["field"] = "description";
            context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
            state['description'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        name: function(val, state) {
            context["field"] = "name";
            context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
            state['name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        softdeleteflag: function(val, state) {
            context["field"] = "softdeleteflag";
            context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
            state['softdeleteflag'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        updatedtimestamp: function(val, state) {
            context["field"] = "updatedtimestamp";
            context["metadata"] = (objectMetadata ? objectMetadata["updatedtimestamp"] : null);
            state['updatedtimestamp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        url: function(val, state) {
            context["field"] = "url";
            context["metadata"] = (objectMetadata ? objectMetadata["url"] : null);
            state['url'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function media(defaultValues) {
        var privateState = {};
        context["field"] = "createdtimestamp";
        context["metadata"] = (objectMetadata ? objectMetadata["createdtimestamp"] : null);
        privateState.createdtimestamp = defaultValues ? (defaultValues["createdtimestamp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["createdtimestamp"], context) : null) : null;
        context["field"] = "description";
        context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
        privateState.description = defaultValues ? (defaultValues["description"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["description"], context) : null) : null;
        context["field"] = "name";
        context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
        privateState.name = defaultValues ? (defaultValues["name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["name"], context) : null) : null;
        context["field"] = "softdeleteflag";
        context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
        privateState.softdeleteflag = defaultValues ? (defaultValues["softdeleteflag"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["softdeleteflag"], context) : null) : null;
        context["field"] = "updatedtimestamp";
        context["metadata"] = (objectMetadata ? objectMetadata["updatedtimestamp"] : null);
        privateState.updatedtimestamp = defaultValues ? (defaultValues["updatedtimestamp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["updatedtimestamp"], context) : null) : null;
        context["field"] = "url";
        context["metadata"] = (objectMetadata ? objectMetadata["url"] : null);
        privateState.url = defaultValues ? (defaultValues["url"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["url"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "createdtimestamp": {
                get: function() {
                    context["field"] = "createdtimestamp";
                    context["metadata"] = (objectMetadata ? objectMetadata["createdtimestamp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.createdtimestamp, context);
                },
                set: function(val) {
                    setterFunctions['createdtimestamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "description": {
                get: function() {
                    context["field"] = "description";
                    context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.description, context);
                },
                set: function(val) {
                    setterFunctions['description'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "name": {
                get: function() {
                    context["field"] = "name";
                    context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.name, context);
                },
                set: function(val) {
                    setterFunctions['name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "softdeleteflag": {
                get: function() {
                    context["field"] = "softdeleteflag";
                    context["metadata"] = (objectMetadata ? objectMetadata["softdeleteflag"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.softdeleteflag, context);
                },
                set: function(val) {
                    setterFunctions['softdeleteflag'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "updatedtimestamp": {
                get: function() {
                    context["field"] = "updatedtimestamp";
                    context["metadata"] = (objectMetadata ? objectMetadata["updatedtimestamp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.updatedtimestamp, context);
                },
                set: function(val) {
                    setterFunctions['updatedtimestamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "url": {
                get: function() {
                    context["field"] = "url";
                    context["metadata"] = (objectMetadata ? objectMetadata["url"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.url, context);
                },
                set: function(val) {
                    setterFunctions['url'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.createdtimestamp = value ? (value["createdtimestamp"] ? value["createdtimestamp"] : null) : null;
            privateState.description = value ? (value["description"] ? value["description"] : null) : null;
            privateState.name = value ? (value["name"] ? value["name"] : null) : null;
            privateState.softdeleteflag = value ? (value["softdeleteflag"] ? value["softdeleteflag"] : null) : null;
            privateState.updatedtimestamp = value ? (value["updatedtimestamp"] ? value["updatedtimestamp"] : null) : null;
            privateState.url = value ? (value["url"] ? value["url"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(media);
    //Create new class level validator object
    BaseModel.Validator.call(media);
    var registerValidatorBackup = media.registerValidator;
    media.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (media.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
        //For Operation 'createBinary' with service id 'createBinarymedia7648'
    media.createBinary = function(params, onCompletion) {
        return media.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinarymedia7217'
    media.getBinary = function(params, onCompletion) {
        return media.customVerb('getBinary', params, onCompletion);
    };
    //For Operation 'updateBinary' with service id 'updateBinarymedia6364'
    media.updateBinary = function(params, onCompletion) {
        return media.customVerb('updateBinary', params, onCompletion);
    };
    //For Operation 'deleteBinary' with service id 'deleteBinarymedia5629'
    media.deleteBinary = function(params, onCompletion) {
        return media.customVerb('deleteBinary', params, onCompletion);
    };
    var relations = [];
    media.relations = relations;
    media.prototype.isValid = function() {
        return media.isValid(this);
    };
    media.prototype.objModelName = "media";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    media.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("RDBMSObjectService", "media", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    media.clone = function(objectToClone) {
        var clonedObj = new media();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return media;
});

define('RDBMSObjectService/media/Repository',[], function() {
    var BaseRepository = kony.mvc.Data.BaseRepository;
    //Create the Repository Class
    function mediaRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
        BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
    };
    //Setting BaseRepository as Parent to this Repository
    mediaRepository.prototype = Object.create(BaseRepository.prototype);
    mediaRepository.prototype.constructor = mediaRepository;
    //For Operation 'createBinary' with service id 'createBinarymedia7648'
    mediaRepository.prototype.createBinary = function(params, onCompletion) {
        return mediaRepository.prototype.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinarymedia7217'
    mediaRepository.prototype.getBinary = function(params, onCompletion) {
        return mediaRepository.prototype.customVerb('getBinary', params, onCompletion);
    };
    //For Operation 'updateBinary' with service id 'updateBinarymedia6364'
    mediaRepository.prototype.updateBinary = function(params, onCompletion) {
        return mediaRepository.prototype.customVerb('updateBinary', params, onCompletion);
    };
    //For Operation 'deleteBinary' with service id 'deleteBinarymedia5629'
    mediaRepository.prototype.deleteBinary = function(params, onCompletion) {
        return mediaRepository.prototype.customVerb('deleteBinary', params, onCompletion);
    };
    return mediaRepository;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSObjectService/product/MF_Config',[], function() {
    var mappings = {
        "description": "description",
        "id": "id",
        "name": "name",
        "price": "price",
    };
    Object.freeze(mappings);
    var typings = {
        "description": "string",
        "id": "number",
        "name": "string",
        "price": "number",
    }
    Object.freeze(typings);
    var primaryKeys = ["id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "RDBMSObjectService",
        tableName: "product"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RDBMSObjectService/product/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "product",
        "objectService": "RDBMSObjectService"
    };
    var setterFunctions = {
        description: function(val, state) {
            context["field"] = "description";
            context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
            state['description'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        id: function(val, state) {
            context["field"] = "id";
            context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
            state['id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        name: function(val, state) {
            context["field"] = "name";
            context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
            state['name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        price: function(val, state) {
            context["field"] = "price";
            context["metadata"] = (objectMetadata ? objectMetadata["price"] : null);
            state['price'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function product(defaultValues) {
        var privateState = {};
        context["field"] = "description";
        context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
        privateState.description = defaultValues ? (defaultValues["description"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["description"], context) : null) : null;
        context["field"] = "id";
        context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
        privateState.id = defaultValues ? (defaultValues["id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["id"], context) : null) : null;
        context["field"] = "name";
        context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
        privateState.name = defaultValues ? (defaultValues["name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["name"], context) : null) : null;
        context["field"] = "price";
        context["metadata"] = (objectMetadata ? objectMetadata["price"] : null);
        privateState.price = defaultValues ? (defaultValues["price"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["price"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "description": {
                get: function() {
                    context["field"] = "description";
                    context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.description, context);
                },
                set: function(val) {
                    setterFunctions['description'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "id": {
                get: function() {
                    context["field"] = "id";
                    context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.id, context);
                },
                set: function(val) {
                    setterFunctions['id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "name": {
                get: function() {
                    context["field"] = "name";
                    context["metadata"] = (objectMetadata ? objectMetadata["name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.name, context);
                },
                set: function(val) {
                    setterFunctions['name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "price": {
                get: function() {
                    context["field"] = "price";
                    context["metadata"] = (objectMetadata ? objectMetadata["price"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.price, context);
                },
                set: function(val) {
                    setterFunctions['price'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.description = value ? (value["description"] ? value["description"] : null) : null;
            privateState.id = value ? (value["id"] ? value["id"] : null) : null;
            privateState.name = value ? (value["name"] ? value["name"] : null) : null;
            privateState.price = value ? (value["price"] ? value["price"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(product);
    //Create new class level validator object
    BaseModel.Validator.call(product);
    var registerValidatorBackup = product.registerValidator;
    product.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (product.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    product.relations = relations;
    product.prototype.isValid = function() {
        return product.isValid(this);
    };
    product.prototype.objModelName = "product";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    product.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("RDBMSObjectService", "product", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    product.clone = function(objectToClone) {
        var clonedObj = new product();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return product;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('RepoManagerConfig',[], function() {
    var repoMapping = {
        Category: {
            model: "SalesforceDB/Category/Model",
            config: "SalesforceDB/Category/MF_Config",
            repository: "",
        },
        Category2: {
            model: "SalesforceDB/Category2/Model",
            config: "SalesforceDB/Category2/MF_Config",
            repository: "",
        },
        uploadBinary: {
            model: "S3ObjectSvc/uploadBinary/Model",
            config: "S3ObjectSvc/uploadBinary/MF_Config",
            repository: "",
        },
        getBinary: {
            model: "S3ObjectSvc/getBinary/Model",
            config: "S3ObjectSvc/getBinary/MF_Config",
            repository: "",
        },
        venue: {
            model: "EventOS/venue/Model",
            config: "EventOS/venue/MF_Config",
            repository: "",
        },
        speaker: {
            model: "EventOS/speaker/Model",
            config: "EventOS/speaker/MF_Config",
            repository: "",
        },
        event: {
            model: "EventOS/event/Model",
            config: "EventOS/event/MF_Config",
            repository: "",
        },
        event_speaker: {
            model: "EventOS/event_speaker/Model",
            config: "EventOS/event_speaker/MF_Config",
            repository: "",
        },
        image: {
            model: "boxObjectService/image/Model",
            config: "boxObjectService/image/MF_Config",
            repository: "",
        },
        File: {
            model: "AsyncTestService/File/Model",
            config: "AsyncTestService/File/MF_Config",
            repository: "AsyncTestService/File/Repository",
        },
        product: {
            model: "RDBMSObjectService/product/Model",
            config: "RDBMSObjectService/product/MF_Config",
            repository: "",
        },
        media: {
            model: "RDBMSObjectService/media/Model",
            config: "RDBMSObjectService/media/MF_Config",
            repository: "RDBMSObjectService/media/Repository",
        },
        contact: {
            model: "ContactOS/contact/Model",
            config: "ContactOS/contact/MF_Config",
            repository: "",
        },
        binaryContact: {
            model: "ContactOS/binaryContact/Model",
            config: "ContactOS/binaryContact/MF_Config",
            repository: "ContactOS/binaryContact/Repository",
        },
        designations: {
            model: "BooleanConversionService/designations/Model",
            config: "BooleanConversionService/designations/MF_Config",
            repository: "",
        },
        employees: {
            model: "BooleanConversionService/employees/Model",
            config: "BooleanConversionService/employees/MF_Config",
            repository: "",
        },
        binary: {
            model: "StorageObjectService/binary/Model",
            config: "StorageObjectService/binary/MF_Config",
            repository: "StorageObjectService/binary/Repository",
        },
        eventhierarchy: {
            model: "RDBMSHierarchy/eventhierarchy/Model",
            config: "RDBMSHierarchy/eventhierarchy/MF_Config",
            repository: "",
        },
        venuehierarchy: {
            model: "RDBMSHierarchy/venuehierarchy/Model",
            config: "RDBMSHierarchy/venuehierarchy/MF_Config",
            repository: "",
        },
        EAM_NOTIFICATION_ADDRESS: {
            model: "sapobj/EAM_NOTIFICATION_ADDRESS/Model",
            config: "sapobj/EAM_NOTIFICATION_ADDRESS/MF_Config",
            repository: "",
        },
        abc: {
            model: "sapobj/abc/Model",
            config: "sapobj/abc/MF_Config",
            repository: "",
        },
        EAM_ADDRESS: {
            model: "sapobj/EAM_ADDRESS/Model",
            config: "sapobj/EAM_ADDRESS/MF_Config",
            repository: "",
        },
        EAM_NOTIF: {
            model: "sapobj/EAM_NOTIF/Model",
            config: "sapobj/EAM_NOTIF/MF_Config",
            repository: "",
        },
        EAM_NOTIF_DIST: {
            model: "sapobj/EAM_NOTIF_DIST/Model",
            config: "sapobj/EAM_NOTIF_DIST/MF_Config",
            repository: "",
        },
    };
    return repoMapping;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('S3ObjectSvc/getBinary/MF_Config',[], function() {
    var mappings = {};
    Object.freeze(mappings);
    var typings = {}
    Object.freeze(typings);
    var primaryKeys = [];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "S3ObjectSvc",
        tableName: "getBinary"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('S3ObjectSvc/getBinary/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "getBinary",
        "objectService": "S3ObjectSvc"
    };
    var setterFunctions = {};
    //Create the Model Class
    function getBinary(defaultValues) {
        var privateState = {};
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {});
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {};
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(getBinary);
    //Create new class level validator object
    BaseModel.Validator.call(getBinary);
    var registerValidatorBackup = getBinary.registerValidator;
    getBinary.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (getBinary.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    getBinary.relations = relations;
    getBinary.prototype.isValid = function() {
        return getBinary.isValid(this);
    };
    getBinary.prototype.objModelName = "getBinary";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    getBinary.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("S3ObjectSvc", "getBinary", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    getBinary.clone = function(objectToClone) {
        var clonedObj = new getBinary();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return getBinary;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('S3ObjectSvc/uploadBinary/MF_Config',[], function() {
    var mappings = {};
    Object.freeze(mappings);
    var typings = {}
    Object.freeze(typings);
    var primaryKeys = [];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "S3ObjectSvc",
        tableName: "uploadBinary"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('S3ObjectSvc/uploadBinary/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "uploadBinary",
        "objectService": "S3ObjectSvc"
    };
    var setterFunctions = {};
    //Create the Model Class
    function uploadBinary(defaultValues) {
        var privateState = {};
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {});
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {};
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(uploadBinary);
    //Create new class level validator object
    BaseModel.Validator.call(uploadBinary);
    var registerValidatorBackup = uploadBinary.registerValidator;
    uploadBinary.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (uploadBinary.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    uploadBinary.relations = relations;
    uploadBinary.prototype.isValid = function() {
        return uploadBinary.isValid(this);
    };
    uploadBinary.prototype.objModelName = "uploadBinary";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    uploadBinary.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("S3ObjectSvc", "uploadBinary", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    uploadBinary.clone = function(objectToClone) {
        var clonedObj = new uploadBinary();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return uploadBinary;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('SalesforceDB/Category/MF_Config',[], function() {
    var mappings = {
        "Category_Des__c": "Category_Des__c",
        "CreatedById": "CreatedById",
        "CreatedDate": "CreatedDate",
        "Id": "Id",
        "IsDeleted": "IsDeleted",
        "LastModifiedById": "LastModifiedById",
        "LastModifiedDate": "LastModifiedDate",
        "LastReferencedDate": "LastReferencedDate",
        "LastViewedDate": "LastViewedDate",
        "Name": "Name",
        "OwnerId": "OwnerId",
        "SystemModstamp": "SystemModstamp",
    };
    Object.freeze(mappings);
    var typings = {
        "Category_Des__c": "string",
        "CreatedById": "string",
        "CreatedDate": "date",
        "Id": "string",
        "IsDeleted": "boolean",
        "LastModifiedById": "string",
        "LastModifiedDate": "date",
        "LastReferencedDate": "date",
        "LastViewedDate": "date",
        "Name": "string",
        "OwnerId": "string",
        "SystemModstamp": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["Id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "SalesforceDB",
        tableName: "Category"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('SalesforceDB/Category/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Category",
        "objectService": "SalesforceDB"
    };
    var setterFunctions = {
        Category_Des__c: function(val, state) {
            context["field"] = "Category_Des__c";
            context["metadata"] = (objectMetadata ? objectMetadata["Category_Des__c"] : null);
            state['Category_Des__c'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CreatedById: function(val, state) {
            context["field"] = "CreatedById";
            context["metadata"] = (objectMetadata ? objectMetadata["CreatedById"] : null);
            state['CreatedById'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CreatedDate: function(val, state) {
            context["field"] = "CreatedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["CreatedDate"] : null);
            state['CreatedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Id: function(val, state) {
            context["field"] = "Id";
            context["metadata"] = (objectMetadata ? objectMetadata["Id"] : null);
            state['Id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        IsDeleted: function(val, state) {
            context["field"] = "IsDeleted";
            context["metadata"] = (objectMetadata ? objectMetadata["IsDeleted"] : null);
            state['IsDeleted'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastModifiedById: function(val, state) {
            context["field"] = "LastModifiedById";
            context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedById"] : null);
            state['LastModifiedById'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastModifiedDate: function(val, state) {
            context["field"] = "LastModifiedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedDate"] : null);
            state['LastModifiedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastReferencedDate: function(val, state) {
            context["field"] = "LastReferencedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["LastReferencedDate"] : null);
            state['LastReferencedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastViewedDate: function(val, state) {
            context["field"] = "LastViewedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["LastViewedDate"] : null);
            state['LastViewedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Name: function(val, state) {
            context["field"] = "Name";
            context["metadata"] = (objectMetadata ? objectMetadata["Name"] : null);
            state['Name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OwnerId: function(val, state) {
            context["field"] = "OwnerId";
            context["metadata"] = (objectMetadata ? objectMetadata["OwnerId"] : null);
            state['OwnerId'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SystemModstamp: function(val, state) {
            context["field"] = "SystemModstamp";
            context["metadata"] = (objectMetadata ? objectMetadata["SystemModstamp"] : null);
            state['SystemModstamp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Category(defaultValues) {
        var privateState = {};
        context["field"] = "Category_Des__c";
        context["metadata"] = (objectMetadata ? objectMetadata["Category_Des__c"] : null);
        privateState.Category_Des__c = defaultValues ? (defaultValues["Category_Des__c"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Category_Des__c"], context) : null) : null;
        context["field"] = "CreatedById";
        context["metadata"] = (objectMetadata ? objectMetadata["CreatedById"] : null);
        privateState.CreatedById = defaultValues ? (defaultValues["CreatedById"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CreatedById"], context) : null) : null;
        context["field"] = "CreatedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["CreatedDate"] : null);
        privateState.CreatedDate = defaultValues ? (defaultValues["CreatedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CreatedDate"], context) : null) : null;
        context["field"] = "Id";
        context["metadata"] = (objectMetadata ? objectMetadata["Id"] : null);
        privateState.Id = defaultValues ? (defaultValues["Id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Id"], context) : null) : null;
        context["field"] = "IsDeleted";
        context["metadata"] = (objectMetadata ? objectMetadata["IsDeleted"] : null);
        privateState.IsDeleted = defaultValues ? (defaultValues["IsDeleted"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["IsDeleted"], context) : null) : null;
        context["field"] = "LastModifiedById";
        context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedById"] : null);
        privateState.LastModifiedById = defaultValues ? (defaultValues["LastModifiedById"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastModifiedById"], context) : null) : null;
        context["field"] = "LastModifiedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedDate"] : null);
        privateState.LastModifiedDate = defaultValues ? (defaultValues["LastModifiedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastModifiedDate"], context) : null) : null;
        context["field"] = "LastReferencedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["LastReferencedDate"] : null);
        privateState.LastReferencedDate = defaultValues ? (defaultValues["LastReferencedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastReferencedDate"], context) : null) : null;
        context["field"] = "LastViewedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["LastViewedDate"] : null);
        privateState.LastViewedDate = defaultValues ? (defaultValues["LastViewedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastViewedDate"], context) : null) : null;
        context["field"] = "Name";
        context["metadata"] = (objectMetadata ? objectMetadata["Name"] : null);
        privateState.Name = defaultValues ? (defaultValues["Name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Name"], context) : null) : null;
        context["field"] = "OwnerId";
        context["metadata"] = (objectMetadata ? objectMetadata["OwnerId"] : null);
        privateState.OwnerId = defaultValues ? (defaultValues["OwnerId"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OwnerId"], context) : null) : null;
        context["field"] = "SystemModstamp";
        context["metadata"] = (objectMetadata ? objectMetadata["SystemModstamp"] : null);
        privateState.SystemModstamp = defaultValues ? (defaultValues["SystemModstamp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SystemModstamp"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "Category_Des__c": {
                get: function() {
                    context["field"] = "Category_Des__c";
                    context["metadata"] = (objectMetadata ? objectMetadata["Category_Des__c"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Category_Des__c, context);
                },
                set: function(val) {
                    setterFunctions['Category_Des__c'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CreatedById": {
                get: function() {
                    context["field"] = "CreatedById";
                    context["metadata"] = (objectMetadata ? objectMetadata["CreatedById"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CreatedById, context);
                },
                set: function(val) {
                    setterFunctions['CreatedById'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CreatedDate": {
                get: function() {
                    context["field"] = "CreatedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["CreatedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CreatedDate, context);
                },
                set: function(val) {
                    setterFunctions['CreatedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Id": {
                get: function() {
                    context["field"] = "Id";
                    context["metadata"] = (objectMetadata ? objectMetadata["Id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Id, context);
                },
                set: function(val) {
                    setterFunctions['Id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "IsDeleted": {
                get: function() {
                    context["field"] = "IsDeleted";
                    context["metadata"] = (objectMetadata ? objectMetadata["IsDeleted"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.IsDeleted, context);
                },
                set: function(val) {
                    setterFunctions['IsDeleted'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastModifiedById": {
                get: function() {
                    context["field"] = "LastModifiedById";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedById"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastModifiedById, context);
                },
                set: function(val) {
                    setterFunctions['LastModifiedById'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastModifiedDate": {
                get: function() {
                    context["field"] = "LastModifiedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastModifiedDate, context);
                },
                set: function(val) {
                    setterFunctions['LastModifiedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastReferencedDate": {
                get: function() {
                    context["field"] = "LastReferencedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastReferencedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastReferencedDate, context);
                },
                set: function(val) {
                    setterFunctions['LastReferencedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastViewedDate": {
                get: function() {
                    context["field"] = "LastViewedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastViewedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastViewedDate, context);
                },
                set: function(val) {
                    setterFunctions['LastViewedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Name": {
                get: function() {
                    context["field"] = "Name";
                    context["metadata"] = (objectMetadata ? objectMetadata["Name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Name, context);
                },
                set: function(val) {
                    setterFunctions['Name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OwnerId": {
                get: function() {
                    context["field"] = "OwnerId";
                    context["metadata"] = (objectMetadata ? objectMetadata["OwnerId"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OwnerId, context);
                },
                set: function(val) {
                    setterFunctions['OwnerId'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SystemModstamp": {
                get: function() {
                    context["field"] = "SystemModstamp";
                    context["metadata"] = (objectMetadata ? objectMetadata["SystemModstamp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SystemModstamp, context);
                },
                set: function(val) {
                    setterFunctions['SystemModstamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.Category_Des__c = value ? (value["Category_Des__c"] ? value["Category_Des__c"] : null) : null;
            privateState.CreatedById = value ? (value["CreatedById"] ? value["CreatedById"] : null) : null;
            privateState.CreatedDate = value ? (value["CreatedDate"] ? value["CreatedDate"] : null) : null;
            privateState.Id = value ? (value["Id"] ? value["Id"] : null) : null;
            privateState.IsDeleted = value ? (value["IsDeleted"] ? value["IsDeleted"] : null) : null;
            privateState.LastModifiedById = value ? (value["LastModifiedById"] ? value["LastModifiedById"] : null) : null;
            privateState.LastModifiedDate = value ? (value["LastModifiedDate"] ? value["LastModifiedDate"] : null) : null;
            privateState.LastReferencedDate = value ? (value["LastReferencedDate"] ? value["LastReferencedDate"] : null) : null;
            privateState.LastViewedDate = value ? (value["LastViewedDate"] ? value["LastViewedDate"] : null) : null;
            privateState.Name = value ? (value["Name"] ? value["Name"] : null) : null;
            privateState.OwnerId = value ? (value["OwnerId"] ? value["OwnerId"] : null) : null;
            privateState.SystemModstamp = value ? (value["SystemModstamp"] ? value["SystemModstamp"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Category);
    //Create new class level validator object
    BaseModel.Validator.call(Category);
    var registerValidatorBackup = Category.registerValidator;
    Category.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Category.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Category.relations = relations;
    Category.prototype.isValid = function() {
        return Category.isValid(this);
    };
    Category.prototype.objModelName = "Category";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Category.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("SalesforceDB", "Category", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Category.clone = function(objectToClone) {
        var clonedObj = new Category();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Category;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('SalesforceDB/Category2/MF_Config',[], function() {
    var mappings = {
        "CreatedById": "CreatedById",
        "CreatedDate": "CreatedDate",
        "Id": "Id",
        "IsDeleted": "IsDeleted",
        "LastModifiedById": "LastModifiedById",
        "LastModifiedDate": "LastModifiedDate",
        "Name": "Name",
        "OwnerId": "OwnerId",
        "SystemModstamp": "SystemModstamp",
    };
    Object.freeze(mappings);
    var typings = {
        "CreatedById": "string",
        "CreatedDate": "date",
        "Id": "string",
        "IsDeleted": "boolean",
        "LastModifiedById": "string",
        "LastModifiedDate": "date",
        "Name": "string",
        "OwnerId": "string",
        "SystemModstamp": "date",
    }
    Object.freeze(typings);
    var primaryKeys = ["Id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "SalesforceDB",
        tableName: "Category2"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('SalesforceDB/Category2/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "Category2",
        "objectService": "SalesforceDB"
    };
    var setterFunctions = {
        CreatedById: function(val, state) {
            context["field"] = "CreatedById";
            context["metadata"] = (objectMetadata ? objectMetadata["CreatedById"] : null);
            state['CreatedById'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CreatedDate: function(val, state) {
            context["field"] = "CreatedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["CreatedDate"] : null);
            state['CreatedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Id: function(val, state) {
            context["field"] = "Id";
            context["metadata"] = (objectMetadata ? objectMetadata["Id"] : null);
            state['Id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        IsDeleted: function(val, state) {
            context["field"] = "IsDeleted";
            context["metadata"] = (objectMetadata ? objectMetadata["IsDeleted"] : null);
            state['IsDeleted'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastModifiedById: function(val, state) {
            context["field"] = "LastModifiedById";
            context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedById"] : null);
            state['LastModifiedById'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastModifiedDate: function(val, state) {
            context["field"] = "LastModifiedDate";
            context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedDate"] : null);
            state['LastModifiedDate'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        Name: function(val, state) {
            context["field"] = "Name";
            context["metadata"] = (objectMetadata ? objectMetadata["Name"] : null);
            state['Name'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OwnerId: function(val, state) {
            context["field"] = "OwnerId";
            context["metadata"] = (objectMetadata ? objectMetadata["OwnerId"] : null);
            state['OwnerId'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SystemModstamp: function(val, state) {
            context["field"] = "SystemModstamp";
            context["metadata"] = (objectMetadata ? objectMetadata["SystemModstamp"] : null);
            state['SystemModstamp'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function Category2(defaultValues) {
        var privateState = {};
        context["field"] = "CreatedById";
        context["metadata"] = (objectMetadata ? objectMetadata["CreatedById"] : null);
        privateState.CreatedById = defaultValues ? (defaultValues["CreatedById"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CreatedById"], context) : null) : null;
        context["field"] = "CreatedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["CreatedDate"] : null);
        privateState.CreatedDate = defaultValues ? (defaultValues["CreatedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CreatedDate"], context) : null) : null;
        context["field"] = "Id";
        context["metadata"] = (objectMetadata ? objectMetadata["Id"] : null);
        privateState.Id = defaultValues ? (defaultValues["Id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Id"], context) : null) : null;
        context["field"] = "IsDeleted";
        context["metadata"] = (objectMetadata ? objectMetadata["IsDeleted"] : null);
        privateState.IsDeleted = defaultValues ? (defaultValues["IsDeleted"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["IsDeleted"], context) : null) : null;
        context["field"] = "LastModifiedById";
        context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedById"] : null);
        privateState.LastModifiedById = defaultValues ? (defaultValues["LastModifiedById"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastModifiedById"], context) : null) : null;
        context["field"] = "LastModifiedDate";
        context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedDate"] : null);
        privateState.LastModifiedDate = defaultValues ? (defaultValues["LastModifiedDate"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastModifiedDate"], context) : null) : null;
        context["field"] = "Name";
        context["metadata"] = (objectMetadata ? objectMetadata["Name"] : null);
        privateState.Name = defaultValues ? (defaultValues["Name"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["Name"], context) : null) : null;
        context["field"] = "OwnerId";
        context["metadata"] = (objectMetadata ? objectMetadata["OwnerId"] : null);
        privateState.OwnerId = defaultValues ? (defaultValues["OwnerId"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OwnerId"], context) : null) : null;
        context["field"] = "SystemModstamp";
        context["metadata"] = (objectMetadata ? objectMetadata["SystemModstamp"] : null);
        privateState.SystemModstamp = defaultValues ? (defaultValues["SystemModstamp"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SystemModstamp"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "CreatedById": {
                get: function() {
                    context["field"] = "CreatedById";
                    context["metadata"] = (objectMetadata ? objectMetadata["CreatedById"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CreatedById, context);
                },
                set: function(val) {
                    setterFunctions['CreatedById'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CreatedDate": {
                get: function() {
                    context["field"] = "CreatedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["CreatedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CreatedDate, context);
                },
                set: function(val) {
                    setterFunctions['CreatedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Id": {
                get: function() {
                    context["field"] = "Id";
                    context["metadata"] = (objectMetadata ? objectMetadata["Id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Id, context);
                },
                set: function(val) {
                    setterFunctions['Id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "IsDeleted": {
                get: function() {
                    context["field"] = "IsDeleted";
                    context["metadata"] = (objectMetadata ? objectMetadata["IsDeleted"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.IsDeleted, context);
                },
                set: function(val) {
                    setterFunctions['IsDeleted'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastModifiedById": {
                get: function() {
                    context["field"] = "LastModifiedById";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedById"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastModifiedById, context);
                },
                set: function(val) {
                    setterFunctions['LastModifiedById'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastModifiedDate": {
                get: function() {
                    context["field"] = "LastModifiedDate";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastModifiedDate"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastModifiedDate, context);
                },
                set: function(val) {
                    setterFunctions['LastModifiedDate'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "Name": {
                get: function() {
                    context["field"] = "Name";
                    context["metadata"] = (objectMetadata ? objectMetadata["Name"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.Name, context);
                },
                set: function(val) {
                    setterFunctions['Name'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OwnerId": {
                get: function() {
                    context["field"] = "OwnerId";
                    context["metadata"] = (objectMetadata ? objectMetadata["OwnerId"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OwnerId, context);
                },
                set: function(val) {
                    setterFunctions['OwnerId'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SystemModstamp": {
                get: function() {
                    context["field"] = "SystemModstamp";
                    context["metadata"] = (objectMetadata ? objectMetadata["SystemModstamp"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SystemModstamp, context);
                },
                set: function(val) {
                    setterFunctions['SystemModstamp'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.CreatedById = value ? (value["CreatedById"] ? value["CreatedById"] : null) : null;
            privateState.CreatedDate = value ? (value["CreatedDate"] ? value["CreatedDate"] : null) : null;
            privateState.Id = value ? (value["Id"] ? value["Id"] : null) : null;
            privateState.IsDeleted = value ? (value["IsDeleted"] ? value["IsDeleted"] : null) : null;
            privateState.LastModifiedById = value ? (value["LastModifiedById"] ? value["LastModifiedById"] : null) : null;
            privateState.LastModifiedDate = value ? (value["LastModifiedDate"] ? value["LastModifiedDate"] : null) : null;
            privateState.Name = value ? (value["Name"] ? value["Name"] : null) : null;
            privateState.OwnerId = value ? (value["OwnerId"] ? value["OwnerId"] : null) : null;
            privateState.SystemModstamp = value ? (value["SystemModstamp"] ? value["SystemModstamp"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(Category2);
    //Create new class level validator object
    BaseModel.Validator.call(Category2);
    var registerValidatorBackup = Category2.registerValidator;
    Category2.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (Category2.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    Category2.relations = relations;
    Category2.prototype.isValid = function() {
        return Category2.isValid(this);
    };
    Category2.prototype.objModelName = "Category2";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    Category2.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("SalesforceDB", "Category2", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    Category2.clone = function(objectToClone) {
        var clonedObj = new Category2();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return Category2;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('StorageObjectService/binary/MF_Config',[], function() {
    var mappings = {
        "id": "id",
        "description": "description",
        "image": "image",
        "CreatedBy": "CreatedBy",
        "LastUpdatedBy": "LastUpdatedBy",
        "CreatedDateTime": "CreatedDateTime",
        "LastUpdatedDateTime": "LastUpdatedDateTime",
        "SoftDeleteFlag": "SoftDeleteFlag",
    };
    Object.freeze(mappings);
    var typings = {
        "id": "number",
        "description": "string",
        "image": "binary",
        "CreatedBy": "string",
        "LastUpdatedBy": "string",
        "CreatedDateTime": "date",
        "LastUpdatedDateTime": "date",
        "SoftDeleteFlag": "boolean",
    }
    Object.freeze(typings);
    var primaryKeys = ["id", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "StorageObjectService",
        tableName: "binary"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('StorageObjectService/binary/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "binary",
        "objectService": "StorageObjectService"
    };
    var setterFunctions = {
        id: function(val, state) {
            context["field"] = "id";
            context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
            state['id'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        description: function(val, state) {
            context["field"] = "description";
            context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
            state['description'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        image: function(val, state) {
            context["field"] = "image";
            context["metadata"] = (objectMetadata ? objectMetadata["image"] : null);
            state['image'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CreatedBy: function(val, state) {
            context["field"] = "CreatedBy";
            context["metadata"] = (objectMetadata ? objectMetadata["CreatedBy"] : null);
            state['CreatedBy'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastUpdatedBy: function(val, state) {
            context["field"] = "LastUpdatedBy";
            context["metadata"] = (objectMetadata ? objectMetadata["LastUpdatedBy"] : null);
            state['LastUpdatedBy'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CreatedDateTime: function(val, state) {
            context["field"] = "CreatedDateTime";
            context["metadata"] = (objectMetadata ? objectMetadata["CreatedDateTime"] : null);
            state['CreatedDateTime'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LastUpdatedDateTime: function(val, state) {
            context["field"] = "LastUpdatedDateTime";
            context["metadata"] = (objectMetadata ? objectMetadata["LastUpdatedDateTime"] : null);
            state['LastUpdatedDateTime'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SoftDeleteFlag: function(val, state) {
            context["field"] = "SoftDeleteFlag";
            context["metadata"] = (objectMetadata ? objectMetadata["SoftDeleteFlag"] : null);
            state['SoftDeleteFlag'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function binary(defaultValues) {
        var privateState = {};
        context["field"] = "id";
        context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
        privateState.id = defaultValues ? (defaultValues["id"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["id"], context) : null) : null;
        context["field"] = "description";
        context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
        privateState.description = defaultValues ? (defaultValues["description"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["description"], context) : null) : null;
        context["field"] = "image";
        context["metadata"] = (objectMetadata ? objectMetadata["image"] : null);
        privateState.image = defaultValues ? (defaultValues["image"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["image"], context) : null) : null;
        context["field"] = "CreatedBy";
        context["metadata"] = (objectMetadata ? objectMetadata["CreatedBy"] : null);
        privateState.CreatedBy = defaultValues ? (defaultValues["CreatedBy"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CreatedBy"], context) : null) : null;
        context["field"] = "LastUpdatedBy";
        context["metadata"] = (objectMetadata ? objectMetadata["LastUpdatedBy"] : null);
        privateState.LastUpdatedBy = defaultValues ? (defaultValues["LastUpdatedBy"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastUpdatedBy"], context) : null) : null;
        context["field"] = "CreatedDateTime";
        context["metadata"] = (objectMetadata ? objectMetadata["CreatedDateTime"] : null);
        privateState.CreatedDateTime = defaultValues ? (defaultValues["CreatedDateTime"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CreatedDateTime"], context) : null) : null;
        context["field"] = "LastUpdatedDateTime";
        context["metadata"] = (objectMetadata ? objectMetadata["LastUpdatedDateTime"] : null);
        privateState.LastUpdatedDateTime = defaultValues ? (defaultValues["LastUpdatedDateTime"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LastUpdatedDateTime"], context) : null) : null;
        context["field"] = "SoftDeleteFlag";
        context["metadata"] = (objectMetadata ? objectMetadata["SoftDeleteFlag"] : null);
        privateState.SoftDeleteFlag = defaultValues ? (defaultValues["SoftDeleteFlag"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SoftDeleteFlag"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "id": {
                get: function() {
                    context["field"] = "id";
                    context["metadata"] = (objectMetadata ? objectMetadata["id"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.id, context);
                },
                set: function(val) {
                    setterFunctions['id'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "description": {
                get: function() {
                    context["field"] = "description";
                    context["metadata"] = (objectMetadata ? objectMetadata["description"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.description, context);
                },
                set: function(val) {
                    setterFunctions['description'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "image": {
                get: function() {
                    context["field"] = "image";
                    context["metadata"] = (objectMetadata ? objectMetadata["image"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.image, context);
                },
                set: function(val) {
                    setterFunctions['image'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CreatedBy": {
                get: function() {
                    context["field"] = "CreatedBy";
                    context["metadata"] = (objectMetadata ? objectMetadata["CreatedBy"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CreatedBy, context);
                },
                set: function(val) {
                    setterFunctions['CreatedBy'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastUpdatedBy": {
                get: function() {
                    context["field"] = "LastUpdatedBy";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastUpdatedBy"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastUpdatedBy, context);
                },
                set: function(val) {
                    setterFunctions['LastUpdatedBy'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CreatedDateTime": {
                get: function() {
                    context["field"] = "CreatedDateTime";
                    context["metadata"] = (objectMetadata ? objectMetadata["CreatedDateTime"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CreatedDateTime, context);
                },
                set: function(val) {
                    setterFunctions['CreatedDateTime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LastUpdatedDateTime": {
                get: function() {
                    context["field"] = "LastUpdatedDateTime";
                    context["metadata"] = (objectMetadata ? objectMetadata["LastUpdatedDateTime"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LastUpdatedDateTime, context);
                },
                set: function(val) {
                    setterFunctions['LastUpdatedDateTime'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SoftDeleteFlag": {
                get: function() {
                    context["field"] = "SoftDeleteFlag";
                    context["metadata"] = (objectMetadata ? objectMetadata["SoftDeleteFlag"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SoftDeleteFlag, context);
                },
                set: function(val) {
                    setterFunctions['SoftDeleteFlag'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.id = value ? (value["id"] ? value["id"] : null) : null;
            privateState.description = value ? (value["description"] ? value["description"] : null) : null;
            privateState.image = value ? (value["image"] ? value["image"] : null) : null;
            privateState.CreatedBy = value ? (value["CreatedBy"] ? value["CreatedBy"] : null) : null;
            privateState.LastUpdatedBy = value ? (value["LastUpdatedBy"] ? value["LastUpdatedBy"] : null) : null;
            privateState.CreatedDateTime = value ? (value["CreatedDateTime"] ? value["CreatedDateTime"] : null) : null;
            privateState.LastUpdatedDateTime = value ? (value["LastUpdatedDateTime"] ? value["LastUpdatedDateTime"] : null) : null;
            privateState.SoftDeleteFlag = value ? (value["SoftDeleteFlag"] ? value["SoftDeleteFlag"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(binary);
    //Create new class level validator object
    BaseModel.Validator.call(binary);
    var registerValidatorBackup = binary.registerValidator;
    binary.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (binary.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
        //For Operation 'createBinary' with service id 'createBinarybinary6960'
    binary.createBinary = function(params, onCompletion) {
        return binary.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinarybinary7167'
    binary.getBinary = function(params, onCompletion) {
        return binary.customVerb('getBinary', params, onCompletion);
    };
    //For Operation 'updateBinary' with service id 'updateBinarybinary7543'
    binary.updateBinary = function(params, onCompletion) {
        return binary.customVerb('updateBinary', params, onCompletion);
    };
    //For Operation 'deleteBinary' with service id 'deleteBinarybinary6673'
    binary.deleteBinary = function(params, onCompletion) {
        return binary.customVerb('deleteBinary', params, onCompletion);
    };
    var relations = [];
    binary.relations = relations;
    binary.prototype.isValid = function() {
        return binary.isValid(this);
    };
    binary.prototype.objModelName = "binary";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    binary.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("StorageObjectService", "binary", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    binary.clone = function(objectToClone) {
        var clonedObj = new binary();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return binary;
});

define('StorageObjectService/binary/Repository',[], function() {
    var BaseRepository = kony.mvc.Data.BaseRepository;
    //Create the Repository Class
    function binaryRepository(modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource) {
        BaseRepository.call(this, modelDefinition, config, defaultAppMode, dataSourceFactory, injectedDataSource);
    };
    //Setting BaseRepository as Parent to this Repository
    binaryRepository.prototype = Object.create(BaseRepository.prototype);
    binaryRepository.prototype.constructor = binaryRepository;
    //For Operation 'createBinary' with service id 'createBinarybinary6960'
    binaryRepository.prototype.createBinary = function(params, onCompletion) {
        return binaryRepository.prototype.customVerb('createBinary', params, onCompletion);
    };
    //For Operation 'getBinary' with service id 'queryBinarybinary7167'
    binaryRepository.prototype.getBinary = function(params, onCompletion) {
        return binaryRepository.prototype.customVerb('getBinary', params, onCompletion);
    };
    //For Operation 'updateBinary' with service id 'updateBinarybinary7543'
    binaryRepository.prototype.updateBinary = function(params, onCompletion) {
        return binaryRepository.prototype.customVerb('updateBinary', params, onCompletion);
    };
    //For Operation 'deleteBinary' with service id 'deleteBinarybinary6673'
    binaryRepository.prototype.deleteBinary = function(params, onCompletion) {
        return binaryRepository.prototype.customVerb('deleteBinary', params, onCompletion);
    };
    return binaryRepository;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('boxObjectService/image/MF_Config',[], function() {
    var mappings = {
        "fileId": "fileId",
    };
    Object.freeze(mappings);
    var typings = {
        "fileId": "string",
    }
    Object.freeze(typings);
    var primaryKeys = [];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "boxObjectService",
        tableName: "image"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('boxObjectService/image/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "image",
        "objectService": "boxObjectService"
    };
    var setterFunctions = {
        fileId: function(val, state) {
            context["field"] = "fileId";
            context["metadata"] = (objectMetadata ? objectMetadata["fileId"] : null);
            state['fileId'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function image(defaultValues) {
        var privateState = {};
        context["field"] = "fileId";
        context["metadata"] = (objectMetadata ? objectMetadata["fileId"] : null);
        privateState.fileId = defaultValues ? (defaultValues["fileId"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["fileId"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "fileId": {
                get: function() {
                    context["field"] = "fileId";
                    context["metadata"] = (objectMetadata ? objectMetadata["fileId"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.fileId, context);
                },
                set: function(val) {
                    setterFunctions['fileId'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.fileId = value ? (value["fileId"] ? value["fileId"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(image);
    //Create new class level validator object
    BaseModel.Validator.call(image);
    var registerValidatorBackup = image.registerValidator;
    image.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (image.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    image.relations = relations;
    image.prototype.isValid = function() {
        return image.isValid(this);
    };
    image.prototype.objModelName = "image";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    image.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("boxObjectService", "image", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    image.clone = function(objectToClone) {
        var clonedObj = new image();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return image;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_ADDRESS/MF_Config',[], function() {
    var mappings = {
        "ADDRNO": "ADDRNO",
        "CITY": "CITY",
        "COUNTER": "COUNTER",
        "COUNTRY": "COUNTRY",
        "DELETE_IND": "DELETE_IND",
        "EMAIL": "EMAIL",
        "FAX": "FAX",
        "FAX_EXTENSION": "FAX_EXTENSION",
        "HOUSE_NUM": "HOUSE_NUM",
        "LATITUDE": "LATITUDE",
        "LONGITUDE": "LONGITUDE",
        "MOBILE1": "MOBILE1",
        "MOBILE2": "MOBILE2",
        "NAME1": "NAME1",
        "NAME2": "NAME2",
        "OPMODE": "OPMODE",
        "PHONE1": "PHONE1",
        "PHONE2": "PHONE2",
        "POST_CODE": "POST_CODE",
        "REGION": "REGION",
        "STREET": "STREET",
        "TEL_EXTENSION1": "TEL_EXTENSION1",
        "TEL_EXTENSION2": "TEL_EXTENSION2",
        "TIMESTAMP": "TIMESTAMP",
    };
    Object.freeze(mappings);
    var typings = {
        "ADDRNO": "string",
        "CITY": "string",
        "COUNTER": "string",
        "COUNTRY": "string",
        "DELETE_IND": "string",
        "EMAIL": "string",
        "FAX": "string",
        "FAX_EXTENSION": "string",
        "HOUSE_NUM": "string",
        "LATITUDE": "number",
        "LONGITUDE": "number",
        "MOBILE1": "string",
        "MOBILE2": "string",
        "NAME1": "string",
        "NAME2": "string",
        "OPMODE": "string",
        "PHONE1": "string",
        "PHONE2": "string",
        "POST_CODE": "string",
        "REGION": "string",
        "STREET": "string",
        "TEL_EXTENSION1": "string",
        "TEL_EXTENSION2": "string",
        "TIMESTAMP": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["ADDRNO", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "sapobj",
        tableName: "EAM_ADDRESS"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_ADDRESS/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "EAM_ADDRESS",
        "objectService": "sapobj"
    };
    var setterFunctions = {
        ADDRNO: function(val, state) {
            context["field"] = "ADDRNO";
            context["metadata"] = (objectMetadata ? objectMetadata["ADDRNO"] : null);
            state['ADDRNO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CITY: function(val, state) {
            context["field"] = "CITY";
            context["metadata"] = (objectMetadata ? objectMetadata["CITY"] : null);
            state['CITY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        COUNTER: function(val, state) {
            context["field"] = "COUNTER";
            context["metadata"] = (objectMetadata ? objectMetadata["COUNTER"] : null);
            state['COUNTER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        COUNTRY: function(val, state) {
            context["field"] = "COUNTRY";
            context["metadata"] = (objectMetadata ? objectMetadata["COUNTRY"] : null);
            state['COUNTRY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETE_IND: function(val, state) {
            context["field"] = "DELETE_IND";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
            state['DELETE_IND'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        EMAIL: function(val, state) {
            context["field"] = "EMAIL";
            context["metadata"] = (objectMetadata ? objectMetadata["EMAIL"] : null);
            state['EMAIL'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        FAX: function(val, state) {
            context["field"] = "FAX";
            context["metadata"] = (objectMetadata ? objectMetadata["FAX"] : null);
            state['FAX'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        FAX_EXTENSION: function(val, state) {
            context["field"] = "FAX_EXTENSION";
            context["metadata"] = (objectMetadata ? objectMetadata["FAX_EXTENSION"] : null);
            state['FAX_EXTENSION'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        HOUSE_NUM: function(val, state) {
            context["field"] = "HOUSE_NUM";
            context["metadata"] = (objectMetadata ? objectMetadata["HOUSE_NUM"] : null);
            state['HOUSE_NUM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LATITUDE: function(val, state) {
            context["field"] = "LATITUDE";
            context["metadata"] = (objectMetadata ? objectMetadata["LATITUDE"] : null);
            state['LATITUDE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LONGITUDE: function(val, state) {
            context["field"] = "LONGITUDE";
            context["metadata"] = (objectMetadata ? objectMetadata["LONGITUDE"] : null);
            state['LONGITUDE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MOBILE1: function(val, state) {
            context["field"] = "MOBILE1";
            context["metadata"] = (objectMetadata ? objectMetadata["MOBILE1"] : null);
            state['MOBILE1'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MOBILE2: function(val, state) {
            context["field"] = "MOBILE2";
            context["metadata"] = (objectMetadata ? objectMetadata["MOBILE2"] : null);
            state['MOBILE2'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NAME1: function(val, state) {
            context["field"] = "NAME1";
            context["metadata"] = (objectMetadata ? objectMetadata["NAME1"] : null);
            state['NAME1'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NAME2: function(val, state) {
            context["field"] = "NAME2";
            context["metadata"] = (objectMetadata ? objectMetadata["NAME2"] : null);
            state['NAME2'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OPMODE: function(val, state) {
            context["field"] = "OPMODE";
            context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
            state['OPMODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PHONE1: function(val, state) {
            context["field"] = "PHONE1";
            context["metadata"] = (objectMetadata ? objectMetadata["PHONE1"] : null);
            state['PHONE1'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PHONE2: function(val, state) {
            context["field"] = "PHONE2";
            context["metadata"] = (objectMetadata ? objectMetadata["PHONE2"] : null);
            state['PHONE2'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        POST_CODE: function(val, state) {
            context["field"] = "POST_CODE";
            context["metadata"] = (objectMetadata ? objectMetadata["POST_CODE"] : null);
            state['POST_CODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        REGION: function(val, state) {
            context["field"] = "REGION";
            context["metadata"] = (objectMetadata ? objectMetadata["REGION"] : null);
            state['REGION'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STREET: function(val, state) {
            context["field"] = "STREET";
            context["metadata"] = (objectMetadata ? objectMetadata["STREET"] : null);
            state['STREET'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TEL_EXTENSION1: function(val, state) {
            context["field"] = "TEL_EXTENSION1";
            context["metadata"] = (objectMetadata ? objectMetadata["TEL_EXTENSION1"] : null);
            state['TEL_EXTENSION1'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TEL_EXTENSION2: function(val, state) {
            context["field"] = "TEL_EXTENSION2";
            context["metadata"] = (objectMetadata ? objectMetadata["TEL_EXTENSION2"] : null);
            state['TEL_EXTENSION2'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TIMESTAMP: function(val, state) {
            context["field"] = "TIMESTAMP";
            context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
            state['TIMESTAMP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function EAM_ADDRESS(defaultValues) {
        var privateState = {};
        context["field"] = "ADDRNO";
        context["metadata"] = (objectMetadata ? objectMetadata["ADDRNO"] : null);
        privateState.ADDRNO = defaultValues ? (defaultValues["ADDRNO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ADDRNO"], context) : null) : null;
        context["field"] = "CITY";
        context["metadata"] = (objectMetadata ? objectMetadata["CITY"] : null);
        privateState.CITY = defaultValues ? (defaultValues["CITY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CITY"], context) : null) : null;
        context["field"] = "COUNTER";
        context["metadata"] = (objectMetadata ? objectMetadata["COUNTER"] : null);
        privateState.COUNTER = defaultValues ? (defaultValues["COUNTER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["COUNTER"], context) : null) : null;
        context["field"] = "COUNTRY";
        context["metadata"] = (objectMetadata ? objectMetadata["COUNTRY"] : null);
        privateState.COUNTRY = defaultValues ? (defaultValues["COUNTRY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["COUNTRY"], context) : null) : null;
        context["field"] = "DELETE_IND";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
        privateState.DELETE_IND = defaultValues ? (defaultValues["DELETE_IND"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETE_IND"], context) : null) : null;
        context["field"] = "EMAIL";
        context["metadata"] = (objectMetadata ? objectMetadata["EMAIL"] : null);
        privateState.EMAIL = defaultValues ? (defaultValues["EMAIL"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["EMAIL"], context) : null) : null;
        context["field"] = "FAX";
        context["metadata"] = (objectMetadata ? objectMetadata["FAX"] : null);
        privateState.FAX = defaultValues ? (defaultValues["FAX"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["FAX"], context) : null) : null;
        context["field"] = "FAX_EXTENSION";
        context["metadata"] = (objectMetadata ? objectMetadata["FAX_EXTENSION"] : null);
        privateState.FAX_EXTENSION = defaultValues ? (defaultValues["FAX_EXTENSION"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["FAX_EXTENSION"], context) : null) : null;
        context["field"] = "HOUSE_NUM";
        context["metadata"] = (objectMetadata ? objectMetadata["HOUSE_NUM"] : null);
        privateState.HOUSE_NUM = defaultValues ? (defaultValues["HOUSE_NUM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["HOUSE_NUM"], context) : null) : null;
        context["field"] = "LATITUDE";
        context["metadata"] = (objectMetadata ? objectMetadata["LATITUDE"] : null);
        privateState.LATITUDE = defaultValues ? (defaultValues["LATITUDE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LATITUDE"], context) : null) : null;
        context["field"] = "LONGITUDE";
        context["metadata"] = (objectMetadata ? objectMetadata["LONGITUDE"] : null);
        privateState.LONGITUDE = defaultValues ? (defaultValues["LONGITUDE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LONGITUDE"], context) : null) : null;
        context["field"] = "MOBILE1";
        context["metadata"] = (objectMetadata ? objectMetadata["MOBILE1"] : null);
        privateState.MOBILE1 = defaultValues ? (defaultValues["MOBILE1"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MOBILE1"], context) : null) : null;
        context["field"] = "MOBILE2";
        context["metadata"] = (objectMetadata ? objectMetadata["MOBILE2"] : null);
        privateState.MOBILE2 = defaultValues ? (defaultValues["MOBILE2"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MOBILE2"], context) : null) : null;
        context["field"] = "NAME1";
        context["metadata"] = (objectMetadata ? objectMetadata["NAME1"] : null);
        privateState.NAME1 = defaultValues ? (defaultValues["NAME1"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NAME1"], context) : null) : null;
        context["field"] = "NAME2";
        context["metadata"] = (objectMetadata ? objectMetadata["NAME2"] : null);
        privateState.NAME2 = defaultValues ? (defaultValues["NAME2"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NAME2"], context) : null) : null;
        context["field"] = "OPMODE";
        context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
        privateState.OPMODE = defaultValues ? (defaultValues["OPMODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OPMODE"], context) : null) : null;
        context["field"] = "PHONE1";
        context["metadata"] = (objectMetadata ? objectMetadata["PHONE1"] : null);
        privateState.PHONE1 = defaultValues ? (defaultValues["PHONE1"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PHONE1"], context) : null) : null;
        context["field"] = "PHONE2";
        context["metadata"] = (objectMetadata ? objectMetadata["PHONE2"] : null);
        privateState.PHONE2 = defaultValues ? (defaultValues["PHONE2"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PHONE2"], context) : null) : null;
        context["field"] = "POST_CODE";
        context["metadata"] = (objectMetadata ? objectMetadata["POST_CODE"] : null);
        privateState.POST_CODE = defaultValues ? (defaultValues["POST_CODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["POST_CODE"], context) : null) : null;
        context["field"] = "REGION";
        context["metadata"] = (objectMetadata ? objectMetadata["REGION"] : null);
        privateState.REGION = defaultValues ? (defaultValues["REGION"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["REGION"], context) : null) : null;
        context["field"] = "STREET";
        context["metadata"] = (objectMetadata ? objectMetadata["STREET"] : null);
        privateState.STREET = defaultValues ? (defaultValues["STREET"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STREET"], context) : null) : null;
        context["field"] = "TEL_EXTENSION1";
        context["metadata"] = (objectMetadata ? objectMetadata["TEL_EXTENSION1"] : null);
        privateState.TEL_EXTENSION1 = defaultValues ? (defaultValues["TEL_EXTENSION1"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TEL_EXTENSION1"], context) : null) : null;
        context["field"] = "TEL_EXTENSION2";
        context["metadata"] = (objectMetadata ? objectMetadata["TEL_EXTENSION2"] : null);
        privateState.TEL_EXTENSION2 = defaultValues ? (defaultValues["TEL_EXTENSION2"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TEL_EXTENSION2"], context) : null) : null;
        context["field"] = "TIMESTAMP";
        context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
        privateState.TIMESTAMP = defaultValues ? (defaultValues["TIMESTAMP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TIMESTAMP"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "ADDRNO": {
                get: function() {
                    context["field"] = "ADDRNO";
                    context["metadata"] = (objectMetadata ? objectMetadata["ADDRNO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ADDRNO, context);
                },
                set: function(val) {
                    setterFunctions['ADDRNO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CITY": {
                get: function() {
                    context["field"] = "CITY";
                    context["metadata"] = (objectMetadata ? objectMetadata["CITY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CITY, context);
                },
                set: function(val) {
                    setterFunctions['CITY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "COUNTER": {
                get: function() {
                    context["field"] = "COUNTER";
                    context["metadata"] = (objectMetadata ? objectMetadata["COUNTER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.COUNTER, context);
                },
                set: function(val) {
                    setterFunctions['COUNTER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "COUNTRY": {
                get: function() {
                    context["field"] = "COUNTRY";
                    context["metadata"] = (objectMetadata ? objectMetadata["COUNTRY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.COUNTRY, context);
                },
                set: function(val) {
                    setterFunctions['COUNTRY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETE_IND": {
                get: function() {
                    context["field"] = "DELETE_IND";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETE_IND, context);
                },
                set: function(val) {
                    setterFunctions['DELETE_IND'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "EMAIL": {
                get: function() {
                    context["field"] = "EMAIL";
                    context["metadata"] = (objectMetadata ? objectMetadata["EMAIL"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.EMAIL, context);
                },
                set: function(val) {
                    setterFunctions['EMAIL'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "FAX": {
                get: function() {
                    context["field"] = "FAX";
                    context["metadata"] = (objectMetadata ? objectMetadata["FAX"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.FAX, context);
                },
                set: function(val) {
                    setterFunctions['FAX'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "FAX_EXTENSION": {
                get: function() {
                    context["field"] = "FAX_EXTENSION";
                    context["metadata"] = (objectMetadata ? objectMetadata["FAX_EXTENSION"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.FAX_EXTENSION, context);
                },
                set: function(val) {
                    setterFunctions['FAX_EXTENSION'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "HOUSE_NUM": {
                get: function() {
                    context["field"] = "HOUSE_NUM";
                    context["metadata"] = (objectMetadata ? objectMetadata["HOUSE_NUM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.HOUSE_NUM, context);
                },
                set: function(val) {
                    setterFunctions['HOUSE_NUM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LATITUDE": {
                get: function() {
                    context["field"] = "LATITUDE";
                    context["metadata"] = (objectMetadata ? objectMetadata["LATITUDE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LATITUDE, context);
                },
                set: function(val) {
                    setterFunctions['LATITUDE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LONGITUDE": {
                get: function() {
                    context["field"] = "LONGITUDE";
                    context["metadata"] = (objectMetadata ? objectMetadata["LONGITUDE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LONGITUDE, context);
                },
                set: function(val) {
                    setterFunctions['LONGITUDE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MOBILE1": {
                get: function() {
                    context["field"] = "MOBILE1";
                    context["metadata"] = (objectMetadata ? objectMetadata["MOBILE1"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MOBILE1, context);
                },
                set: function(val) {
                    setterFunctions['MOBILE1'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MOBILE2": {
                get: function() {
                    context["field"] = "MOBILE2";
                    context["metadata"] = (objectMetadata ? objectMetadata["MOBILE2"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MOBILE2, context);
                },
                set: function(val) {
                    setterFunctions['MOBILE2'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NAME1": {
                get: function() {
                    context["field"] = "NAME1";
                    context["metadata"] = (objectMetadata ? objectMetadata["NAME1"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NAME1, context);
                },
                set: function(val) {
                    setterFunctions['NAME1'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NAME2": {
                get: function() {
                    context["field"] = "NAME2";
                    context["metadata"] = (objectMetadata ? objectMetadata["NAME2"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NAME2, context);
                },
                set: function(val) {
                    setterFunctions['NAME2'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OPMODE": {
                get: function() {
                    context["field"] = "OPMODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OPMODE, context);
                },
                set: function(val) {
                    setterFunctions['OPMODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PHONE1": {
                get: function() {
                    context["field"] = "PHONE1";
                    context["metadata"] = (objectMetadata ? objectMetadata["PHONE1"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PHONE1, context);
                },
                set: function(val) {
                    setterFunctions['PHONE1'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PHONE2": {
                get: function() {
                    context["field"] = "PHONE2";
                    context["metadata"] = (objectMetadata ? objectMetadata["PHONE2"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PHONE2, context);
                },
                set: function(val) {
                    setterFunctions['PHONE2'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "POST_CODE": {
                get: function() {
                    context["field"] = "POST_CODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["POST_CODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.POST_CODE, context);
                },
                set: function(val) {
                    setterFunctions['POST_CODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "REGION": {
                get: function() {
                    context["field"] = "REGION";
                    context["metadata"] = (objectMetadata ? objectMetadata["REGION"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.REGION, context);
                },
                set: function(val) {
                    setterFunctions['REGION'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STREET": {
                get: function() {
                    context["field"] = "STREET";
                    context["metadata"] = (objectMetadata ? objectMetadata["STREET"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STREET, context);
                },
                set: function(val) {
                    setterFunctions['STREET'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TEL_EXTENSION1": {
                get: function() {
                    context["field"] = "TEL_EXTENSION1";
                    context["metadata"] = (objectMetadata ? objectMetadata["TEL_EXTENSION1"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TEL_EXTENSION1, context);
                },
                set: function(val) {
                    setterFunctions['TEL_EXTENSION1'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TEL_EXTENSION2": {
                get: function() {
                    context["field"] = "TEL_EXTENSION2";
                    context["metadata"] = (objectMetadata ? objectMetadata["TEL_EXTENSION2"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TEL_EXTENSION2, context);
                },
                set: function(val) {
                    setterFunctions['TEL_EXTENSION2'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TIMESTAMP": {
                get: function() {
                    context["field"] = "TIMESTAMP";
                    context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TIMESTAMP, context);
                },
                set: function(val) {
                    setterFunctions['TIMESTAMP'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.ADDRNO = value ? (value["ADDRNO"] ? value["ADDRNO"] : null) : null;
            privateState.CITY = value ? (value["CITY"] ? value["CITY"] : null) : null;
            privateState.COUNTER = value ? (value["COUNTER"] ? value["COUNTER"] : null) : null;
            privateState.COUNTRY = value ? (value["COUNTRY"] ? value["COUNTRY"] : null) : null;
            privateState.DELETE_IND = value ? (value["DELETE_IND"] ? value["DELETE_IND"] : null) : null;
            privateState.EMAIL = value ? (value["EMAIL"] ? value["EMAIL"] : null) : null;
            privateState.FAX = value ? (value["FAX"] ? value["FAX"] : null) : null;
            privateState.FAX_EXTENSION = value ? (value["FAX_EXTENSION"] ? value["FAX_EXTENSION"] : null) : null;
            privateState.HOUSE_NUM = value ? (value["HOUSE_NUM"] ? value["HOUSE_NUM"] : null) : null;
            privateState.LATITUDE = value ? (value["LATITUDE"] ? value["LATITUDE"] : null) : null;
            privateState.LONGITUDE = value ? (value["LONGITUDE"] ? value["LONGITUDE"] : null) : null;
            privateState.MOBILE1 = value ? (value["MOBILE1"] ? value["MOBILE1"] : null) : null;
            privateState.MOBILE2 = value ? (value["MOBILE2"] ? value["MOBILE2"] : null) : null;
            privateState.NAME1 = value ? (value["NAME1"] ? value["NAME1"] : null) : null;
            privateState.NAME2 = value ? (value["NAME2"] ? value["NAME2"] : null) : null;
            privateState.OPMODE = value ? (value["OPMODE"] ? value["OPMODE"] : null) : null;
            privateState.PHONE1 = value ? (value["PHONE1"] ? value["PHONE1"] : null) : null;
            privateState.PHONE2 = value ? (value["PHONE2"] ? value["PHONE2"] : null) : null;
            privateState.POST_CODE = value ? (value["POST_CODE"] ? value["POST_CODE"] : null) : null;
            privateState.REGION = value ? (value["REGION"] ? value["REGION"] : null) : null;
            privateState.STREET = value ? (value["STREET"] ? value["STREET"] : null) : null;
            privateState.TEL_EXTENSION1 = value ? (value["TEL_EXTENSION1"] ? value["TEL_EXTENSION1"] : null) : null;
            privateState.TEL_EXTENSION2 = value ? (value["TEL_EXTENSION2"] ? value["TEL_EXTENSION2"] : null) : null;
            privateState.TIMESTAMP = value ? (value["TIMESTAMP"] ? value["TIMESTAMP"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(EAM_ADDRESS);
    //Create new class level validator object
    BaseModel.Validator.call(EAM_ADDRESS);
    var registerValidatorBackup = EAM_ADDRESS.registerValidator;
    EAM_ADDRESS.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (EAM_ADDRESS.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    EAM_ADDRESS.relations = relations;
    EAM_ADDRESS.prototype.isValid = function() {
        return EAM_ADDRESS.isValid(this);
    };
    EAM_ADDRESS.prototype.objModelName = "EAM_ADDRESS";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    EAM_ADDRESS.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("sapobj", "EAM_ADDRESS", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    EAM_ADDRESS.clone = function(objectToClone) {
        var clonedObj = new EAM_ADDRESS();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return EAM_ADDRESS;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_NOTIF/MF_Config',[], function() {
    var mappings = {
        "ABCINDIC": "ABCINDIC",
        "ACCEPTED": "ACCEPTED",
        "ADDR_NO_LOC": "ADDR_NO_LOC",
        "ADDR_NUMBER": "ADDR_NUMBER",
        "ASSEMBLY": "ASSEMBLY",
        "ASSEMBLY_EXT": "ASSEMBLY_EXT",
        "ASSEMBLY_GUID": "ASSEMBLY_GUID",
        "ASSEMBLY_VERSION": "ASSEMBLY_VERSION",
        "ASSET_NO": "ASSET_NO",
        "BREAKDOWN": "BREAKDOWN",
        "BUS_AREA": "BUS_AREA",
        "CATALOG_PROFILE": "CATALOG_PROFILE",
        "CAT_TYPE": "CAT_TYPE",
        "CAUSE_CODE": "CAUSE_CODE",
        "CHANGED_AT": "CHANGED_AT",
        "CHANGED_BY": "CHANGED_BY",
        "CHANGED_ON": "CHANGED_ON",
        "CODE_GRP_CAUSE": "CODE_GRP_CAUSE",
        "CODE_GRP_CODING": "CODE_GRP_CODING",
        "CODE_GRP_PART": "CODE_GRP_PART",
        "CODE_GRP_PROBLEM": "CODE_GRP_PROBLEM",
        "CODING_CODE": "CODING_CODE",
        "COMPTIME": "COMPTIME",
        "COMP_CODE": "COMP_CODE",
        "CONVERT_TO_WO": "CONVERT_TO_WO",
        "COSTCENTER": "COSTCENTER",
        "CO_AREA": "CO_AREA",
        "CREATED_AT": "CREATED_AT",
        "CREATED_BY": "CREATED_BY",
        "CREATED_ON": "CREATED_ON",
        "CUST_NO": "CUST_NO",
        "DELETE_FLAG": "DELETE_FLAG",
        "DELETE_IND": "DELETE_IND",
        "DESENDDATE": "DESENDDATE",
        "DESENDTM": "DESENDTM",
        "DESEN_DATE_TIME": "DESEN_DATE_TIME",
        "DESSTDATE": "DESSTDATE",
        "DESSTTIME": "DESSTTIME",
        "DESST_DATE_TIME": "DESST_DATE_TIME",
        "DEVICEDATA": "DEVICEDATA",
        "DISTR_CHAN": "DISTR_CHAN",
        "DIST_CHAN_LOC": "DIST_CHAN_LOC",
        "DIVISION": "DIVISION",
        "DIVISION_LOC": "DIVISION_LOC",
        "DOC_NUMBER": "DOC_NUMBER",
        "DOWNTIME": "DOWNTIME",
        "ENDMLFNDATE": "ENDMLFNDATE",
        "ENDMLFNTIME": "ENDMLFNTIME",
        "ENDML_DATE_TIME": "ENDML_DATE_TIME",
        "END_POINT": "END_POINT",
        "EQUIP_NUM": "EQUIP_NUM",
        "FLOCN_DESC": "FLOCN_DESC",
        "FUNC_LOCATION": "FUNC_LOCATION",
        "INTERNAL_NUMBER": "INTERNAL_NUMBER",
        "ISOCODE_UNIT": "ISOCODE_UNIT",
        "ITM_NUMBER": "ITM_NUMBER",
        "LINEAR_LENGTH": "LINEAR_LENGTH",
        "LINEAR_UNIT": "LINEAR_UNIT",
        "LOC_ACC": "LOC_ACC",
        "LONG_TEXT": "LONG_TEXT",
        "LRPID": "LRPID",
        "LTEXT": "LTEXT",
        "MAINTITEM": "MAINTITEM",
        "MAINTLOC": "MAINTLOC",
        "MAINTPLANT": "MAINTPLANT",
        "MAINTROOM": "MAINTROOM",
        "MANU_WRRNTY_ENDT": "MANU_WRRNTY_ENDT",
        "MANU_WRRNTY_STDT": "MANU_WRRNTY_STDT",
        "MARKER_DIST_END": "MARKER_DIST_END",
        "MARKER_DIST_STA": "MARKER_DIST_STA",
        "MARKER_DIST_UNIT": "MARKER_DIST_UNIT",
        "MARKER_END": "MARKER_END",
        "MARKER_START": "MARKER_START",
        "MASTER_WRRNTY_NO": "MASTER_WRRNTY_NO",
        "MATERIAL": "MATERIAL",
        "MATERIAL_EXT": "MATERIAL_EXT",
        "MATERIAL_GUID": "MATERIAL_GUID",
        "MATERIAL_VERSION": "MATERIAL_VERSION",
        "MNTCALL_NO": "MNTCALL_NO",
        "MNTPLAN": "MNTPLAN",
        "NOTF_REP_PER_NAM": "NOTF_REP_PER_NAM",
        "NOTIFTMEZ": "NOTIFTMEZ",
        "NOTIF_DATE": "NOTIF_DATE",
        "NOTIF_DATE_TIME": "NOTIF_DATE_TIME",
        "NOTIF_NUM": "NOTIF_NUM",
        "NOTIF_TIME": "NOTIF_TIME",
        "NOTIF_TYPE": "NOTIF_TYPE",
        "OBJECT_NO": "OBJECT_NO",
        "OFFSET1_TYPE": "OFFSET1_TYPE",
        "OFFSET1_UNIT": "OFFSET1_UNIT",
        "OFFSET1_VALUE": "OFFSET1_VALUE",
        "OFFSET2_TYPE": "OFFSET2_TYPE",
        "OFFSET2_UNIT": "OFFSET2_UNIT",
        "OFFSET2_VALUE": "OFFSET2_VALUE",
        "OPMODE": "OPMODE",
        "ORDER_NUM": "ORDER_NUM",
        "ORDER_TEXT": "ORDER_TEXT",
        "ORDER_TYPE": "ORDER_TYPE",
        "PART_OBJECT": "PART_OBJECT",
        "PLANGROUP": "PLANGROUP",
        "PLANPLANT": "PLANPLANT",
        "PLSECTN": "PLSECTN",
        "PM_WKCTR": "PM_WKCTR",
        "PP_WKCTR": "PP_WKCTR",
        "PRILANG": "PRILANG",
        "PRIORITY": "PRIORITY",
        "PRIORITY_TYPE": "PRIORITY_TYPE",
        "PROBLEM": "PROBLEM",
        "PROBLEM_TEXT": "PROBLEM_TEXT",
        "PURCH_DATE": "PURCH_DATE",
        "PURCH_NO_C": "PURCH_NO_C",
        "REFDATE": "REFDATE",
        "REFTIME": "REFTIME",
        "REF_DATE_TIME": "REF_DATE_TIME",
        "REJECTED": "REJECTED",
        "SALES_GRP": "SALES_GRP",
        "SALES_OFFICE": "SALES_OFFICE",
        "SALES_ORD": "SALES_ORD",
        "SALES_ORG": "SALES_ORG",
        "SALES_ORG_LOC": "SALES_ORG_LOC",
        "SCENARIO": "SCENARIO",
        "SERIALNO": "SERIALNO",
        "SERVER_GROUP": "SERVER_GROUP",
        "SERVER_ID": "SERVER_ID",
        "SHORT_TEXT": "SHORT_TEXT",
        "SORTFIELD": "SORTFIELD",
        "START_POINT": "START_POINT",
        "STAT_PROF": "STAT_PROF",
        "STDGORD": "STDGORD",
        "STLMTORDER": "STLMTORDER",
        "STRMLFNDATE": "STRMLFNDATE",
        "STRMLFNTIME": "STRMLFNTIME",
        "STRML_DATE_TIME": "STRML_DATE_TIME",
        "SUB_NUMBER": "SUB_NUMBER",
        "SYS_STATUS": "SYS_STATUS",
        "TECH_OBJ_DESC": "TECH_OBJ_DESC",
        "TEXT_LENGTH": "TEXT_LENGTH",
        "TIMESTAMP": "TIMESTAMP",
        "TIME_ZONE": "TIME_ZONE",
        "UNIT": "UNIT",
        "USERID": "USERID",
        "USERSTATUS_TXT": "USERSTATUS_TXT",
        "USER_ST": "USER_ST",
        "USER_STATUS": "USER_STATUS",
        "WBS_ELEMENT": "WBS_ELEMENT",
        "WC_SHORT_DESC": "WC_SHORT_DESC",
        "WORK_CENTER": "WORK_CENTER",
        "WRRNTY_END_DT": "WRRNTY_END_DT",
        "WRRNTY_START_DT": "WRRNTY_START_DT",
    };
    Object.freeze(mappings);
    var typings = {
        "ABCINDIC": "string",
        "ACCEPTED": "string",
        "ADDR_NO_LOC": "string",
        "ADDR_NUMBER": "string",
        "ASSEMBLY": "string",
        "ASSEMBLY_EXT": "string",
        "ASSEMBLY_GUID": "string",
        "ASSEMBLY_VERSION": "string",
        "ASSET_NO": "string",
        "BREAKDOWN": "string",
        "BUS_AREA": "string",
        "CATALOG_PROFILE": "string",
        "CAT_TYPE": "string",
        "CAUSE_CODE": "string",
        "CHANGED_AT": "string",
        "CHANGED_BY": "string",
        "CHANGED_ON": "string",
        "CODE_GRP_CAUSE": "string",
        "CODE_GRP_CODING": "string",
        "CODE_GRP_PART": "string",
        "CODE_GRP_PROBLEM": "string",
        "CODING_CODE": "string",
        "COMPTIME": "string",
        "COMP_CODE": "string",
        "CONVERT_TO_WO": "string",
        "COSTCENTER": "string",
        "CO_AREA": "string",
        "CREATED_AT": "string",
        "CREATED_BY": "string",
        "CREATED_ON": "string",
        "CUST_NO": "string",
        "DELETE_FLAG": "string",
        "DELETE_IND": "string",
        "DESENDDATE": "string",
        "DESENDTM": "string",
        "DESEN_DATE_TIME": "string",
        "DESSTDATE": "string",
        "DESSTTIME": "string",
        "DESST_DATE_TIME": "string",
        "DEVICEDATA": "string",
        "DISTR_CHAN": "string",
        "DIST_CHAN_LOC": "string",
        "DIVISION": "string",
        "DIVISION_LOC": "string",
        "DOC_NUMBER": "string",
        "DOWNTIME": "string",
        "ENDMLFNDATE": "string",
        "ENDMLFNTIME": "string",
        "ENDML_DATE_TIME": "string",
        "END_POINT": "string",
        "EQUIP_NUM": "string",
        "FLOCN_DESC": "string",
        "FUNC_LOCATION": "string",
        "INTERNAL_NUMBER": "string",
        "ISOCODE_UNIT": "string",
        "ITM_NUMBER": "string",
        "LINEAR_LENGTH": "string",
        "LINEAR_UNIT": "string",
        "LOC_ACC": "string",
        "LONG_TEXT": "string",
        "LRPID": "string",
        "LTEXT": "string",
        "MAINTITEM": "string",
        "MAINTLOC": "string",
        "MAINTPLANT": "string",
        "MAINTROOM": "string",
        "MANU_WRRNTY_ENDT": "string",
        "MANU_WRRNTY_STDT": "string",
        "MARKER_DIST_END": "string",
        "MARKER_DIST_STA": "string",
        "MARKER_DIST_UNIT": "string",
        "MARKER_END": "string",
        "MARKER_START": "string",
        "MASTER_WRRNTY_NO": "string",
        "MATERIAL": "string",
        "MATERIAL_EXT": "string",
        "MATERIAL_GUID": "string",
        "MATERIAL_VERSION": "string",
        "MNTCALL_NO": "number",
        "MNTPLAN": "string",
        "NOTF_REP_PER_NAM": "string",
        "NOTIFTMEZ": "string",
        "NOTIF_DATE": "string",
        "NOTIF_DATE_TIME": "string",
        "NOTIF_NUM": "string",
        "NOTIF_TIME": "string",
        "NOTIF_TYPE": "string",
        "OBJECT_NO": "string",
        "OFFSET1_TYPE": "string",
        "OFFSET1_UNIT": "string",
        "OFFSET1_VALUE": "string",
        "OFFSET2_TYPE": "string",
        "OFFSET2_UNIT": "string",
        "OFFSET2_VALUE": "string",
        "OPMODE": "string",
        "ORDER_NUM": "string",
        "ORDER_TEXT": "string",
        "ORDER_TYPE": "string",
        "PART_OBJECT": "string",
        "PLANGROUP": "string",
        "PLANPLANT": "string",
        "PLSECTN": "string",
        "PM_WKCTR": "string",
        "PP_WKCTR": "string",
        "PRILANG": "string",
        "PRIORITY": "string",
        "PRIORITY_TYPE": "string",
        "PROBLEM": "string",
        "PROBLEM_TEXT": "string",
        "PURCH_DATE": "string",
        "PURCH_NO_C": "string",
        "REFDATE": "string",
        "REFTIME": "string",
        "REF_DATE_TIME": "string",
        "REJECTED": "string",
        "SALES_GRP": "string",
        "SALES_OFFICE": "string",
        "SALES_ORD": "string",
        "SALES_ORG": "string",
        "SALES_ORG_LOC": "string",
        "SCENARIO": "string",
        "SERIALNO": "string",
        "SERVER_GROUP": "string",
        "SERVER_ID": "string",
        "SHORT_TEXT": "string",
        "SORTFIELD": "string",
        "START_POINT": "string",
        "STAT_PROF": "string",
        "STDGORD": "string",
        "STLMTORDER": "string",
        "STRMLFNDATE": "string",
        "STRMLFNTIME": "string",
        "STRML_DATE_TIME": "string",
        "SUB_NUMBER": "string",
        "SYS_STATUS": "string",
        "TECH_OBJ_DESC": "string",
        "TEXT_LENGTH": "string",
        "TIMESTAMP": "string",
        "TIME_ZONE": "string",
        "UNIT": "string",
        "USERID": "string",
        "USERSTATUS_TXT": "string",
        "USER_ST": "string",
        "USER_STATUS": "string",
        "WBS_ELEMENT": "string",
        "WC_SHORT_DESC": "string",
        "WORK_CENTER": "string",
        "WRRNTY_END_DT": "string",
        "WRRNTY_START_DT": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["NOTIF_NUM", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "sapobj",
        tableName: "EAM_NOTIF"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_NOTIF/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "EAM_NOTIF",
        "objectService": "sapobj"
    };
    var setterFunctions = {
        ABCINDIC: function(val, state) {
            context["field"] = "ABCINDIC";
            context["metadata"] = (objectMetadata ? objectMetadata["ABCINDIC"] : null);
            state['ABCINDIC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ACCEPTED: function(val, state) {
            context["field"] = "ACCEPTED";
            context["metadata"] = (objectMetadata ? objectMetadata["ACCEPTED"] : null);
            state['ACCEPTED'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ADDR_NO_LOC: function(val, state) {
            context["field"] = "ADDR_NO_LOC";
            context["metadata"] = (objectMetadata ? objectMetadata["ADDR_NO_LOC"] : null);
            state['ADDR_NO_LOC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ADDR_NUMBER: function(val, state) {
            context["field"] = "ADDR_NUMBER";
            context["metadata"] = (objectMetadata ? objectMetadata["ADDR_NUMBER"] : null);
            state['ADDR_NUMBER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ASSEMBLY: function(val, state) {
            context["field"] = "ASSEMBLY";
            context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY"] : null);
            state['ASSEMBLY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ASSEMBLY_EXT: function(val, state) {
            context["field"] = "ASSEMBLY_EXT";
            context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_EXT"] : null);
            state['ASSEMBLY_EXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ASSEMBLY_GUID: function(val, state) {
            context["field"] = "ASSEMBLY_GUID";
            context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_GUID"] : null);
            state['ASSEMBLY_GUID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ASSEMBLY_VERSION: function(val, state) {
            context["field"] = "ASSEMBLY_VERSION";
            context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_VERSION"] : null);
            state['ASSEMBLY_VERSION'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ASSET_NO: function(val, state) {
            context["field"] = "ASSET_NO";
            context["metadata"] = (objectMetadata ? objectMetadata["ASSET_NO"] : null);
            state['ASSET_NO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        BREAKDOWN: function(val, state) {
            context["field"] = "BREAKDOWN";
            context["metadata"] = (objectMetadata ? objectMetadata["BREAKDOWN"] : null);
            state['BREAKDOWN'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        BUS_AREA: function(val, state) {
            context["field"] = "BUS_AREA";
            context["metadata"] = (objectMetadata ? objectMetadata["BUS_AREA"] : null);
            state['BUS_AREA'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CATALOG_PROFILE: function(val, state) {
            context["field"] = "CATALOG_PROFILE";
            context["metadata"] = (objectMetadata ? objectMetadata["CATALOG_PROFILE"] : null);
            state['CATALOG_PROFILE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CAT_TYPE: function(val, state) {
            context["field"] = "CAT_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["CAT_TYPE"] : null);
            state['CAT_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CAUSE_CODE: function(val, state) {
            context["field"] = "CAUSE_CODE";
            context["metadata"] = (objectMetadata ? objectMetadata["CAUSE_CODE"] : null);
            state['CAUSE_CODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CHANGED_AT: function(val, state) {
            context["field"] = "CHANGED_AT";
            context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_AT"] : null);
            state['CHANGED_AT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CHANGED_BY: function(val, state) {
            context["field"] = "CHANGED_BY";
            context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_BY"] : null);
            state['CHANGED_BY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CHANGED_ON: function(val, state) {
            context["field"] = "CHANGED_ON";
            context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_ON"] : null);
            state['CHANGED_ON'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CODE_GRP_CAUSE: function(val, state) {
            context["field"] = "CODE_GRP_CAUSE";
            context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_CAUSE"] : null);
            state['CODE_GRP_CAUSE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CODE_GRP_CODING: function(val, state) {
            context["field"] = "CODE_GRP_CODING";
            context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_CODING"] : null);
            state['CODE_GRP_CODING'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CODE_GRP_PART: function(val, state) {
            context["field"] = "CODE_GRP_PART";
            context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_PART"] : null);
            state['CODE_GRP_PART'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CODE_GRP_PROBLEM: function(val, state) {
            context["field"] = "CODE_GRP_PROBLEM";
            context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_PROBLEM"] : null);
            state['CODE_GRP_PROBLEM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CODING_CODE: function(val, state) {
            context["field"] = "CODING_CODE";
            context["metadata"] = (objectMetadata ? objectMetadata["CODING_CODE"] : null);
            state['CODING_CODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        COMPTIME: function(val, state) {
            context["field"] = "COMPTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["COMPTIME"] : null);
            state['COMPTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        COMP_CODE: function(val, state) {
            context["field"] = "COMP_CODE";
            context["metadata"] = (objectMetadata ? objectMetadata["COMP_CODE"] : null);
            state['COMP_CODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CONVERT_TO_WO: function(val, state) {
            context["field"] = "CONVERT_TO_WO";
            context["metadata"] = (objectMetadata ? objectMetadata["CONVERT_TO_WO"] : null);
            state['CONVERT_TO_WO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        COSTCENTER: function(val, state) {
            context["field"] = "COSTCENTER";
            context["metadata"] = (objectMetadata ? objectMetadata["COSTCENTER"] : null);
            state['COSTCENTER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CO_AREA: function(val, state) {
            context["field"] = "CO_AREA";
            context["metadata"] = (objectMetadata ? objectMetadata["CO_AREA"] : null);
            state['CO_AREA'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CREATED_AT: function(val, state) {
            context["field"] = "CREATED_AT";
            context["metadata"] = (objectMetadata ? objectMetadata["CREATED_AT"] : null);
            state['CREATED_AT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CREATED_BY: function(val, state) {
            context["field"] = "CREATED_BY";
            context["metadata"] = (objectMetadata ? objectMetadata["CREATED_BY"] : null);
            state['CREATED_BY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CREATED_ON: function(val, state) {
            context["field"] = "CREATED_ON";
            context["metadata"] = (objectMetadata ? objectMetadata["CREATED_ON"] : null);
            state['CREATED_ON'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CUST_NO: function(val, state) {
            context["field"] = "CUST_NO";
            context["metadata"] = (objectMetadata ? objectMetadata["CUST_NO"] : null);
            state['CUST_NO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETE_FLAG: function(val, state) {
            context["field"] = "DELETE_FLAG";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETE_FLAG"] : null);
            state['DELETE_FLAG'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETE_IND: function(val, state) {
            context["field"] = "DELETE_IND";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
            state['DELETE_IND'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESENDDATE: function(val, state) {
            context["field"] = "DESENDDATE";
            context["metadata"] = (objectMetadata ? objectMetadata["DESENDDATE"] : null);
            state['DESENDDATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESENDTM: function(val, state) {
            context["field"] = "DESENDTM";
            context["metadata"] = (objectMetadata ? objectMetadata["DESENDTM"] : null);
            state['DESENDTM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESEN_DATE_TIME: function(val, state) {
            context["field"] = "DESEN_DATE_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["DESEN_DATE_TIME"] : null);
            state['DESEN_DATE_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESSTDATE: function(val, state) {
            context["field"] = "DESSTDATE";
            context["metadata"] = (objectMetadata ? objectMetadata["DESSTDATE"] : null);
            state['DESSTDATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESSTTIME: function(val, state) {
            context["field"] = "DESSTTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["DESSTTIME"] : null);
            state['DESSTTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESST_DATE_TIME: function(val, state) {
            context["field"] = "DESST_DATE_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["DESST_DATE_TIME"] : null);
            state['DESST_DATE_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DEVICEDATA: function(val, state) {
            context["field"] = "DEVICEDATA";
            context["metadata"] = (objectMetadata ? objectMetadata["DEVICEDATA"] : null);
            state['DEVICEDATA'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DISTR_CHAN: function(val, state) {
            context["field"] = "DISTR_CHAN";
            context["metadata"] = (objectMetadata ? objectMetadata["DISTR_CHAN"] : null);
            state['DISTR_CHAN'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DIST_CHAN_LOC: function(val, state) {
            context["field"] = "DIST_CHAN_LOC";
            context["metadata"] = (objectMetadata ? objectMetadata["DIST_CHAN_LOC"] : null);
            state['DIST_CHAN_LOC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DIVISION: function(val, state) {
            context["field"] = "DIVISION";
            context["metadata"] = (objectMetadata ? objectMetadata["DIVISION"] : null);
            state['DIVISION'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DIVISION_LOC: function(val, state) {
            context["field"] = "DIVISION_LOC";
            context["metadata"] = (objectMetadata ? objectMetadata["DIVISION_LOC"] : null);
            state['DIVISION_LOC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DOC_NUMBER: function(val, state) {
            context["field"] = "DOC_NUMBER";
            context["metadata"] = (objectMetadata ? objectMetadata["DOC_NUMBER"] : null);
            state['DOC_NUMBER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DOWNTIME: function(val, state) {
            context["field"] = "DOWNTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["DOWNTIME"] : null);
            state['DOWNTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ENDMLFNDATE: function(val, state) {
            context["field"] = "ENDMLFNDATE";
            context["metadata"] = (objectMetadata ? objectMetadata["ENDMLFNDATE"] : null);
            state['ENDMLFNDATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ENDMLFNTIME: function(val, state) {
            context["field"] = "ENDMLFNTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["ENDMLFNTIME"] : null);
            state['ENDMLFNTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ENDML_DATE_TIME: function(val, state) {
            context["field"] = "ENDML_DATE_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["ENDML_DATE_TIME"] : null);
            state['ENDML_DATE_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        END_POINT: function(val, state) {
            context["field"] = "END_POINT";
            context["metadata"] = (objectMetadata ? objectMetadata["END_POINT"] : null);
            state['END_POINT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        EQUIP_NUM: function(val, state) {
            context["field"] = "EQUIP_NUM";
            context["metadata"] = (objectMetadata ? objectMetadata["EQUIP_NUM"] : null);
            state['EQUIP_NUM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        FLOCN_DESC: function(val, state) {
            context["field"] = "FLOCN_DESC";
            context["metadata"] = (objectMetadata ? objectMetadata["FLOCN_DESC"] : null);
            state['FLOCN_DESC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        FUNC_LOCATION: function(val, state) {
            context["field"] = "FUNC_LOCATION";
            context["metadata"] = (objectMetadata ? objectMetadata["FUNC_LOCATION"] : null);
            state['FUNC_LOCATION'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        INTERNAL_NUMBER: function(val, state) {
            context["field"] = "INTERNAL_NUMBER";
            context["metadata"] = (objectMetadata ? objectMetadata["INTERNAL_NUMBER"] : null);
            state['INTERNAL_NUMBER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ISOCODE_UNIT: function(val, state) {
            context["field"] = "ISOCODE_UNIT";
            context["metadata"] = (objectMetadata ? objectMetadata["ISOCODE_UNIT"] : null);
            state['ISOCODE_UNIT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ITM_NUMBER: function(val, state) {
            context["field"] = "ITM_NUMBER";
            context["metadata"] = (objectMetadata ? objectMetadata["ITM_NUMBER"] : null);
            state['ITM_NUMBER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LINEAR_LENGTH: function(val, state) {
            context["field"] = "LINEAR_LENGTH";
            context["metadata"] = (objectMetadata ? objectMetadata["LINEAR_LENGTH"] : null);
            state['LINEAR_LENGTH'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LINEAR_UNIT: function(val, state) {
            context["field"] = "LINEAR_UNIT";
            context["metadata"] = (objectMetadata ? objectMetadata["LINEAR_UNIT"] : null);
            state['LINEAR_UNIT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LOC_ACC: function(val, state) {
            context["field"] = "LOC_ACC";
            context["metadata"] = (objectMetadata ? objectMetadata["LOC_ACC"] : null);
            state['LOC_ACC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LONG_TEXT: function(val, state) {
            context["field"] = "LONG_TEXT";
            context["metadata"] = (objectMetadata ? objectMetadata["LONG_TEXT"] : null);
            state['LONG_TEXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LRPID: function(val, state) {
            context["field"] = "LRPID";
            context["metadata"] = (objectMetadata ? objectMetadata["LRPID"] : null);
            state['LRPID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        LTEXT: function(val, state) {
            context["field"] = "LTEXT";
            context["metadata"] = (objectMetadata ? objectMetadata["LTEXT"] : null);
            state['LTEXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MAINTITEM: function(val, state) {
            context["field"] = "MAINTITEM";
            context["metadata"] = (objectMetadata ? objectMetadata["MAINTITEM"] : null);
            state['MAINTITEM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MAINTLOC: function(val, state) {
            context["field"] = "MAINTLOC";
            context["metadata"] = (objectMetadata ? objectMetadata["MAINTLOC"] : null);
            state['MAINTLOC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MAINTPLANT: function(val, state) {
            context["field"] = "MAINTPLANT";
            context["metadata"] = (objectMetadata ? objectMetadata["MAINTPLANT"] : null);
            state['MAINTPLANT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MAINTROOM: function(val, state) {
            context["field"] = "MAINTROOM";
            context["metadata"] = (objectMetadata ? objectMetadata["MAINTROOM"] : null);
            state['MAINTROOM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MANU_WRRNTY_ENDT: function(val, state) {
            context["field"] = "MANU_WRRNTY_ENDT";
            context["metadata"] = (objectMetadata ? objectMetadata["MANU_WRRNTY_ENDT"] : null);
            state['MANU_WRRNTY_ENDT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MANU_WRRNTY_STDT: function(val, state) {
            context["field"] = "MANU_WRRNTY_STDT";
            context["metadata"] = (objectMetadata ? objectMetadata["MANU_WRRNTY_STDT"] : null);
            state['MANU_WRRNTY_STDT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MARKER_DIST_END: function(val, state) {
            context["field"] = "MARKER_DIST_END";
            context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_END"] : null);
            state['MARKER_DIST_END'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MARKER_DIST_STA: function(val, state) {
            context["field"] = "MARKER_DIST_STA";
            context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_STA"] : null);
            state['MARKER_DIST_STA'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MARKER_DIST_UNIT: function(val, state) {
            context["field"] = "MARKER_DIST_UNIT";
            context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_UNIT"] : null);
            state['MARKER_DIST_UNIT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MARKER_END: function(val, state) {
            context["field"] = "MARKER_END";
            context["metadata"] = (objectMetadata ? objectMetadata["MARKER_END"] : null);
            state['MARKER_END'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MARKER_START: function(val, state) {
            context["field"] = "MARKER_START";
            context["metadata"] = (objectMetadata ? objectMetadata["MARKER_START"] : null);
            state['MARKER_START'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MASTER_WRRNTY_NO: function(val, state) {
            context["field"] = "MASTER_WRRNTY_NO";
            context["metadata"] = (objectMetadata ? objectMetadata["MASTER_WRRNTY_NO"] : null);
            state['MASTER_WRRNTY_NO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MATERIAL: function(val, state) {
            context["field"] = "MATERIAL";
            context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL"] : null);
            state['MATERIAL'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MATERIAL_EXT: function(val, state) {
            context["field"] = "MATERIAL_EXT";
            context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_EXT"] : null);
            state['MATERIAL_EXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MATERIAL_GUID: function(val, state) {
            context["field"] = "MATERIAL_GUID";
            context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_GUID"] : null);
            state['MATERIAL_GUID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MATERIAL_VERSION: function(val, state) {
            context["field"] = "MATERIAL_VERSION";
            context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_VERSION"] : null);
            state['MATERIAL_VERSION'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MNTCALL_NO: function(val, state) {
            context["field"] = "MNTCALL_NO";
            context["metadata"] = (objectMetadata ? objectMetadata["MNTCALL_NO"] : null);
            state['MNTCALL_NO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        MNTPLAN: function(val, state) {
            context["field"] = "MNTPLAN";
            context["metadata"] = (objectMetadata ? objectMetadata["MNTPLAN"] : null);
            state['MNTPLAN'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTF_REP_PER_NAM: function(val, state) {
            context["field"] = "NOTF_REP_PER_NAM";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTF_REP_PER_NAM"] : null);
            state['NOTF_REP_PER_NAM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIFTMEZ: function(val, state) {
            context["field"] = "NOTIFTMEZ";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIFTMEZ"] : null);
            state['NOTIFTMEZ'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIF_DATE: function(val, state) {
            context["field"] = "NOTIF_DATE";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_DATE"] : null);
            state['NOTIF_DATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIF_DATE_TIME: function(val, state) {
            context["field"] = "NOTIF_DATE_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_DATE_TIME"] : null);
            state['NOTIF_DATE_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIF_NUM: function(val, state) {
            context["field"] = "NOTIF_NUM";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_NUM"] : null);
            state['NOTIF_NUM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIF_TIME: function(val, state) {
            context["field"] = "NOTIF_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_TIME"] : null);
            state['NOTIF_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIF_TYPE: function(val, state) {
            context["field"] = "NOTIF_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_TYPE"] : null);
            state['NOTIF_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OBJECT_NO: function(val, state) {
            context["field"] = "OBJECT_NO";
            context["metadata"] = (objectMetadata ? objectMetadata["OBJECT_NO"] : null);
            state['OBJECT_NO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OFFSET1_TYPE: function(val, state) {
            context["field"] = "OFFSET1_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_TYPE"] : null);
            state['OFFSET1_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OFFSET1_UNIT: function(val, state) {
            context["field"] = "OFFSET1_UNIT";
            context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_UNIT"] : null);
            state['OFFSET1_UNIT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OFFSET1_VALUE: function(val, state) {
            context["field"] = "OFFSET1_VALUE";
            context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_VALUE"] : null);
            state['OFFSET1_VALUE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OFFSET2_TYPE: function(val, state) {
            context["field"] = "OFFSET2_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_TYPE"] : null);
            state['OFFSET2_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OFFSET2_UNIT: function(val, state) {
            context["field"] = "OFFSET2_UNIT";
            context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_UNIT"] : null);
            state['OFFSET2_UNIT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OFFSET2_VALUE: function(val, state) {
            context["field"] = "OFFSET2_VALUE";
            context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_VALUE"] : null);
            state['OFFSET2_VALUE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OPMODE: function(val, state) {
            context["field"] = "OPMODE";
            context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
            state['OPMODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ORDER_NUM: function(val, state) {
            context["field"] = "ORDER_NUM";
            context["metadata"] = (objectMetadata ? objectMetadata["ORDER_NUM"] : null);
            state['ORDER_NUM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ORDER_TEXT: function(val, state) {
            context["field"] = "ORDER_TEXT";
            context["metadata"] = (objectMetadata ? objectMetadata["ORDER_TEXT"] : null);
            state['ORDER_TEXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ORDER_TYPE: function(val, state) {
            context["field"] = "ORDER_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["ORDER_TYPE"] : null);
            state['ORDER_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PART_OBJECT: function(val, state) {
            context["field"] = "PART_OBJECT";
            context["metadata"] = (objectMetadata ? objectMetadata["PART_OBJECT"] : null);
            state['PART_OBJECT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PLANGROUP: function(val, state) {
            context["field"] = "PLANGROUP";
            context["metadata"] = (objectMetadata ? objectMetadata["PLANGROUP"] : null);
            state['PLANGROUP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PLANPLANT: function(val, state) {
            context["field"] = "PLANPLANT";
            context["metadata"] = (objectMetadata ? objectMetadata["PLANPLANT"] : null);
            state['PLANPLANT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PLSECTN: function(val, state) {
            context["field"] = "PLSECTN";
            context["metadata"] = (objectMetadata ? objectMetadata["PLSECTN"] : null);
            state['PLSECTN'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PM_WKCTR: function(val, state) {
            context["field"] = "PM_WKCTR";
            context["metadata"] = (objectMetadata ? objectMetadata["PM_WKCTR"] : null);
            state['PM_WKCTR'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PP_WKCTR: function(val, state) {
            context["field"] = "PP_WKCTR";
            context["metadata"] = (objectMetadata ? objectMetadata["PP_WKCTR"] : null);
            state['PP_WKCTR'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PRILANG: function(val, state) {
            context["field"] = "PRILANG";
            context["metadata"] = (objectMetadata ? objectMetadata["PRILANG"] : null);
            state['PRILANG'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PRIORITY: function(val, state) {
            context["field"] = "PRIORITY";
            context["metadata"] = (objectMetadata ? objectMetadata["PRIORITY"] : null);
            state['PRIORITY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PRIORITY_TYPE: function(val, state) {
            context["field"] = "PRIORITY_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["PRIORITY_TYPE"] : null);
            state['PRIORITY_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PROBLEM: function(val, state) {
            context["field"] = "PROBLEM";
            context["metadata"] = (objectMetadata ? objectMetadata["PROBLEM"] : null);
            state['PROBLEM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PROBLEM_TEXT: function(val, state) {
            context["field"] = "PROBLEM_TEXT";
            context["metadata"] = (objectMetadata ? objectMetadata["PROBLEM_TEXT"] : null);
            state['PROBLEM_TEXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PURCH_DATE: function(val, state) {
            context["field"] = "PURCH_DATE";
            context["metadata"] = (objectMetadata ? objectMetadata["PURCH_DATE"] : null);
            state['PURCH_DATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PURCH_NO_C: function(val, state) {
            context["field"] = "PURCH_NO_C";
            context["metadata"] = (objectMetadata ? objectMetadata["PURCH_NO_C"] : null);
            state['PURCH_NO_C'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        REFDATE: function(val, state) {
            context["field"] = "REFDATE";
            context["metadata"] = (objectMetadata ? objectMetadata["REFDATE"] : null);
            state['REFDATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        REFTIME: function(val, state) {
            context["field"] = "REFTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["REFTIME"] : null);
            state['REFTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        REF_DATE_TIME: function(val, state) {
            context["field"] = "REF_DATE_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["REF_DATE_TIME"] : null);
            state['REF_DATE_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        REJECTED: function(val, state) {
            context["field"] = "REJECTED";
            context["metadata"] = (objectMetadata ? objectMetadata["REJECTED"] : null);
            state['REJECTED'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SALES_GRP: function(val, state) {
            context["field"] = "SALES_GRP";
            context["metadata"] = (objectMetadata ? objectMetadata["SALES_GRP"] : null);
            state['SALES_GRP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SALES_OFFICE: function(val, state) {
            context["field"] = "SALES_OFFICE";
            context["metadata"] = (objectMetadata ? objectMetadata["SALES_OFFICE"] : null);
            state['SALES_OFFICE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SALES_ORD: function(val, state) {
            context["field"] = "SALES_ORD";
            context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORD"] : null);
            state['SALES_ORD'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SALES_ORG: function(val, state) {
            context["field"] = "SALES_ORG";
            context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORG"] : null);
            state['SALES_ORG'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SALES_ORG_LOC: function(val, state) {
            context["field"] = "SALES_ORG_LOC";
            context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORG_LOC"] : null);
            state['SALES_ORG_LOC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SCENARIO: function(val, state) {
            context["field"] = "SCENARIO";
            context["metadata"] = (objectMetadata ? objectMetadata["SCENARIO"] : null);
            state['SCENARIO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SERIALNO: function(val, state) {
            context["field"] = "SERIALNO";
            context["metadata"] = (objectMetadata ? objectMetadata["SERIALNO"] : null);
            state['SERIALNO'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SERVER_GROUP: function(val, state) {
            context["field"] = "SERVER_GROUP";
            context["metadata"] = (objectMetadata ? objectMetadata["SERVER_GROUP"] : null);
            state['SERVER_GROUP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SERVER_ID: function(val, state) {
            context["field"] = "SERVER_ID";
            context["metadata"] = (objectMetadata ? objectMetadata["SERVER_ID"] : null);
            state['SERVER_ID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SHORT_TEXT: function(val, state) {
            context["field"] = "SHORT_TEXT";
            context["metadata"] = (objectMetadata ? objectMetadata["SHORT_TEXT"] : null);
            state['SHORT_TEXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SORTFIELD: function(val, state) {
            context["field"] = "SORTFIELD";
            context["metadata"] = (objectMetadata ? objectMetadata["SORTFIELD"] : null);
            state['SORTFIELD'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        START_POINT: function(val, state) {
            context["field"] = "START_POINT";
            context["metadata"] = (objectMetadata ? objectMetadata["START_POINT"] : null);
            state['START_POINT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STAT_PROF: function(val, state) {
            context["field"] = "STAT_PROF";
            context["metadata"] = (objectMetadata ? objectMetadata["STAT_PROF"] : null);
            state['STAT_PROF'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STDGORD: function(val, state) {
            context["field"] = "STDGORD";
            context["metadata"] = (objectMetadata ? objectMetadata["STDGORD"] : null);
            state['STDGORD'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STLMTORDER: function(val, state) {
            context["field"] = "STLMTORDER";
            context["metadata"] = (objectMetadata ? objectMetadata["STLMTORDER"] : null);
            state['STLMTORDER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STRMLFNDATE: function(val, state) {
            context["field"] = "STRMLFNDATE";
            context["metadata"] = (objectMetadata ? objectMetadata["STRMLFNDATE"] : null);
            state['STRMLFNDATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STRMLFNTIME: function(val, state) {
            context["field"] = "STRMLFNTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["STRMLFNTIME"] : null);
            state['STRMLFNTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STRML_DATE_TIME: function(val, state) {
            context["field"] = "STRML_DATE_TIME";
            context["metadata"] = (objectMetadata ? objectMetadata["STRML_DATE_TIME"] : null);
            state['STRML_DATE_TIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SUB_NUMBER: function(val, state) {
            context["field"] = "SUB_NUMBER";
            context["metadata"] = (objectMetadata ? objectMetadata["SUB_NUMBER"] : null);
            state['SUB_NUMBER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        SYS_STATUS: function(val, state) {
            context["field"] = "SYS_STATUS";
            context["metadata"] = (objectMetadata ? objectMetadata["SYS_STATUS"] : null);
            state['SYS_STATUS'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TECH_OBJ_DESC: function(val, state) {
            context["field"] = "TECH_OBJ_DESC";
            context["metadata"] = (objectMetadata ? objectMetadata["TECH_OBJ_DESC"] : null);
            state['TECH_OBJ_DESC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TEXT_LENGTH: function(val, state) {
            context["field"] = "TEXT_LENGTH";
            context["metadata"] = (objectMetadata ? objectMetadata["TEXT_LENGTH"] : null);
            state['TEXT_LENGTH'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TIMESTAMP: function(val, state) {
            context["field"] = "TIMESTAMP";
            context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
            state['TIMESTAMP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TIME_ZONE: function(val, state) {
            context["field"] = "TIME_ZONE";
            context["metadata"] = (objectMetadata ? objectMetadata["TIME_ZONE"] : null);
            state['TIME_ZONE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        UNIT: function(val, state) {
            context["field"] = "UNIT";
            context["metadata"] = (objectMetadata ? objectMetadata["UNIT"] : null);
            state['UNIT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        USERID: function(val, state) {
            context["field"] = "USERID";
            context["metadata"] = (objectMetadata ? objectMetadata["USERID"] : null);
            state['USERID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        USERSTATUS_TXT: function(val, state) {
            context["field"] = "USERSTATUS_TXT";
            context["metadata"] = (objectMetadata ? objectMetadata["USERSTATUS_TXT"] : null);
            state['USERSTATUS_TXT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        USER_ST: function(val, state) {
            context["field"] = "USER_ST";
            context["metadata"] = (objectMetadata ? objectMetadata["USER_ST"] : null);
            state['USER_ST'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        USER_STATUS: function(val, state) {
            context["field"] = "USER_STATUS";
            context["metadata"] = (objectMetadata ? objectMetadata["USER_STATUS"] : null);
            state['USER_STATUS'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        WBS_ELEMENT: function(val, state) {
            context["field"] = "WBS_ELEMENT";
            context["metadata"] = (objectMetadata ? objectMetadata["WBS_ELEMENT"] : null);
            state['WBS_ELEMENT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        WC_SHORT_DESC: function(val, state) {
            context["field"] = "WC_SHORT_DESC";
            context["metadata"] = (objectMetadata ? objectMetadata["WC_SHORT_DESC"] : null);
            state['WC_SHORT_DESC'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        WORK_CENTER: function(val, state) {
            context["field"] = "WORK_CENTER";
            context["metadata"] = (objectMetadata ? objectMetadata["WORK_CENTER"] : null);
            state['WORK_CENTER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        WRRNTY_END_DT: function(val, state) {
            context["field"] = "WRRNTY_END_DT";
            context["metadata"] = (objectMetadata ? objectMetadata["WRRNTY_END_DT"] : null);
            state['WRRNTY_END_DT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        WRRNTY_START_DT: function(val, state) {
            context["field"] = "WRRNTY_START_DT";
            context["metadata"] = (objectMetadata ? objectMetadata["WRRNTY_START_DT"] : null);
            state['WRRNTY_START_DT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function EAM_NOTIF(defaultValues) {
        var privateState = {};
        context["field"] = "ABCINDIC";
        context["metadata"] = (objectMetadata ? objectMetadata["ABCINDIC"] : null);
        privateState.ABCINDIC = defaultValues ? (defaultValues["ABCINDIC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ABCINDIC"], context) : null) : null;
        context["field"] = "ACCEPTED";
        context["metadata"] = (objectMetadata ? objectMetadata["ACCEPTED"] : null);
        privateState.ACCEPTED = defaultValues ? (defaultValues["ACCEPTED"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ACCEPTED"], context) : null) : null;
        context["field"] = "ADDR_NO_LOC";
        context["metadata"] = (objectMetadata ? objectMetadata["ADDR_NO_LOC"] : null);
        privateState.ADDR_NO_LOC = defaultValues ? (defaultValues["ADDR_NO_LOC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ADDR_NO_LOC"], context) : null) : null;
        context["field"] = "ADDR_NUMBER";
        context["metadata"] = (objectMetadata ? objectMetadata["ADDR_NUMBER"] : null);
        privateState.ADDR_NUMBER = defaultValues ? (defaultValues["ADDR_NUMBER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ADDR_NUMBER"], context) : null) : null;
        context["field"] = "ASSEMBLY";
        context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY"] : null);
        privateState.ASSEMBLY = defaultValues ? (defaultValues["ASSEMBLY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ASSEMBLY"], context) : null) : null;
        context["field"] = "ASSEMBLY_EXT";
        context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_EXT"] : null);
        privateState.ASSEMBLY_EXT = defaultValues ? (defaultValues["ASSEMBLY_EXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ASSEMBLY_EXT"], context) : null) : null;
        context["field"] = "ASSEMBLY_GUID";
        context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_GUID"] : null);
        privateState.ASSEMBLY_GUID = defaultValues ? (defaultValues["ASSEMBLY_GUID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ASSEMBLY_GUID"], context) : null) : null;
        context["field"] = "ASSEMBLY_VERSION";
        context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_VERSION"] : null);
        privateState.ASSEMBLY_VERSION = defaultValues ? (defaultValues["ASSEMBLY_VERSION"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ASSEMBLY_VERSION"], context) : null) : null;
        context["field"] = "ASSET_NO";
        context["metadata"] = (objectMetadata ? objectMetadata["ASSET_NO"] : null);
        privateState.ASSET_NO = defaultValues ? (defaultValues["ASSET_NO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ASSET_NO"], context) : null) : null;
        context["field"] = "BREAKDOWN";
        context["metadata"] = (objectMetadata ? objectMetadata["BREAKDOWN"] : null);
        privateState.BREAKDOWN = defaultValues ? (defaultValues["BREAKDOWN"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["BREAKDOWN"], context) : null) : null;
        context["field"] = "BUS_AREA";
        context["metadata"] = (objectMetadata ? objectMetadata["BUS_AREA"] : null);
        privateState.BUS_AREA = defaultValues ? (defaultValues["BUS_AREA"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["BUS_AREA"], context) : null) : null;
        context["field"] = "CATALOG_PROFILE";
        context["metadata"] = (objectMetadata ? objectMetadata["CATALOG_PROFILE"] : null);
        privateState.CATALOG_PROFILE = defaultValues ? (defaultValues["CATALOG_PROFILE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CATALOG_PROFILE"], context) : null) : null;
        context["field"] = "CAT_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["CAT_TYPE"] : null);
        privateState.CAT_TYPE = defaultValues ? (defaultValues["CAT_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CAT_TYPE"], context) : null) : null;
        context["field"] = "CAUSE_CODE";
        context["metadata"] = (objectMetadata ? objectMetadata["CAUSE_CODE"] : null);
        privateState.CAUSE_CODE = defaultValues ? (defaultValues["CAUSE_CODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CAUSE_CODE"], context) : null) : null;
        context["field"] = "CHANGED_AT";
        context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_AT"] : null);
        privateState.CHANGED_AT = defaultValues ? (defaultValues["CHANGED_AT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CHANGED_AT"], context) : null) : null;
        context["field"] = "CHANGED_BY";
        context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_BY"] : null);
        privateState.CHANGED_BY = defaultValues ? (defaultValues["CHANGED_BY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CHANGED_BY"], context) : null) : null;
        context["field"] = "CHANGED_ON";
        context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_ON"] : null);
        privateState.CHANGED_ON = defaultValues ? (defaultValues["CHANGED_ON"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CHANGED_ON"], context) : null) : null;
        context["field"] = "CODE_GRP_CAUSE";
        context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_CAUSE"] : null);
        privateState.CODE_GRP_CAUSE = defaultValues ? (defaultValues["CODE_GRP_CAUSE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CODE_GRP_CAUSE"], context) : null) : null;
        context["field"] = "CODE_GRP_CODING";
        context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_CODING"] : null);
        privateState.CODE_GRP_CODING = defaultValues ? (defaultValues["CODE_GRP_CODING"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CODE_GRP_CODING"], context) : null) : null;
        context["field"] = "CODE_GRP_PART";
        context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_PART"] : null);
        privateState.CODE_GRP_PART = defaultValues ? (defaultValues["CODE_GRP_PART"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CODE_GRP_PART"], context) : null) : null;
        context["field"] = "CODE_GRP_PROBLEM";
        context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_PROBLEM"] : null);
        privateState.CODE_GRP_PROBLEM = defaultValues ? (defaultValues["CODE_GRP_PROBLEM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CODE_GRP_PROBLEM"], context) : null) : null;
        context["field"] = "CODING_CODE";
        context["metadata"] = (objectMetadata ? objectMetadata["CODING_CODE"] : null);
        privateState.CODING_CODE = defaultValues ? (defaultValues["CODING_CODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CODING_CODE"], context) : null) : null;
        context["field"] = "COMPTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["COMPTIME"] : null);
        privateState.COMPTIME = defaultValues ? (defaultValues["COMPTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["COMPTIME"], context) : null) : null;
        context["field"] = "COMP_CODE";
        context["metadata"] = (objectMetadata ? objectMetadata["COMP_CODE"] : null);
        privateState.COMP_CODE = defaultValues ? (defaultValues["COMP_CODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["COMP_CODE"], context) : null) : null;
        context["field"] = "CONVERT_TO_WO";
        context["metadata"] = (objectMetadata ? objectMetadata["CONVERT_TO_WO"] : null);
        privateState.CONVERT_TO_WO = defaultValues ? (defaultValues["CONVERT_TO_WO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CONVERT_TO_WO"], context) : null) : null;
        context["field"] = "COSTCENTER";
        context["metadata"] = (objectMetadata ? objectMetadata["COSTCENTER"] : null);
        privateState.COSTCENTER = defaultValues ? (defaultValues["COSTCENTER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["COSTCENTER"], context) : null) : null;
        context["field"] = "CO_AREA";
        context["metadata"] = (objectMetadata ? objectMetadata["CO_AREA"] : null);
        privateState.CO_AREA = defaultValues ? (defaultValues["CO_AREA"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CO_AREA"], context) : null) : null;
        context["field"] = "CREATED_AT";
        context["metadata"] = (objectMetadata ? objectMetadata["CREATED_AT"] : null);
        privateState.CREATED_AT = defaultValues ? (defaultValues["CREATED_AT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CREATED_AT"], context) : null) : null;
        context["field"] = "CREATED_BY";
        context["metadata"] = (objectMetadata ? objectMetadata["CREATED_BY"] : null);
        privateState.CREATED_BY = defaultValues ? (defaultValues["CREATED_BY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CREATED_BY"], context) : null) : null;
        context["field"] = "CREATED_ON";
        context["metadata"] = (objectMetadata ? objectMetadata["CREATED_ON"] : null);
        privateState.CREATED_ON = defaultValues ? (defaultValues["CREATED_ON"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CREATED_ON"], context) : null) : null;
        context["field"] = "CUST_NO";
        context["metadata"] = (objectMetadata ? objectMetadata["CUST_NO"] : null);
        privateState.CUST_NO = defaultValues ? (defaultValues["CUST_NO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CUST_NO"], context) : null) : null;
        context["field"] = "DELETE_FLAG";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETE_FLAG"] : null);
        privateState.DELETE_FLAG = defaultValues ? (defaultValues["DELETE_FLAG"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETE_FLAG"], context) : null) : null;
        context["field"] = "DELETE_IND";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
        privateState.DELETE_IND = defaultValues ? (defaultValues["DELETE_IND"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETE_IND"], context) : null) : null;
        context["field"] = "DESENDDATE";
        context["metadata"] = (objectMetadata ? objectMetadata["DESENDDATE"] : null);
        privateState.DESENDDATE = defaultValues ? (defaultValues["DESENDDATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESENDDATE"], context) : null) : null;
        context["field"] = "DESENDTM";
        context["metadata"] = (objectMetadata ? objectMetadata["DESENDTM"] : null);
        privateState.DESENDTM = defaultValues ? (defaultValues["DESENDTM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESENDTM"], context) : null) : null;
        context["field"] = "DESEN_DATE_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["DESEN_DATE_TIME"] : null);
        privateState.DESEN_DATE_TIME = defaultValues ? (defaultValues["DESEN_DATE_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESEN_DATE_TIME"], context) : null) : null;
        context["field"] = "DESSTDATE";
        context["metadata"] = (objectMetadata ? objectMetadata["DESSTDATE"] : null);
        privateState.DESSTDATE = defaultValues ? (defaultValues["DESSTDATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESSTDATE"], context) : null) : null;
        context["field"] = "DESSTTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["DESSTTIME"] : null);
        privateState.DESSTTIME = defaultValues ? (defaultValues["DESSTTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESSTTIME"], context) : null) : null;
        context["field"] = "DESST_DATE_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["DESST_DATE_TIME"] : null);
        privateState.DESST_DATE_TIME = defaultValues ? (defaultValues["DESST_DATE_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESST_DATE_TIME"], context) : null) : null;
        context["field"] = "DEVICEDATA";
        context["metadata"] = (objectMetadata ? objectMetadata["DEVICEDATA"] : null);
        privateState.DEVICEDATA = defaultValues ? (defaultValues["DEVICEDATA"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DEVICEDATA"], context) : null) : null;
        context["field"] = "DISTR_CHAN";
        context["metadata"] = (objectMetadata ? objectMetadata["DISTR_CHAN"] : null);
        privateState.DISTR_CHAN = defaultValues ? (defaultValues["DISTR_CHAN"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DISTR_CHAN"], context) : null) : null;
        context["field"] = "DIST_CHAN_LOC";
        context["metadata"] = (objectMetadata ? objectMetadata["DIST_CHAN_LOC"] : null);
        privateState.DIST_CHAN_LOC = defaultValues ? (defaultValues["DIST_CHAN_LOC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DIST_CHAN_LOC"], context) : null) : null;
        context["field"] = "DIVISION";
        context["metadata"] = (objectMetadata ? objectMetadata["DIVISION"] : null);
        privateState.DIVISION = defaultValues ? (defaultValues["DIVISION"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DIVISION"], context) : null) : null;
        context["field"] = "DIVISION_LOC";
        context["metadata"] = (objectMetadata ? objectMetadata["DIVISION_LOC"] : null);
        privateState.DIVISION_LOC = defaultValues ? (defaultValues["DIVISION_LOC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DIVISION_LOC"], context) : null) : null;
        context["field"] = "DOC_NUMBER";
        context["metadata"] = (objectMetadata ? objectMetadata["DOC_NUMBER"] : null);
        privateState.DOC_NUMBER = defaultValues ? (defaultValues["DOC_NUMBER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DOC_NUMBER"], context) : null) : null;
        context["field"] = "DOWNTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["DOWNTIME"] : null);
        privateState.DOWNTIME = defaultValues ? (defaultValues["DOWNTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DOWNTIME"], context) : null) : null;
        context["field"] = "ENDMLFNDATE";
        context["metadata"] = (objectMetadata ? objectMetadata["ENDMLFNDATE"] : null);
        privateState.ENDMLFNDATE = defaultValues ? (defaultValues["ENDMLFNDATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ENDMLFNDATE"], context) : null) : null;
        context["field"] = "ENDMLFNTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["ENDMLFNTIME"] : null);
        privateState.ENDMLFNTIME = defaultValues ? (defaultValues["ENDMLFNTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ENDMLFNTIME"], context) : null) : null;
        context["field"] = "ENDML_DATE_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["ENDML_DATE_TIME"] : null);
        privateState.ENDML_DATE_TIME = defaultValues ? (defaultValues["ENDML_DATE_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ENDML_DATE_TIME"], context) : null) : null;
        context["field"] = "END_POINT";
        context["metadata"] = (objectMetadata ? objectMetadata["END_POINT"] : null);
        privateState.END_POINT = defaultValues ? (defaultValues["END_POINT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["END_POINT"], context) : null) : null;
        context["field"] = "EQUIP_NUM";
        context["metadata"] = (objectMetadata ? objectMetadata["EQUIP_NUM"] : null);
        privateState.EQUIP_NUM = defaultValues ? (defaultValues["EQUIP_NUM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["EQUIP_NUM"], context) : null) : null;
        context["field"] = "FLOCN_DESC";
        context["metadata"] = (objectMetadata ? objectMetadata["FLOCN_DESC"] : null);
        privateState.FLOCN_DESC = defaultValues ? (defaultValues["FLOCN_DESC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["FLOCN_DESC"], context) : null) : null;
        context["field"] = "FUNC_LOCATION";
        context["metadata"] = (objectMetadata ? objectMetadata["FUNC_LOCATION"] : null);
        privateState.FUNC_LOCATION = defaultValues ? (defaultValues["FUNC_LOCATION"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["FUNC_LOCATION"], context) : null) : null;
        context["field"] = "INTERNAL_NUMBER";
        context["metadata"] = (objectMetadata ? objectMetadata["INTERNAL_NUMBER"] : null);
        privateState.INTERNAL_NUMBER = defaultValues ? (defaultValues["INTERNAL_NUMBER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["INTERNAL_NUMBER"], context) : null) : null;
        context["field"] = "ISOCODE_UNIT";
        context["metadata"] = (objectMetadata ? objectMetadata["ISOCODE_UNIT"] : null);
        privateState.ISOCODE_UNIT = defaultValues ? (defaultValues["ISOCODE_UNIT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ISOCODE_UNIT"], context) : null) : null;
        context["field"] = "ITM_NUMBER";
        context["metadata"] = (objectMetadata ? objectMetadata["ITM_NUMBER"] : null);
        privateState.ITM_NUMBER = defaultValues ? (defaultValues["ITM_NUMBER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ITM_NUMBER"], context) : null) : null;
        context["field"] = "LINEAR_LENGTH";
        context["metadata"] = (objectMetadata ? objectMetadata["LINEAR_LENGTH"] : null);
        privateState.LINEAR_LENGTH = defaultValues ? (defaultValues["LINEAR_LENGTH"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LINEAR_LENGTH"], context) : null) : null;
        context["field"] = "LINEAR_UNIT";
        context["metadata"] = (objectMetadata ? objectMetadata["LINEAR_UNIT"] : null);
        privateState.LINEAR_UNIT = defaultValues ? (defaultValues["LINEAR_UNIT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LINEAR_UNIT"], context) : null) : null;
        context["field"] = "LOC_ACC";
        context["metadata"] = (objectMetadata ? objectMetadata["LOC_ACC"] : null);
        privateState.LOC_ACC = defaultValues ? (defaultValues["LOC_ACC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LOC_ACC"], context) : null) : null;
        context["field"] = "LONG_TEXT";
        context["metadata"] = (objectMetadata ? objectMetadata["LONG_TEXT"] : null);
        privateState.LONG_TEXT = defaultValues ? (defaultValues["LONG_TEXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LONG_TEXT"], context) : null) : null;
        context["field"] = "LRPID";
        context["metadata"] = (objectMetadata ? objectMetadata["LRPID"] : null);
        privateState.LRPID = defaultValues ? (defaultValues["LRPID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LRPID"], context) : null) : null;
        context["field"] = "LTEXT";
        context["metadata"] = (objectMetadata ? objectMetadata["LTEXT"] : null);
        privateState.LTEXT = defaultValues ? (defaultValues["LTEXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["LTEXT"], context) : null) : null;
        context["field"] = "MAINTITEM";
        context["metadata"] = (objectMetadata ? objectMetadata["MAINTITEM"] : null);
        privateState.MAINTITEM = defaultValues ? (defaultValues["MAINTITEM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MAINTITEM"], context) : null) : null;
        context["field"] = "MAINTLOC";
        context["metadata"] = (objectMetadata ? objectMetadata["MAINTLOC"] : null);
        privateState.MAINTLOC = defaultValues ? (defaultValues["MAINTLOC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MAINTLOC"], context) : null) : null;
        context["field"] = "MAINTPLANT";
        context["metadata"] = (objectMetadata ? objectMetadata["MAINTPLANT"] : null);
        privateState.MAINTPLANT = defaultValues ? (defaultValues["MAINTPLANT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MAINTPLANT"], context) : null) : null;
        context["field"] = "MAINTROOM";
        context["metadata"] = (objectMetadata ? objectMetadata["MAINTROOM"] : null);
        privateState.MAINTROOM = defaultValues ? (defaultValues["MAINTROOM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MAINTROOM"], context) : null) : null;
        context["field"] = "MANU_WRRNTY_ENDT";
        context["metadata"] = (objectMetadata ? objectMetadata["MANU_WRRNTY_ENDT"] : null);
        privateState.MANU_WRRNTY_ENDT = defaultValues ? (defaultValues["MANU_WRRNTY_ENDT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MANU_WRRNTY_ENDT"], context) : null) : null;
        context["field"] = "MANU_WRRNTY_STDT";
        context["metadata"] = (objectMetadata ? objectMetadata["MANU_WRRNTY_STDT"] : null);
        privateState.MANU_WRRNTY_STDT = defaultValues ? (defaultValues["MANU_WRRNTY_STDT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MANU_WRRNTY_STDT"], context) : null) : null;
        context["field"] = "MARKER_DIST_END";
        context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_END"] : null);
        privateState.MARKER_DIST_END = defaultValues ? (defaultValues["MARKER_DIST_END"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MARKER_DIST_END"], context) : null) : null;
        context["field"] = "MARKER_DIST_STA";
        context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_STA"] : null);
        privateState.MARKER_DIST_STA = defaultValues ? (defaultValues["MARKER_DIST_STA"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MARKER_DIST_STA"], context) : null) : null;
        context["field"] = "MARKER_DIST_UNIT";
        context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_UNIT"] : null);
        privateState.MARKER_DIST_UNIT = defaultValues ? (defaultValues["MARKER_DIST_UNIT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MARKER_DIST_UNIT"], context) : null) : null;
        context["field"] = "MARKER_END";
        context["metadata"] = (objectMetadata ? objectMetadata["MARKER_END"] : null);
        privateState.MARKER_END = defaultValues ? (defaultValues["MARKER_END"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MARKER_END"], context) : null) : null;
        context["field"] = "MARKER_START";
        context["metadata"] = (objectMetadata ? objectMetadata["MARKER_START"] : null);
        privateState.MARKER_START = defaultValues ? (defaultValues["MARKER_START"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MARKER_START"], context) : null) : null;
        context["field"] = "MASTER_WRRNTY_NO";
        context["metadata"] = (objectMetadata ? objectMetadata["MASTER_WRRNTY_NO"] : null);
        privateState.MASTER_WRRNTY_NO = defaultValues ? (defaultValues["MASTER_WRRNTY_NO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MASTER_WRRNTY_NO"], context) : null) : null;
        context["field"] = "MATERIAL";
        context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL"] : null);
        privateState.MATERIAL = defaultValues ? (defaultValues["MATERIAL"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MATERIAL"], context) : null) : null;
        context["field"] = "MATERIAL_EXT";
        context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_EXT"] : null);
        privateState.MATERIAL_EXT = defaultValues ? (defaultValues["MATERIAL_EXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MATERIAL_EXT"], context) : null) : null;
        context["field"] = "MATERIAL_GUID";
        context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_GUID"] : null);
        privateState.MATERIAL_GUID = defaultValues ? (defaultValues["MATERIAL_GUID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MATERIAL_GUID"], context) : null) : null;
        context["field"] = "MATERIAL_VERSION";
        context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_VERSION"] : null);
        privateState.MATERIAL_VERSION = defaultValues ? (defaultValues["MATERIAL_VERSION"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MATERIAL_VERSION"], context) : null) : null;
        context["field"] = "MNTCALL_NO";
        context["metadata"] = (objectMetadata ? objectMetadata["MNTCALL_NO"] : null);
        privateState.MNTCALL_NO = defaultValues ? (defaultValues["MNTCALL_NO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MNTCALL_NO"], context) : null) : null;
        context["field"] = "MNTPLAN";
        context["metadata"] = (objectMetadata ? objectMetadata["MNTPLAN"] : null);
        privateState.MNTPLAN = defaultValues ? (defaultValues["MNTPLAN"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["MNTPLAN"], context) : null) : null;
        context["field"] = "NOTF_REP_PER_NAM";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTF_REP_PER_NAM"] : null);
        privateState.NOTF_REP_PER_NAM = defaultValues ? (defaultValues["NOTF_REP_PER_NAM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTF_REP_PER_NAM"], context) : null) : null;
        context["field"] = "NOTIFTMEZ";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIFTMEZ"] : null);
        privateState.NOTIFTMEZ = defaultValues ? (defaultValues["NOTIFTMEZ"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIFTMEZ"], context) : null) : null;
        context["field"] = "NOTIF_DATE";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_DATE"] : null);
        privateState.NOTIF_DATE = defaultValues ? (defaultValues["NOTIF_DATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIF_DATE"], context) : null) : null;
        context["field"] = "NOTIF_DATE_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_DATE_TIME"] : null);
        privateState.NOTIF_DATE_TIME = defaultValues ? (defaultValues["NOTIF_DATE_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIF_DATE_TIME"], context) : null) : null;
        context["field"] = "NOTIF_NUM";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_NUM"] : null);
        privateState.NOTIF_NUM = defaultValues ? (defaultValues["NOTIF_NUM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIF_NUM"], context) : null) : null;
        context["field"] = "NOTIF_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_TIME"] : null);
        privateState.NOTIF_TIME = defaultValues ? (defaultValues["NOTIF_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIF_TIME"], context) : null) : null;
        context["field"] = "NOTIF_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_TYPE"] : null);
        privateState.NOTIF_TYPE = defaultValues ? (defaultValues["NOTIF_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIF_TYPE"], context) : null) : null;
        context["field"] = "OBJECT_NO";
        context["metadata"] = (objectMetadata ? objectMetadata["OBJECT_NO"] : null);
        privateState.OBJECT_NO = defaultValues ? (defaultValues["OBJECT_NO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OBJECT_NO"], context) : null) : null;
        context["field"] = "OFFSET1_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_TYPE"] : null);
        privateState.OFFSET1_TYPE = defaultValues ? (defaultValues["OFFSET1_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OFFSET1_TYPE"], context) : null) : null;
        context["field"] = "OFFSET1_UNIT";
        context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_UNIT"] : null);
        privateState.OFFSET1_UNIT = defaultValues ? (defaultValues["OFFSET1_UNIT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OFFSET1_UNIT"], context) : null) : null;
        context["field"] = "OFFSET1_VALUE";
        context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_VALUE"] : null);
        privateState.OFFSET1_VALUE = defaultValues ? (defaultValues["OFFSET1_VALUE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OFFSET1_VALUE"], context) : null) : null;
        context["field"] = "OFFSET2_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_TYPE"] : null);
        privateState.OFFSET2_TYPE = defaultValues ? (defaultValues["OFFSET2_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OFFSET2_TYPE"], context) : null) : null;
        context["field"] = "OFFSET2_UNIT";
        context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_UNIT"] : null);
        privateState.OFFSET2_UNIT = defaultValues ? (defaultValues["OFFSET2_UNIT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OFFSET2_UNIT"], context) : null) : null;
        context["field"] = "OFFSET2_VALUE";
        context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_VALUE"] : null);
        privateState.OFFSET2_VALUE = defaultValues ? (defaultValues["OFFSET2_VALUE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OFFSET2_VALUE"], context) : null) : null;
        context["field"] = "OPMODE";
        context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
        privateState.OPMODE = defaultValues ? (defaultValues["OPMODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OPMODE"], context) : null) : null;
        context["field"] = "ORDER_NUM";
        context["metadata"] = (objectMetadata ? objectMetadata["ORDER_NUM"] : null);
        privateState.ORDER_NUM = defaultValues ? (defaultValues["ORDER_NUM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ORDER_NUM"], context) : null) : null;
        context["field"] = "ORDER_TEXT";
        context["metadata"] = (objectMetadata ? objectMetadata["ORDER_TEXT"] : null);
        privateState.ORDER_TEXT = defaultValues ? (defaultValues["ORDER_TEXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ORDER_TEXT"], context) : null) : null;
        context["field"] = "ORDER_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["ORDER_TYPE"] : null);
        privateState.ORDER_TYPE = defaultValues ? (defaultValues["ORDER_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ORDER_TYPE"], context) : null) : null;
        context["field"] = "PART_OBJECT";
        context["metadata"] = (objectMetadata ? objectMetadata["PART_OBJECT"] : null);
        privateState.PART_OBJECT = defaultValues ? (defaultValues["PART_OBJECT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PART_OBJECT"], context) : null) : null;
        context["field"] = "PLANGROUP";
        context["metadata"] = (objectMetadata ? objectMetadata["PLANGROUP"] : null);
        privateState.PLANGROUP = defaultValues ? (defaultValues["PLANGROUP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PLANGROUP"], context) : null) : null;
        context["field"] = "PLANPLANT";
        context["metadata"] = (objectMetadata ? objectMetadata["PLANPLANT"] : null);
        privateState.PLANPLANT = defaultValues ? (defaultValues["PLANPLANT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PLANPLANT"], context) : null) : null;
        context["field"] = "PLSECTN";
        context["metadata"] = (objectMetadata ? objectMetadata["PLSECTN"] : null);
        privateState.PLSECTN = defaultValues ? (defaultValues["PLSECTN"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PLSECTN"], context) : null) : null;
        context["field"] = "PM_WKCTR";
        context["metadata"] = (objectMetadata ? objectMetadata["PM_WKCTR"] : null);
        privateState.PM_WKCTR = defaultValues ? (defaultValues["PM_WKCTR"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PM_WKCTR"], context) : null) : null;
        context["field"] = "PP_WKCTR";
        context["metadata"] = (objectMetadata ? objectMetadata["PP_WKCTR"] : null);
        privateState.PP_WKCTR = defaultValues ? (defaultValues["PP_WKCTR"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PP_WKCTR"], context) : null) : null;
        context["field"] = "PRILANG";
        context["metadata"] = (objectMetadata ? objectMetadata["PRILANG"] : null);
        privateState.PRILANG = defaultValues ? (defaultValues["PRILANG"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PRILANG"], context) : null) : null;
        context["field"] = "PRIORITY";
        context["metadata"] = (objectMetadata ? objectMetadata["PRIORITY"] : null);
        privateState.PRIORITY = defaultValues ? (defaultValues["PRIORITY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PRIORITY"], context) : null) : null;
        context["field"] = "PRIORITY_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["PRIORITY_TYPE"] : null);
        privateState.PRIORITY_TYPE = defaultValues ? (defaultValues["PRIORITY_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PRIORITY_TYPE"], context) : null) : null;
        context["field"] = "PROBLEM";
        context["metadata"] = (objectMetadata ? objectMetadata["PROBLEM"] : null);
        privateState.PROBLEM = defaultValues ? (defaultValues["PROBLEM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PROBLEM"], context) : null) : null;
        context["field"] = "PROBLEM_TEXT";
        context["metadata"] = (objectMetadata ? objectMetadata["PROBLEM_TEXT"] : null);
        privateState.PROBLEM_TEXT = defaultValues ? (defaultValues["PROBLEM_TEXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PROBLEM_TEXT"], context) : null) : null;
        context["field"] = "PURCH_DATE";
        context["metadata"] = (objectMetadata ? objectMetadata["PURCH_DATE"] : null);
        privateState.PURCH_DATE = defaultValues ? (defaultValues["PURCH_DATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PURCH_DATE"], context) : null) : null;
        context["field"] = "PURCH_NO_C";
        context["metadata"] = (objectMetadata ? objectMetadata["PURCH_NO_C"] : null);
        privateState.PURCH_NO_C = defaultValues ? (defaultValues["PURCH_NO_C"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PURCH_NO_C"], context) : null) : null;
        context["field"] = "REFDATE";
        context["metadata"] = (objectMetadata ? objectMetadata["REFDATE"] : null);
        privateState.REFDATE = defaultValues ? (defaultValues["REFDATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["REFDATE"], context) : null) : null;
        context["field"] = "REFTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["REFTIME"] : null);
        privateState.REFTIME = defaultValues ? (defaultValues["REFTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["REFTIME"], context) : null) : null;
        context["field"] = "REF_DATE_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["REF_DATE_TIME"] : null);
        privateState.REF_DATE_TIME = defaultValues ? (defaultValues["REF_DATE_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["REF_DATE_TIME"], context) : null) : null;
        context["field"] = "REJECTED";
        context["metadata"] = (objectMetadata ? objectMetadata["REJECTED"] : null);
        privateState.REJECTED = defaultValues ? (defaultValues["REJECTED"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["REJECTED"], context) : null) : null;
        context["field"] = "SALES_GRP";
        context["metadata"] = (objectMetadata ? objectMetadata["SALES_GRP"] : null);
        privateState.SALES_GRP = defaultValues ? (defaultValues["SALES_GRP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SALES_GRP"], context) : null) : null;
        context["field"] = "SALES_OFFICE";
        context["metadata"] = (objectMetadata ? objectMetadata["SALES_OFFICE"] : null);
        privateState.SALES_OFFICE = defaultValues ? (defaultValues["SALES_OFFICE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SALES_OFFICE"], context) : null) : null;
        context["field"] = "SALES_ORD";
        context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORD"] : null);
        privateState.SALES_ORD = defaultValues ? (defaultValues["SALES_ORD"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SALES_ORD"], context) : null) : null;
        context["field"] = "SALES_ORG";
        context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORG"] : null);
        privateState.SALES_ORG = defaultValues ? (defaultValues["SALES_ORG"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SALES_ORG"], context) : null) : null;
        context["field"] = "SALES_ORG_LOC";
        context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORG_LOC"] : null);
        privateState.SALES_ORG_LOC = defaultValues ? (defaultValues["SALES_ORG_LOC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SALES_ORG_LOC"], context) : null) : null;
        context["field"] = "SCENARIO";
        context["metadata"] = (objectMetadata ? objectMetadata["SCENARIO"] : null);
        privateState.SCENARIO = defaultValues ? (defaultValues["SCENARIO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SCENARIO"], context) : null) : null;
        context["field"] = "SERIALNO";
        context["metadata"] = (objectMetadata ? objectMetadata["SERIALNO"] : null);
        privateState.SERIALNO = defaultValues ? (defaultValues["SERIALNO"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SERIALNO"], context) : null) : null;
        context["field"] = "SERVER_GROUP";
        context["metadata"] = (objectMetadata ? objectMetadata["SERVER_GROUP"] : null);
        privateState.SERVER_GROUP = defaultValues ? (defaultValues["SERVER_GROUP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SERVER_GROUP"], context) : null) : null;
        context["field"] = "SERVER_ID";
        context["metadata"] = (objectMetadata ? objectMetadata["SERVER_ID"] : null);
        privateState.SERVER_ID = defaultValues ? (defaultValues["SERVER_ID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SERVER_ID"], context) : null) : null;
        context["field"] = "SHORT_TEXT";
        context["metadata"] = (objectMetadata ? objectMetadata["SHORT_TEXT"] : null);
        privateState.SHORT_TEXT = defaultValues ? (defaultValues["SHORT_TEXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SHORT_TEXT"], context) : null) : null;
        context["field"] = "SORTFIELD";
        context["metadata"] = (objectMetadata ? objectMetadata["SORTFIELD"] : null);
        privateState.SORTFIELD = defaultValues ? (defaultValues["SORTFIELD"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SORTFIELD"], context) : null) : null;
        context["field"] = "START_POINT";
        context["metadata"] = (objectMetadata ? objectMetadata["START_POINT"] : null);
        privateState.START_POINT = defaultValues ? (defaultValues["START_POINT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["START_POINT"], context) : null) : null;
        context["field"] = "STAT_PROF";
        context["metadata"] = (objectMetadata ? objectMetadata["STAT_PROF"] : null);
        privateState.STAT_PROF = defaultValues ? (defaultValues["STAT_PROF"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STAT_PROF"], context) : null) : null;
        context["field"] = "STDGORD";
        context["metadata"] = (objectMetadata ? objectMetadata["STDGORD"] : null);
        privateState.STDGORD = defaultValues ? (defaultValues["STDGORD"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STDGORD"], context) : null) : null;
        context["field"] = "STLMTORDER";
        context["metadata"] = (objectMetadata ? objectMetadata["STLMTORDER"] : null);
        privateState.STLMTORDER = defaultValues ? (defaultValues["STLMTORDER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STLMTORDER"], context) : null) : null;
        context["field"] = "STRMLFNDATE";
        context["metadata"] = (objectMetadata ? objectMetadata["STRMLFNDATE"] : null);
        privateState.STRMLFNDATE = defaultValues ? (defaultValues["STRMLFNDATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STRMLFNDATE"], context) : null) : null;
        context["field"] = "STRMLFNTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["STRMLFNTIME"] : null);
        privateState.STRMLFNTIME = defaultValues ? (defaultValues["STRMLFNTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STRMLFNTIME"], context) : null) : null;
        context["field"] = "STRML_DATE_TIME";
        context["metadata"] = (objectMetadata ? objectMetadata["STRML_DATE_TIME"] : null);
        privateState.STRML_DATE_TIME = defaultValues ? (defaultValues["STRML_DATE_TIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STRML_DATE_TIME"], context) : null) : null;
        context["field"] = "SUB_NUMBER";
        context["metadata"] = (objectMetadata ? objectMetadata["SUB_NUMBER"] : null);
        privateState.SUB_NUMBER = defaultValues ? (defaultValues["SUB_NUMBER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SUB_NUMBER"], context) : null) : null;
        context["field"] = "SYS_STATUS";
        context["metadata"] = (objectMetadata ? objectMetadata["SYS_STATUS"] : null);
        privateState.SYS_STATUS = defaultValues ? (defaultValues["SYS_STATUS"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["SYS_STATUS"], context) : null) : null;
        context["field"] = "TECH_OBJ_DESC";
        context["metadata"] = (objectMetadata ? objectMetadata["TECH_OBJ_DESC"] : null);
        privateState.TECH_OBJ_DESC = defaultValues ? (defaultValues["TECH_OBJ_DESC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TECH_OBJ_DESC"], context) : null) : null;
        context["field"] = "TEXT_LENGTH";
        context["metadata"] = (objectMetadata ? objectMetadata["TEXT_LENGTH"] : null);
        privateState.TEXT_LENGTH = defaultValues ? (defaultValues["TEXT_LENGTH"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TEXT_LENGTH"], context) : null) : null;
        context["field"] = "TIMESTAMP";
        context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
        privateState.TIMESTAMP = defaultValues ? (defaultValues["TIMESTAMP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TIMESTAMP"], context) : null) : null;
        context["field"] = "TIME_ZONE";
        context["metadata"] = (objectMetadata ? objectMetadata["TIME_ZONE"] : null);
        privateState.TIME_ZONE = defaultValues ? (defaultValues["TIME_ZONE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TIME_ZONE"], context) : null) : null;
        context["field"] = "UNIT";
        context["metadata"] = (objectMetadata ? objectMetadata["UNIT"] : null);
        privateState.UNIT = defaultValues ? (defaultValues["UNIT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["UNIT"], context) : null) : null;
        context["field"] = "USERID";
        context["metadata"] = (objectMetadata ? objectMetadata["USERID"] : null);
        privateState.USERID = defaultValues ? (defaultValues["USERID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["USERID"], context) : null) : null;
        context["field"] = "USERSTATUS_TXT";
        context["metadata"] = (objectMetadata ? objectMetadata["USERSTATUS_TXT"] : null);
        privateState.USERSTATUS_TXT = defaultValues ? (defaultValues["USERSTATUS_TXT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["USERSTATUS_TXT"], context) : null) : null;
        context["field"] = "USER_ST";
        context["metadata"] = (objectMetadata ? objectMetadata["USER_ST"] : null);
        privateState.USER_ST = defaultValues ? (defaultValues["USER_ST"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["USER_ST"], context) : null) : null;
        context["field"] = "USER_STATUS";
        context["metadata"] = (objectMetadata ? objectMetadata["USER_STATUS"] : null);
        privateState.USER_STATUS = defaultValues ? (defaultValues["USER_STATUS"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["USER_STATUS"], context) : null) : null;
        context["field"] = "WBS_ELEMENT";
        context["metadata"] = (objectMetadata ? objectMetadata["WBS_ELEMENT"] : null);
        privateState.WBS_ELEMENT = defaultValues ? (defaultValues["WBS_ELEMENT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["WBS_ELEMENT"], context) : null) : null;
        context["field"] = "WC_SHORT_DESC";
        context["metadata"] = (objectMetadata ? objectMetadata["WC_SHORT_DESC"] : null);
        privateState.WC_SHORT_DESC = defaultValues ? (defaultValues["WC_SHORT_DESC"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["WC_SHORT_DESC"], context) : null) : null;
        context["field"] = "WORK_CENTER";
        context["metadata"] = (objectMetadata ? objectMetadata["WORK_CENTER"] : null);
        privateState.WORK_CENTER = defaultValues ? (defaultValues["WORK_CENTER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["WORK_CENTER"], context) : null) : null;
        context["field"] = "WRRNTY_END_DT";
        context["metadata"] = (objectMetadata ? objectMetadata["WRRNTY_END_DT"] : null);
        privateState.WRRNTY_END_DT = defaultValues ? (defaultValues["WRRNTY_END_DT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["WRRNTY_END_DT"], context) : null) : null;
        context["field"] = "WRRNTY_START_DT";
        context["metadata"] = (objectMetadata ? objectMetadata["WRRNTY_START_DT"] : null);
        privateState.WRRNTY_START_DT = defaultValues ? (defaultValues["WRRNTY_START_DT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["WRRNTY_START_DT"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "ABCINDIC": {
                get: function() {
                    context["field"] = "ABCINDIC";
                    context["metadata"] = (objectMetadata ? objectMetadata["ABCINDIC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ABCINDIC, context);
                },
                set: function(val) {
                    setterFunctions['ABCINDIC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ACCEPTED": {
                get: function() {
                    context["field"] = "ACCEPTED";
                    context["metadata"] = (objectMetadata ? objectMetadata["ACCEPTED"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ACCEPTED, context);
                },
                set: function(val) {
                    setterFunctions['ACCEPTED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ADDR_NO_LOC": {
                get: function() {
                    context["field"] = "ADDR_NO_LOC";
                    context["metadata"] = (objectMetadata ? objectMetadata["ADDR_NO_LOC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ADDR_NO_LOC, context);
                },
                set: function(val) {
                    setterFunctions['ADDR_NO_LOC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ADDR_NUMBER": {
                get: function() {
                    context["field"] = "ADDR_NUMBER";
                    context["metadata"] = (objectMetadata ? objectMetadata["ADDR_NUMBER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ADDR_NUMBER, context);
                },
                set: function(val) {
                    setterFunctions['ADDR_NUMBER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ASSEMBLY": {
                get: function() {
                    context["field"] = "ASSEMBLY";
                    context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ASSEMBLY, context);
                },
                set: function(val) {
                    setterFunctions['ASSEMBLY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ASSEMBLY_EXT": {
                get: function() {
                    context["field"] = "ASSEMBLY_EXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_EXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ASSEMBLY_EXT, context);
                },
                set: function(val) {
                    setterFunctions['ASSEMBLY_EXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ASSEMBLY_GUID": {
                get: function() {
                    context["field"] = "ASSEMBLY_GUID";
                    context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_GUID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ASSEMBLY_GUID, context);
                },
                set: function(val) {
                    setterFunctions['ASSEMBLY_GUID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ASSEMBLY_VERSION": {
                get: function() {
                    context["field"] = "ASSEMBLY_VERSION";
                    context["metadata"] = (objectMetadata ? objectMetadata["ASSEMBLY_VERSION"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ASSEMBLY_VERSION, context);
                },
                set: function(val) {
                    setterFunctions['ASSEMBLY_VERSION'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ASSET_NO": {
                get: function() {
                    context["field"] = "ASSET_NO";
                    context["metadata"] = (objectMetadata ? objectMetadata["ASSET_NO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ASSET_NO, context);
                },
                set: function(val) {
                    setterFunctions['ASSET_NO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "BREAKDOWN": {
                get: function() {
                    context["field"] = "BREAKDOWN";
                    context["metadata"] = (objectMetadata ? objectMetadata["BREAKDOWN"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.BREAKDOWN, context);
                },
                set: function(val) {
                    setterFunctions['BREAKDOWN'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "BUS_AREA": {
                get: function() {
                    context["field"] = "BUS_AREA";
                    context["metadata"] = (objectMetadata ? objectMetadata["BUS_AREA"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.BUS_AREA, context);
                },
                set: function(val) {
                    setterFunctions['BUS_AREA'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CATALOG_PROFILE": {
                get: function() {
                    context["field"] = "CATALOG_PROFILE";
                    context["metadata"] = (objectMetadata ? objectMetadata["CATALOG_PROFILE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CATALOG_PROFILE, context);
                },
                set: function(val) {
                    setterFunctions['CATALOG_PROFILE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CAT_TYPE": {
                get: function() {
                    context["field"] = "CAT_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["CAT_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CAT_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['CAT_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CAUSE_CODE": {
                get: function() {
                    context["field"] = "CAUSE_CODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["CAUSE_CODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CAUSE_CODE, context);
                },
                set: function(val) {
                    setterFunctions['CAUSE_CODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CHANGED_AT": {
                get: function() {
                    context["field"] = "CHANGED_AT";
                    context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_AT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CHANGED_AT, context);
                },
                set: function(val) {
                    setterFunctions['CHANGED_AT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CHANGED_BY": {
                get: function() {
                    context["field"] = "CHANGED_BY";
                    context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_BY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CHANGED_BY, context);
                },
                set: function(val) {
                    setterFunctions['CHANGED_BY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CHANGED_ON": {
                get: function() {
                    context["field"] = "CHANGED_ON";
                    context["metadata"] = (objectMetadata ? objectMetadata["CHANGED_ON"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CHANGED_ON, context);
                },
                set: function(val) {
                    setterFunctions['CHANGED_ON'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CODE_GRP_CAUSE": {
                get: function() {
                    context["field"] = "CODE_GRP_CAUSE";
                    context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_CAUSE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CODE_GRP_CAUSE, context);
                },
                set: function(val) {
                    setterFunctions['CODE_GRP_CAUSE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CODE_GRP_CODING": {
                get: function() {
                    context["field"] = "CODE_GRP_CODING";
                    context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_CODING"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CODE_GRP_CODING, context);
                },
                set: function(val) {
                    setterFunctions['CODE_GRP_CODING'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CODE_GRP_PART": {
                get: function() {
                    context["field"] = "CODE_GRP_PART";
                    context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_PART"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CODE_GRP_PART, context);
                },
                set: function(val) {
                    setterFunctions['CODE_GRP_PART'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CODE_GRP_PROBLEM": {
                get: function() {
                    context["field"] = "CODE_GRP_PROBLEM";
                    context["metadata"] = (objectMetadata ? objectMetadata["CODE_GRP_PROBLEM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CODE_GRP_PROBLEM, context);
                },
                set: function(val) {
                    setterFunctions['CODE_GRP_PROBLEM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CODING_CODE": {
                get: function() {
                    context["field"] = "CODING_CODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["CODING_CODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CODING_CODE, context);
                },
                set: function(val) {
                    setterFunctions['CODING_CODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "COMPTIME": {
                get: function() {
                    context["field"] = "COMPTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["COMPTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.COMPTIME, context);
                },
                set: function(val) {
                    setterFunctions['COMPTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "COMP_CODE": {
                get: function() {
                    context["field"] = "COMP_CODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["COMP_CODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.COMP_CODE, context);
                },
                set: function(val) {
                    setterFunctions['COMP_CODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CONVERT_TO_WO": {
                get: function() {
                    context["field"] = "CONVERT_TO_WO";
                    context["metadata"] = (objectMetadata ? objectMetadata["CONVERT_TO_WO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CONVERT_TO_WO, context);
                },
                set: function(val) {
                    setterFunctions['CONVERT_TO_WO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "COSTCENTER": {
                get: function() {
                    context["field"] = "COSTCENTER";
                    context["metadata"] = (objectMetadata ? objectMetadata["COSTCENTER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.COSTCENTER, context);
                },
                set: function(val) {
                    setterFunctions['COSTCENTER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CO_AREA": {
                get: function() {
                    context["field"] = "CO_AREA";
                    context["metadata"] = (objectMetadata ? objectMetadata["CO_AREA"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CO_AREA, context);
                },
                set: function(val) {
                    setterFunctions['CO_AREA'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CREATED_AT": {
                get: function() {
                    context["field"] = "CREATED_AT";
                    context["metadata"] = (objectMetadata ? objectMetadata["CREATED_AT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CREATED_AT, context);
                },
                set: function(val) {
                    setterFunctions['CREATED_AT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CREATED_BY": {
                get: function() {
                    context["field"] = "CREATED_BY";
                    context["metadata"] = (objectMetadata ? objectMetadata["CREATED_BY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CREATED_BY, context);
                },
                set: function(val) {
                    setterFunctions['CREATED_BY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CREATED_ON": {
                get: function() {
                    context["field"] = "CREATED_ON";
                    context["metadata"] = (objectMetadata ? objectMetadata["CREATED_ON"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CREATED_ON, context);
                },
                set: function(val) {
                    setterFunctions['CREATED_ON'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CUST_NO": {
                get: function() {
                    context["field"] = "CUST_NO";
                    context["metadata"] = (objectMetadata ? objectMetadata["CUST_NO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CUST_NO, context);
                },
                set: function(val) {
                    setterFunctions['CUST_NO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETE_FLAG": {
                get: function() {
                    context["field"] = "DELETE_FLAG";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETE_FLAG"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETE_FLAG, context);
                },
                set: function(val) {
                    setterFunctions['DELETE_FLAG'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETE_IND": {
                get: function() {
                    context["field"] = "DELETE_IND";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETE_IND, context);
                },
                set: function(val) {
                    setterFunctions['DELETE_IND'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESENDDATE": {
                get: function() {
                    context["field"] = "DESENDDATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESENDDATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESENDDATE, context);
                },
                set: function(val) {
                    setterFunctions['DESENDDATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESENDTM": {
                get: function() {
                    context["field"] = "DESENDTM";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESENDTM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESENDTM, context);
                },
                set: function(val) {
                    setterFunctions['DESENDTM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESEN_DATE_TIME": {
                get: function() {
                    context["field"] = "DESEN_DATE_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESEN_DATE_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESEN_DATE_TIME, context);
                },
                set: function(val) {
                    setterFunctions['DESEN_DATE_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESSTDATE": {
                get: function() {
                    context["field"] = "DESSTDATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESSTDATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESSTDATE, context);
                },
                set: function(val) {
                    setterFunctions['DESSTDATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESSTTIME": {
                get: function() {
                    context["field"] = "DESSTTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESSTTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESSTTIME, context);
                },
                set: function(val) {
                    setterFunctions['DESSTTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESST_DATE_TIME": {
                get: function() {
                    context["field"] = "DESST_DATE_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESST_DATE_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESST_DATE_TIME, context);
                },
                set: function(val) {
                    setterFunctions['DESST_DATE_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DEVICEDATA": {
                get: function() {
                    context["field"] = "DEVICEDATA";
                    context["metadata"] = (objectMetadata ? objectMetadata["DEVICEDATA"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DEVICEDATA, context);
                },
                set: function(val) {
                    setterFunctions['DEVICEDATA'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DISTR_CHAN": {
                get: function() {
                    context["field"] = "DISTR_CHAN";
                    context["metadata"] = (objectMetadata ? objectMetadata["DISTR_CHAN"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DISTR_CHAN, context);
                },
                set: function(val) {
                    setterFunctions['DISTR_CHAN'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DIST_CHAN_LOC": {
                get: function() {
                    context["field"] = "DIST_CHAN_LOC";
                    context["metadata"] = (objectMetadata ? objectMetadata["DIST_CHAN_LOC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DIST_CHAN_LOC, context);
                },
                set: function(val) {
                    setterFunctions['DIST_CHAN_LOC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DIVISION": {
                get: function() {
                    context["field"] = "DIVISION";
                    context["metadata"] = (objectMetadata ? objectMetadata["DIVISION"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DIVISION, context);
                },
                set: function(val) {
                    setterFunctions['DIVISION'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DIVISION_LOC": {
                get: function() {
                    context["field"] = "DIVISION_LOC";
                    context["metadata"] = (objectMetadata ? objectMetadata["DIVISION_LOC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DIVISION_LOC, context);
                },
                set: function(val) {
                    setterFunctions['DIVISION_LOC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DOC_NUMBER": {
                get: function() {
                    context["field"] = "DOC_NUMBER";
                    context["metadata"] = (objectMetadata ? objectMetadata["DOC_NUMBER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DOC_NUMBER, context);
                },
                set: function(val) {
                    setterFunctions['DOC_NUMBER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DOWNTIME": {
                get: function() {
                    context["field"] = "DOWNTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["DOWNTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DOWNTIME, context);
                },
                set: function(val) {
                    setterFunctions['DOWNTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ENDMLFNDATE": {
                get: function() {
                    context["field"] = "ENDMLFNDATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["ENDMLFNDATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ENDMLFNDATE, context);
                },
                set: function(val) {
                    setterFunctions['ENDMLFNDATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ENDMLFNTIME": {
                get: function() {
                    context["field"] = "ENDMLFNTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["ENDMLFNTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ENDMLFNTIME, context);
                },
                set: function(val) {
                    setterFunctions['ENDMLFNTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ENDML_DATE_TIME": {
                get: function() {
                    context["field"] = "ENDML_DATE_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["ENDML_DATE_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ENDML_DATE_TIME, context);
                },
                set: function(val) {
                    setterFunctions['ENDML_DATE_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "END_POINT": {
                get: function() {
                    context["field"] = "END_POINT";
                    context["metadata"] = (objectMetadata ? objectMetadata["END_POINT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.END_POINT, context);
                },
                set: function(val) {
                    setterFunctions['END_POINT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "EQUIP_NUM": {
                get: function() {
                    context["field"] = "EQUIP_NUM";
                    context["metadata"] = (objectMetadata ? objectMetadata["EQUIP_NUM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.EQUIP_NUM, context);
                },
                set: function(val) {
                    setterFunctions['EQUIP_NUM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "FLOCN_DESC": {
                get: function() {
                    context["field"] = "FLOCN_DESC";
                    context["metadata"] = (objectMetadata ? objectMetadata["FLOCN_DESC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.FLOCN_DESC, context);
                },
                set: function(val) {
                    setterFunctions['FLOCN_DESC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "FUNC_LOCATION": {
                get: function() {
                    context["field"] = "FUNC_LOCATION";
                    context["metadata"] = (objectMetadata ? objectMetadata["FUNC_LOCATION"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.FUNC_LOCATION, context);
                },
                set: function(val) {
                    setterFunctions['FUNC_LOCATION'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "INTERNAL_NUMBER": {
                get: function() {
                    context["field"] = "INTERNAL_NUMBER";
                    context["metadata"] = (objectMetadata ? objectMetadata["INTERNAL_NUMBER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.INTERNAL_NUMBER, context);
                },
                set: function(val) {
                    setterFunctions['INTERNAL_NUMBER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ISOCODE_UNIT": {
                get: function() {
                    context["field"] = "ISOCODE_UNIT";
                    context["metadata"] = (objectMetadata ? objectMetadata["ISOCODE_UNIT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ISOCODE_UNIT, context);
                },
                set: function(val) {
                    setterFunctions['ISOCODE_UNIT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ITM_NUMBER": {
                get: function() {
                    context["field"] = "ITM_NUMBER";
                    context["metadata"] = (objectMetadata ? objectMetadata["ITM_NUMBER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ITM_NUMBER, context);
                },
                set: function(val) {
                    setterFunctions['ITM_NUMBER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LINEAR_LENGTH": {
                get: function() {
                    context["field"] = "LINEAR_LENGTH";
                    context["metadata"] = (objectMetadata ? objectMetadata["LINEAR_LENGTH"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LINEAR_LENGTH, context);
                },
                set: function(val) {
                    setterFunctions['LINEAR_LENGTH'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LINEAR_UNIT": {
                get: function() {
                    context["field"] = "LINEAR_UNIT";
                    context["metadata"] = (objectMetadata ? objectMetadata["LINEAR_UNIT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LINEAR_UNIT, context);
                },
                set: function(val) {
                    setterFunctions['LINEAR_UNIT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LOC_ACC": {
                get: function() {
                    context["field"] = "LOC_ACC";
                    context["metadata"] = (objectMetadata ? objectMetadata["LOC_ACC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LOC_ACC, context);
                },
                set: function(val) {
                    setterFunctions['LOC_ACC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LONG_TEXT": {
                get: function() {
                    context["field"] = "LONG_TEXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["LONG_TEXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LONG_TEXT, context);
                },
                set: function(val) {
                    setterFunctions['LONG_TEXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LRPID": {
                get: function() {
                    context["field"] = "LRPID";
                    context["metadata"] = (objectMetadata ? objectMetadata["LRPID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LRPID, context);
                },
                set: function(val) {
                    setterFunctions['LRPID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "LTEXT": {
                get: function() {
                    context["field"] = "LTEXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["LTEXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.LTEXT, context);
                },
                set: function(val) {
                    setterFunctions['LTEXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MAINTITEM": {
                get: function() {
                    context["field"] = "MAINTITEM";
                    context["metadata"] = (objectMetadata ? objectMetadata["MAINTITEM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MAINTITEM, context);
                },
                set: function(val) {
                    setterFunctions['MAINTITEM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MAINTLOC": {
                get: function() {
                    context["field"] = "MAINTLOC";
                    context["metadata"] = (objectMetadata ? objectMetadata["MAINTLOC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MAINTLOC, context);
                },
                set: function(val) {
                    setterFunctions['MAINTLOC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MAINTPLANT": {
                get: function() {
                    context["field"] = "MAINTPLANT";
                    context["metadata"] = (objectMetadata ? objectMetadata["MAINTPLANT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MAINTPLANT, context);
                },
                set: function(val) {
                    setterFunctions['MAINTPLANT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MAINTROOM": {
                get: function() {
                    context["field"] = "MAINTROOM";
                    context["metadata"] = (objectMetadata ? objectMetadata["MAINTROOM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MAINTROOM, context);
                },
                set: function(val) {
                    setterFunctions['MAINTROOM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MANU_WRRNTY_ENDT": {
                get: function() {
                    context["field"] = "MANU_WRRNTY_ENDT";
                    context["metadata"] = (objectMetadata ? objectMetadata["MANU_WRRNTY_ENDT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MANU_WRRNTY_ENDT, context);
                },
                set: function(val) {
                    setterFunctions['MANU_WRRNTY_ENDT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MANU_WRRNTY_STDT": {
                get: function() {
                    context["field"] = "MANU_WRRNTY_STDT";
                    context["metadata"] = (objectMetadata ? objectMetadata["MANU_WRRNTY_STDT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MANU_WRRNTY_STDT, context);
                },
                set: function(val) {
                    setterFunctions['MANU_WRRNTY_STDT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MARKER_DIST_END": {
                get: function() {
                    context["field"] = "MARKER_DIST_END";
                    context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_END"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MARKER_DIST_END, context);
                },
                set: function(val) {
                    setterFunctions['MARKER_DIST_END'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MARKER_DIST_STA": {
                get: function() {
                    context["field"] = "MARKER_DIST_STA";
                    context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_STA"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MARKER_DIST_STA, context);
                },
                set: function(val) {
                    setterFunctions['MARKER_DIST_STA'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MARKER_DIST_UNIT": {
                get: function() {
                    context["field"] = "MARKER_DIST_UNIT";
                    context["metadata"] = (objectMetadata ? objectMetadata["MARKER_DIST_UNIT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MARKER_DIST_UNIT, context);
                },
                set: function(val) {
                    setterFunctions['MARKER_DIST_UNIT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MARKER_END": {
                get: function() {
                    context["field"] = "MARKER_END";
                    context["metadata"] = (objectMetadata ? objectMetadata["MARKER_END"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MARKER_END, context);
                },
                set: function(val) {
                    setterFunctions['MARKER_END'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MARKER_START": {
                get: function() {
                    context["field"] = "MARKER_START";
                    context["metadata"] = (objectMetadata ? objectMetadata["MARKER_START"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MARKER_START, context);
                },
                set: function(val) {
                    setterFunctions['MARKER_START'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MASTER_WRRNTY_NO": {
                get: function() {
                    context["field"] = "MASTER_WRRNTY_NO";
                    context["metadata"] = (objectMetadata ? objectMetadata["MASTER_WRRNTY_NO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MASTER_WRRNTY_NO, context);
                },
                set: function(val) {
                    setterFunctions['MASTER_WRRNTY_NO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MATERIAL": {
                get: function() {
                    context["field"] = "MATERIAL";
                    context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MATERIAL, context);
                },
                set: function(val) {
                    setterFunctions['MATERIAL'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MATERIAL_EXT": {
                get: function() {
                    context["field"] = "MATERIAL_EXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_EXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MATERIAL_EXT, context);
                },
                set: function(val) {
                    setterFunctions['MATERIAL_EXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MATERIAL_GUID": {
                get: function() {
                    context["field"] = "MATERIAL_GUID";
                    context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_GUID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MATERIAL_GUID, context);
                },
                set: function(val) {
                    setterFunctions['MATERIAL_GUID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MATERIAL_VERSION": {
                get: function() {
                    context["field"] = "MATERIAL_VERSION";
                    context["metadata"] = (objectMetadata ? objectMetadata["MATERIAL_VERSION"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MATERIAL_VERSION, context);
                },
                set: function(val) {
                    setterFunctions['MATERIAL_VERSION'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MNTCALL_NO": {
                get: function() {
                    context["field"] = "MNTCALL_NO";
                    context["metadata"] = (objectMetadata ? objectMetadata["MNTCALL_NO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MNTCALL_NO, context);
                },
                set: function(val) {
                    setterFunctions['MNTCALL_NO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "MNTPLAN": {
                get: function() {
                    context["field"] = "MNTPLAN";
                    context["metadata"] = (objectMetadata ? objectMetadata["MNTPLAN"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.MNTPLAN, context);
                },
                set: function(val) {
                    setterFunctions['MNTPLAN'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTF_REP_PER_NAM": {
                get: function() {
                    context["field"] = "NOTF_REP_PER_NAM";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTF_REP_PER_NAM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTF_REP_PER_NAM, context);
                },
                set: function(val) {
                    setterFunctions['NOTF_REP_PER_NAM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIFTMEZ": {
                get: function() {
                    context["field"] = "NOTIFTMEZ";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIFTMEZ"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIFTMEZ, context);
                },
                set: function(val) {
                    setterFunctions['NOTIFTMEZ'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIF_DATE": {
                get: function() {
                    context["field"] = "NOTIF_DATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_DATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIF_DATE, context);
                },
                set: function(val) {
                    setterFunctions['NOTIF_DATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIF_DATE_TIME": {
                get: function() {
                    context["field"] = "NOTIF_DATE_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_DATE_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIF_DATE_TIME, context);
                },
                set: function(val) {
                    setterFunctions['NOTIF_DATE_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIF_NUM": {
                get: function() {
                    context["field"] = "NOTIF_NUM";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_NUM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIF_NUM, context);
                },
                set: function(val) {
                    setterFunctions['NOTIF_NUM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIF_TIME": {
                get: function() {
                    context["field"] = "NOTIF_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIF_TIME, context);
                },
                set: function(val) {
                    setterFunctions['NOTIF_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIF_TYPE": {
                get: function() {
                    context["field"] = "NOTIF_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIF_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['NOTIF_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OBJECT_NO": {
                get: function() {
                    context["field"] = "OBJECT_NO";
                    context["metadata"] = (objectMetadata ? objectMetadata["OBJECT_NO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OBJECT_NO, context);
                },
                set: function(val) {
                    setterFunctions['OBJECT_NO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OFFSET1_TYPE": {
                get: function() {
                    context["field"] = "OFFSET1_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OFFSET1_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['OFFSET1_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OFFSET1_UNIT": {
                get: function() {
                    context["field"] = "OFFSET1_UNIT";
                    context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_UNIT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OFFSET1_UNIT, context);
                },
                set: function(val) {
                    setterFunctions['OFFSET1_UNIT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OFFSET1_VALUE": {
                get: function() {
                    context["field"] = "OFFSET1_VALUE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OFFSET1_VALUE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OFFSET1_VALUE, context);
                },
                set: function(val) {
                    setterFunctions['OFFSET1_VALUE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OFFSET2_TYPE": {
                get: function() {
                    context["field"] = "OFFSET2_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OFFSET2_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['OFFSET2_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OFFSET2_UNIT": {
                get: function() {
                    context["field"] = "OFFSET2_UNIT";
                    context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_UNIT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OFFSET2_UNIT, context);
                },
                set: function(val) {
                    setterFunctions['OFFSET2_UNIT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OFFSET2_VALUE": {
                get: function() {
                    context["field"] = "OFFSET2_VALUE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OFFSET2_VALUE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OFFSET2_VALUE, context);
                },
                set: function(val) {
                    setterFunctions['OFFSET2_VALUE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OPMODE": {
                get: function() {
                    context["field"] = "OPMODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OPMODE, context);
                },
                set: function(val) {
                    setterFunctions['OPMODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ORDER_NUM": {
                get: function() {
                    context["field"] = "ORDER_NUM";
                    context["metadata"] = (objectMetadata ? objectMetadata["ORDER_NUM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ORDER_NUM, context);
                },
                set: function(val) {
                    setterFunctions['ORDER_NUM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ORDER_TEXT": {
                get: function() {
                    context["field"] = "ORDER_TEXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["ORDER_TEXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ORDER_TEXT, context);
                },
                set: function(val) {
                    setterFunctions['ORDER_TEXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ORDER_TYPE": {
                get: function() {
                    context["field"] = "ORDER_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["ORDER_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ORDER_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['ORDER_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PART_OBJECT": {
                get: function() {
                    context["field"] = "PART_OBJECT";
                    context["metadata"] = (objectMetadata ? objectMetadata["PART_OBJECT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PART_OBJECT, context);
                },
                set: function(val) {
                    setterFunctions['PART_OBJECT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PLANGROUP": {
                get: function() {
                    context["field"] = "PLANGROUP";
                    context["metadata"] = (objectMetadata ? objectMetadata["PLANGROUP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PLANGROUP, context);
                },
                set: function(val) {
                    setterFunctions['PLANGROUP'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PLANPLANT": {
                get: function() {
                    context["field"] = "PLANPLANT";
                    context["metadata"] = (objectMetadata ? objectMetadata["PLANPLANT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PLANPLANT, context);
                },
                set: function(val) {
                    setterFunctions['PLANPLANT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PLSECTN": {
                get: function() {
                    context["field"] = "PLSECTN";
                    context["metadata"] = (objectMetadata ? objectMetadata["PLSECTN"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PLSECTN, context);
                },
                set: function(val) {
                    setterFunctions['PLSECTN'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PM_WKCTR": {
                get: function() {
                    context["field"] = "PM_WKCTR";
                    context["metadata"] = (objectMetadata ? objectMetadata["PM_WKCTR"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PM_WKCTR, context);
                },
                set: function(val) {
                    setterFunctions['PM_WKCTR'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PP_WKCTR": {
                get: function() {
                    context["field"] = "PP_WKCTR";
                    context["metadata"] = (objectMetadata ? objectMetadata["PP_WKCTR"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PP_WKCTR, context);
                },
                set: function(val) {
                    setterFunctions['PP_WKCTR'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PRILANG": {
                get: function() {
                    context["field"] = "PRILANG";
                    context["metadata"] = (objectMetadata ? objectMetadata["PRILANG"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PRILANG, context);
                },
                set: function(val) {
                    setterFunctions['PRILANG'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PRIORITY": {
                get: function() {
                    context["field"] = "PRIORITY";
                    context["metadata"] = (objectMetadata ? objectMetadata["PRIORITY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PRIORITY, context);
                },
                set: function(val) {
                    setterFunctions['PRIORITY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PRIORITY_TYPE": {
                get: function() {
                    context["field"] = "PRIORITY_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["PRIORITY_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PRIORITY_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['PRIORITY_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PROBLEM": {
                get: function() {
                    context["field"] = "PROBLEM";
                    context["metadata"] = (objectMetadata ? objectMetadata["PROBLEM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PROBLEM, context);
                },
                set: function(val) {
                    setterFunctions['PROBLEM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PROBLEM_TEXT": {
                get: function() {
                    context["field"] = "PROBLEM_TEXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["PROBLEM_TEXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PROBLEM_TEXT, context);
                },
                set: function(val) {
                    setterFunctions['PROBLEM_TEXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PURCH_DATE": {
                get: function() {
                    context["field"] = "PURCH_DATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["PURCH_DATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PURCH_DATE, context);
                },
                set: function(val) {
                    setterFunctions['PURCH_DATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PURCH_NO_C": {
                get: function() {
                    context["field"] = "PURCH_NO_C";
                    context["metadata"] = (objectMetadata ? objectMetadata["PURCH_NO_C"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PURCH_NO_C, context);
                },
                set: function(val) {
                    setterFunctions['PURCH_NO_C'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "REFDATE": {
                get: function() {
                    context["field"] = "REFDATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["REFDATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.REFDATE, context);
                },
                set: function(val) {
                    setterFunctions['REFDATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "REFTIME": {
                get: function() {
                    context["field"] = "REFTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["REFTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.REFTIME, context);
                },
                set: function(val) {
                    setterFunctions['REFTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "REF_DATE_TIME": {
                get: function() {
                    context["field"] = "REF_DATE_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["REF_DATE_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.REF_DATE_TIME, context);
                },
                set: function(val) {
                    setterFunctions['REF_DATE_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "REJECTED": {
                get: function() {
                    context["field"] = "REJECTED";
                    context["metadata"] = (objectMetadata ? objectMetadata["REJECTED"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.REJECTED, context);
                },
                set: function(val) {
                    setterFunctions['REJECTED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SALES_GRP": {
                get: function() {
                    context["field"] = "SALES_GRP";
                    context["metadata"] = (objectMetadata ? objectMetadata["SALES_GRP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SALES_GRP, context);
                },
                set: function(val) {
                    setterFunctions['SALES_GRP'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SALES_OFFICE": {
                get: function() {
                    context["field"] = "SALES_OFFICE";
                    context["metadata"] = (objectMetadata ? objectMetadata["SALES_OFFICE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SALES_OFFICE, context);
                },
                set: function(val) {
                    setterFunctions['SALES_OFFICE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SALES_ORD": {
                get: function() {
                    context["field"] = "SALES_ORD";
                    context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORD"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SALES_ORD, context);
                },
                set: function(val) {
                    setterFunctions['SALES_ORD'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SALES_ORG": {
                get: function() {
                    context["field"] = "SALES_ORG";
                    context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORG"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SALES_ORG, context);
                },
                set: function(val) {
                    setterFunctions['SALES_ORG'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SALES_ORG_LOC": {
                get: function() {
                    context["field"] = "SALES_ORG_LOC";
                    context["metadata"] = (objectMetadata ? objectMetadata["SALES_ORG_LOC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SALES_ORG_LOC, context);
                },
                set: function(val) {
                    setterFunctions['SALES_ORG_LOC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SCENARIO": {
                get: function() {
                    context["field"] = "SCENARIO";
                    context["metadata"] = (objectMetadata ? objectMetadata["SCENARIO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SCENARIO, context);
                },
                set: function(val) {
                    setterFunctions['SCENARIO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SERIALNO": {
                get: function() {
                    context["field"] = "SERIALNO";
                    context["metadata"] = (objectMetadata ? objectMetadata["SERIALNO"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SERIALNO, context);
                },
                set: function(val) {
                    setterFunctions['SERIALNO'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SERVER_GROUP": {
                get: function() {
                    context["field"] = "SERVER_GROUP";
                    context["metadata"] = (objectMetadata ? objectMetadata["SERVER_GROUP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SERVER_GROUP, context);
                },
                set: function(val) {
                    setterFunctions['SERVER_GROUP'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SERVER_ID": {
                get: function() {
                    context["field"] = "SERVER_ID";
                    context["metadata"] = (objectMetadata ? objectMetadata["SERVER_ID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SERVER_ID, context);
                },
                set: function(val) {
                    setterFunctions['SERVER_ID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SHORT_TEXT": {
                get: function() {
                    context["field"] = "SHORT_TEXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["SHORT_TEXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SHORT_TEXT, context);
                },
                set: function(val) {
                    setterFunctions['SHORT_TEXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SORTFIELD": {
                get: function() {
                    context["field"] = "SORTFIELD";
                    context["metadata"] = (objectMetadata ? objectMetadata["SORTFIELD"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SORTFIELD, context);
                },
                set: function(val) {
                    setterFunctions['SORTFIELD'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "START_POINT": {
                get: function() {
                    context["field"] = "START_POINT";
                    context["metadata"] = (objectMetadata ? objectMetadata["START_POINT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.START_POINT, context);
                },
                set: function(val) {
                    setterFunctions['START_POINT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STAT_PROF": {
                get: function() {
                    context["field"] = "STAT_PROF";
                    context["metadata"] = (objectMetadata ? objectMetadata["STAT_PROF"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STAT_PROF, context);
                },
                set: function(val) {
                    setterFunctions['STAT_PROF'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STDGORD": {
                get: function() {
                    context["field"] = "STDGORD";
                    context["metadata"] = (objectMetadata ? objectMetadata["STDGORD"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STDGORD, context);
                },
                set: function(val) {
                    setterFunctions['STDGORD'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STLMTORDER": {
                get: function() {
                    context["field"] = "STLMTORDER";
                    context["metadata"] = (objectMetadata ? objectMetadata["STLMTORDER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STLMTORDER, context);
                },
                set: function(val) {
                    setterFunctions['STLMTORDER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STRMLFNDATE": {
                get: function() {
                    context["field"] = "STRMLFNDATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["STRMLFNDATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STRMLFNDATE, context);
                },
                set: function(val) {
                    setterFunctions['STRMLFNDATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STRMLFNTIME": {
                get: function() {
                    context["field"] = "STRMLFNTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["STRMLFNTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STRMLFNTIME, context);
                },
                set: function(val) {
                    setterFunctions['STRMLFNTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STRML_DATE_TIME": {
                get: function() {
                    context["field"] = "STRML_DATE_TIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["STRML_DATE_TIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STRML_DATE_TIME, context);
                },
                set: function(val) {
                    setterFunctions['STRML_DATE_TIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SUB_NUMBER": {
                get: function() {
                    context["field"] = "SUB_NUMBER";
                    context["metadata"] = (objectMetadata ? objectMetadata["SUB_NUMBER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SUB_NUMBER, context);
                },
                set: function(val) {
                    setterFunctions['SUB_NUMBER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "SYS_STATUS": {
                get: function() {
                    context["field"] = "SYS_STATUS";
                    context["metadata"] = (objectMetadata ? objectMetadata["SYS_STATUS"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.SYS_STATUS, context);
                },
                set: function(val) {
                    setterFunctions['SYS_STATUS'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TECH_OBJ_DESC": {
                get: function() {
                    context["field"] = "TECH_OBJ_DESC";
                    context["metadata"] = (objectMetadata ? objectMetadata["TECH_OBJ_DESC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TECH_OBJ_DESC, context);
                },
                set: function(val) {
                    setterFunctions['TECH_OBJ_DESC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TEXT_LENGTH": {
                get: function() {
                    context["field"] = "TEXT_LENGTH";
                    context["metadata"] = (objectMetadata ? objectMetadata["TEXT_LENGTH"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TEXT_LENGTH, context);
                },
                set: function(val) {
                    setterFunctions['TEXT_LENGTH'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TIMESTAMP": {
                get: function() {
                    context["field"] = "TIMESTAMP";
                    context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TIMESTAMP, context);
                },
                set: function(val) {
                    setterFunctions['TIMESTAMP'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TIME_ZONE": {
                get: function() {
                    context["field"] = "TIME_ZONE";
                    context["metadata"] = (objectMetadata ? objectMetadata["TIME_ZONE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TIME_ZONE, context);
                },
                set: function(val) {
                    setterFunctions['TIME_ZONE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "UNIT": {
                get: function() {
                    context["field"] = "UNIT";
                    context["metadata"] = (objectMetadata ? objectMetadata["UNIT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.UNIT, context);
                },
                set: function(val) {
                    setterFunctions['UNIT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "USERID": {
                get: function() {
                    context["field"] = "USERID";
                    context["metadata"] = (objectMetadata ? objectMetadata["USERID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.USERID, context);
                },
                set: function(val) {
                    setterFunctions['USERID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "USERSTATUS_TXT": {
                get: function() {
                    context["field"] = "USERSTATUS_TXT";
                    context["metadata"] = (objectMetadata ? objectMetadata["USERSTATUS_TXT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.USERSTATUS_TXT, context);
                },
                set: function(val) {
                    setterFunctions['USERSTATUS_TXT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "USER_ST": {
                get: function() {
                    context["field"] = "USER_ST";
                    context["metadata"] = (objectMetadata ? objectMetadata["USER_ST"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.USER_ST, context);
                },
                set: function(val) {
                    setterFunctions['USER_ST'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "USER_STATUS": {
                get: function() {
                    context["field"] = "USER_STATUS";
                    context["metadata"] = (objectMetadata ? objectMetadata["USER_STATUS"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.USER_STATUS, context);
                },
                set: function(val) {
                    setterFunctions['USER_STATUS'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "WBS_ELEMENT": {
                get: function() {
                    context["field"] = "WBS_ELEMENT";
                    context["metadata"] = (objectMetadata ? objectMetadata["WBS_ELEMENT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.WBS_ELEMENT, context);
                },
                set: function(val) {
                    setterFunctions['WBS_ELEMENT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "WC_SHORT_DESC": {
                get: function() {
                    context["field"] = "WC_SHORT_DESC";
                    context["metadata"] = (objectMetadata ? objectMetadata["WC_SHORT_DESC"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.WC_SHORT_DESC, context);
                },
                set: function(val) {
                    setterFunctions['WC_SHORT_DESC'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "WORK_CENTER": {
                get: function() {
                    context["field"] = "WORK_CENTER";
                    context["metadata"] = (objectMetadata ? objectMetadata["WORK_CENTER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.WORK_CENTER, context);
                },
                set: function(val) {
                    setterFunctions['WORK_CENTER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "WRRNTY_END_DT": {
                get: function() {
                    context["field"] = "WRRNTY_END_DT";
                    context["metadata"] = (objectMetadata ? objectMetadata["WRRNTY_END_DT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.WRRNTY_END_DT, context);
                },
                set: function(val) {
                    setterFunctions['WRRNTY_END_DT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "WRRNTY_START_DT": {
                get: function() {
                    context["field"] = "WRRNTY_START_DT";
                    context["metadata"] = (objectMetadata ? objectMetadata["WRRNTY_START_DT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.WRRNTY_START_DT, context);
                },
                set: function(val) {
                    setterFunctions['WRRNTY_START_DT'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.ABCINDIC = value ? (value["ABCINDIC"] ? value["ABCINDIC"] : null) : null;
            privateState.ACCEPTED = value ? (value["ACCEPTED"] ? value["ACCEPTED"] : null) : null;
            privateState.ADDR_NO_LOC = value ? (value["ADDR_NO_LOC"] ? value["ADDR_NO_LOC"] : null) : null;
            privateState.ADDR_NUMBER = value ? (value["ADDR_NUMBER"] ? value["ADDR_NUMBER"] : null) : null;
            privateState.ASSEMBLY = value ? (value["ASSEMBLY"] ? value["ASSEMBLY"] : null) : null;
            privateState.ASSEMBLY_EXT = value ? (value["ASSEMBLY_EXT"] ? value["ASSEMBLY_EXT"] : null) : null;
            privateState.ASSEMBLY_GUID = value ? (value["ASSEMBLY_GUID"] ? value["ASSEMBLY_GUID"] : null) : null;
            privateState.ASSEMBLY_VERSION = value ? (value["ASSEMBLY_VERSION"] ? value["ASSEMBLY_VERSION"] : null) : null;
            privateState.ASSET_NO = value ? (value["ASSET_NO"] ? value["ASSET_NO"] : null) : null;
            privateState.BREAKDOWN = value ? (value["BREAKDOWN"] ? value["BREAKDOWN"] : null) : null;
            privateState.BUS_AREA = value ? (value["BUS_AREA"] ? value["BUS_AREA"] : null) : null;
            privateState.CATALOG_PROFILE = value ? (value["CATALOG_PROFILE"] ? value["CATALOG_PROFILE"] : null) : null;
            privateState.CAT_TYPE = value ? (value["CAT_TYPE"] ? value["CAT_TYPE"] : null) : null;
            privateState.CAUSE_CODE = value ? (value["CAUSE_CODE"] ? value["CAUSE_CODE"] : null) : null;
            privateState.CHANGED_AT = value ? (value["CHANGED_AT"] ? value["CHANGED_AT"] : null) : null;
            privateState.CHANGED_BY = value ? (value["CHANGED_BY"] ? value["CHANGED_BY"] : null) : null;
            privateState.CHANGED_ON = value ? (value["CHANGED_ON"] ? value["CHANGED_ON"] : null) : null;
            privateState.CODE_GRP_CAUSE = value ? (value["CODE_GRP_CAUSE"] ? value["CODE_GRP_CAUSE"] : null) : null;
            privateState.CODE_GRP_CODING = value ? (value["CODE_GRP_CODING"] ? value["CODE_GRP_CODING"] : null) : null;
            privateState.CODE_GRP_PART = value ? (value["CODE_GRP_PART"] ? value["CODE_GRP_PART"] : null) : null;
            privateState.CODE_GRP_PROBLEM = value ? (value["CODE_GRP_PROBLEM"] ? value["CODE_GRP_PROBLEM"] : null) : null;
            privateState.CODING_CODE = value ? (value["CODING_CODE"] ? value["CODING_CODE"] : null) : null;
            privateState.COMPTIME = value ? (value["COMPTIME"] ? value["COMPTIME"] : null) : null;
            privateState.COMP_CODE = value ? (value["COMP_CODE"] ? value["COMP_CODE"] : null) : null;
            privateState.CONVERT_TO_WO = value ? (value["CONVERT_TO_WO"] ? value["CONVERT_TO_WO"] : null) : null;
            privateState.COSTCENTER = value ? (value["COSTCENTER"] ? value["COSTCENTER"] : null) : null;
            privateState.CO_AREA = value ? (value["CO_AREA"] ? value["CO_AREA"] : null) : null;
            privateState.CREATED_AT = value ? (value["CREATED_AT"] ? value["CREATED_AT"] : null) : null;
            privateState.CREATED_BY = value ? (value["CREATED_BY"] ? value["CREATED_BY"] : null) : null;
            privateState.CREATED_ON = value ? (value["CREATED_ON"] ? value["CREATED_ON"] : null) : null;
            privateState.CUST_NO = value ? (value["CUST_NO"] ? value["CUST_NO"] : null) : null;
            privateState.DELETE_FLAG = value ? (value["DELETE_FLAG"] ? value["DELETE_FLAG"] : null) : null;
            privateState.DELETE_IND = value ? (value["DELETE_IND"] ? value["DELETE_IND"] : null) : null;
            privateState.DESENDDATE = value ? (value["DESENDDATE"] ? value["DESENDDATE"] : null) : null;
            privateState.DESENDTM = value ? (value["DESENDTM"] ? value["DESENDTM"] : null) : null;
            privateState.DESEN_DATE_TIME = value ? (value["DESEN_DATE_TIME"] ? value["DESEN_DATE_TIME"] : null) : null;
            privateState.DESSTDATE = value ? (value["DESSTDATE"] ? value["DESSTDATE"] : null) : null;
            privateState.DESSTTIME = value ? (value["DESSTTIME"] ? value["DESSTTIME"] : null) : null;
            privateState.DESST_DATE_TIME = value ? (value["DESST_DATE_TIME"] ? value["DESST_DATE_TIME"] : null) : null;
            privateState.DEVICEDATA = value ? (value["DEVICEDATA"] ? value["DEVICEDATA"] : null) : null;
            privateState.DISTR_CHAN = value ? (value["DISTR_CHAN"] ? value["DISTR_CHAN"] : null) : null;
            privateState.DIST_CHAN_LOC = value ? (value["DIST_CHAN_LOC"] ? value["DIST_CHAN_LOC"] : null) : null;
            privateState.DIVISION = value ? (value["DIVISION"] ? value["DIVISION"] : null) : null;
            privateState.DIVISION_LOC = value ? (value["DIVISION_LOC"] ? value["DIVISION_LOC"] : null) : null;
            privateState.DOC_NUMBER = value ? (value["DOC_NUMBER"] ? value["DOC_NUMBER"] : null) : null;
            privateState.DOWNTIME = value ? (value["DOWNTIME"] ? value["DOWNTIME"] : null) : null;
            privateState.ENDMLFNDATE = value ? (value["ENDMLFNDATE"] ? value["ENDMLFNDATE"] : null) : null;
            privateState.ENDMLFNTIME = value ? (value["ENDMLFNTIME"] ? value["ENDMLFNTIME"] : null) : null;
            privateState.ENDML_DATE_TIME = value ? (value["ENDML_DATE_TIME"] ? value["ENDML_DATE_TIME"] : null) : null;
            privateState.END_POINT = value ? (value["END_POINT"] ? value["END_POINT"] : null) : null;
            privateState.EQUIP_NUM = value ? (value["EQUIP_NUM"] ? value["EQUIP_NUM"] : null) : null;
            privateState.FLOCN_DESC = value ? (value["FLOCN_DESC"] ? value["FLOCN_DESC"] : null) : null;
            privateState.FUNC_LOCATION = value ? (value["FUNC_LOCATION"] ? value["FUNC_LOCATION"] : null) : null;
            privateState.INTERNAL_NUMBER = value ? (value["INTERNAL_NUMBER"] ? value["INTERNAL_NUMBER"] : null) : null;
            privateState.ISOCODE_UNIT = value ? (value["ISOCODE_UNIT"] ? value["ISOCODE_UNIT"] : null) : null;
            privateState.ITM_NUMBER = value ? (value["ITM_NUMBER"] ? value["ITM_NUMBER"] : null) : null;
            privateState.LINEAR_LENGTH = value ? (value["LINEAR_LENGTH"] ? value["LINEAR_LENGTH"] : null) : null;
            privateState.LINEAR_UNIT = value ? (value["LINEAR_UNIT"] ? value["LINEAR_UNIT"] : null) : null;
            privateState.LOC_ACC = value ? (value["LOC_ACC"] ? value["LOC_ACC"] : null) : null;
            privateState.LONG_TEXT = value ? (value["LONG_TEXT"] ? value["LONG_TEXT"] : null) : null;
            privateState.LRPID = value ? (value["LRPID"] ? value["LRPID"] : null) : null;
            privateState.LTEXT = value ? (value["LTEXT"] ? value["LTEXT"] : null) : null;
            privateState.MAINTITEM = value ? (value["MAINTITEM"] ? value["MAINTITEM"] : null) : null;
            privateState.MAINTLOC = value ? (value["MAINTLOC"] ? value["MAINTLOC"] : null) : null;
            privateState.MAINTPLANT = value ? (value["MAINTPLANT"] ? value["MAINTPLANT"] : null) : null;
            privateState.MAINTROOM = value ? (value["MAINTROOM"] ? value["MAINTROOM"] : null) : null;
            privateState.MANU_WRRNTY_ENDT = value ? (value["MANU_WRRNTY_ENDT"] ? value["MANU_WRRNTY_ENDT"] : null) : null;
            privateState.MANU_WRRNTY_STDT = value ? (value["MANU_WRRNTY_STDT"] ? value["MANU_WRRNTY_STDT"] : null) : null;
            privateState.MARKER_DIST_END = value ? (value["MARKER_DIST_END"] ? value["MARKER_DIST_END"] : null) : null;
            privateState.MARKER_DIST_STA = value ? (value["MARKER_DIST_STA"] ? value["MARKER_DIST_STA"] : null) : null;
            privateState.MARKER_DIST_UNIT = value ? (value["MARKER_DIST_UNIT"] ? value["MARKER_DIST_UNIT"] : null) : null;
            privateState.MARKER_END = value ? (value["MARKER_END"] ? value["MARKER_END"] : null) : null;
            privateState.MARKER_START = value ? (value["MARKER_START"] ? value["MARKER_START"] : null) : null;
            privateState.MASTER_WRRNTY_NO = value ? (value["MASTER_WRRNTY_NO"] ? value["MASTER_WRRNTY_NO"] : null) : null;
            privateState.MATERIAL = value ? (value["MATERIAL"] ? value["MATERIAL"] : null) : null;
            privateState.MATERIAL_EXT = value ? (value["MATERIAL_EXT"] ? value["MATERIAL_EXT"] : null) : null;
            privateState.MATERIAL_GUID = value ? (value["MATERIAL_GUID"] ? value["MATERIAL_GUID"] : null) : null;
            privateState.MATERIAL_VERSION = value ? (value["MATERIAL_VERSION"] ? value["MATERIAL_VERSION"] : null) : null;
            privateState.MNTCALL_NO = value ? (value["MNTCALL_NO"] ? value["MNTCALL_NO"] : null) : null;
            privateState.MNTPLAN = value ? (value["MNTPLAN"] ? value["MNTPLAN"] : null) : null;
            privateState.NOTF_REP_PER_NAM = value ? (value["NOTF_REP_PER_NAM"] ? value["NOTF_REP_PER_NAM"] : null) : null;
            privateState.NOTIFTMEZ = value ? (value["NOTIFTMEZ"] ? value["NOTIFTMEZ"] : null) : null;
            privateState.NOTIF_DATE = value ? (value["NOTIF_DATE"] ? value["NOTIF_DATE"] : null) : null;
            privateState.NOTIF_DATE_TIME = value ? (value["NOTIF_DATE_TIME"] ? value["NOTIF_DATE_TIME"] : null) : null;
            privateState.NOTIF_NUM = value ? (value["NOTIF_NUM"] ? value["NOTIF_NUM"] : null) : null;
            privateState.NOTIF_TIME = value ? (value["NOTIF_TIME"] ? value["NOTIF_TIME"] : null) : null;
            privateState.NOTIF_TYPE = value ? (value["NOTIF_TYPE"] ? value["NOTIF_TYPE"] : null) : null;
            privateState.OBJECT_NO = value ? (value["OBJECT_NO"] ? value["OBJECT_NO"] : null) : null;
            privateState.OFFSET1_TYPE = value ? (value["OFFSET1_TYPE"] ? value["OFFSET1_TYPE"] : null) : null;
            privateState.OFFSET1_UNIT = value ? (value["OFFSET1_UNIT"] ? value["OFFSET1_UNIT"] : null) : null;
            privateState.OFFSET1_VALUE = value ? (value["OFFSET1_VALUE"] ? value["OFFSET1_VALUE"] : null) : null;
            privateState.OFFSET2_TYPE = value ? (value["OFFSET2_TYPE"] ? value["OFFSET2_TYPE"] : null) : null;
            privateState.OFFSET2_UNIT = value ? (value["OFFSET2_UNIT"] ? value["OFFSET2_UNIT"] : null) : null;
            privateState.OFFSET2_VALUE = value ? (value["OFFSET2_VALUE"] ? value["OFFSET2_VALUE"] : null) : null;
            privateState.OPMODE = value ? (value["OPMODE"] ? value["OPMODE"] : null) : null;
            privateState.ORDER_NUM = value ? (value["ORDER_NUM"] ? value["ORDER_NUM"] : null) : null;
            privateState.ORDER_TEXT = value ? (value["ORDER_TEXT"] ? value["ORDER_TEXT"] : null) : null;
            privateState.ORDER_TYPE = value ? (value["ORDER_TYPE"] ? value["ORDER_TYPE"] : null) : null;
            privateState.PART_OBJECT = value ? (value["PART_OBJECT"] ? value["PART_OBJECT"] : null) : null;
            privateState.PLANGROUP = value ? (value["PLANGROUP"] ? value["PLANGROUP"] : null) : null;
            privateState.PLANPLANT = value ? (value["PLANPLANT"] ? value["PLANPLANT"] : null) : null;
            privateState.PLSECTN = value ? (value["PLSECTN"] ? value["PLSECTN"] : null) : null;
            privateState.PM_WKCTR = value ? (value["PM_WKCTR"] ? value["PM_WKCTR"] : null) : null;
            privateState.PP_WKCTR = value ? (value["PP_WKCTR"] ? value["PP_WKCTR"] : null) : null;
            privateState.PRILANG = value ? (value["PRILANG"] ? value["PRILANG"] : null) : null;
            privateState.PRIORITY = value ? (value["PRIORITY"] ? value["PRIORITY"] : null) : null;
            privateState.PRIORITY_TYPE = value ? (value["PRIORITY_TYPE"] ? value["PRIORITY_TYPE"] : null) : null;
            privateState.PROBLEM = value ? (value["PROBLEM"] ? value["PROBLEM"] : null) : null;
            privateState.PROBLEM_TEXT = value ? (value["PROBLEM_TEXT"] ? value["PROBLEM_TEXT"] : null) : null;
            privateState.PURCH_DATE = value ? (value["PURCH_DATE"] ? value["PURCH_DATE"] : null) : null;
            privateState.PURCH_NO_C = value ? (value["PURCH_NO_C"] ? value["PURCH_NO_C"] : null) : null;
            privateState.REFDATE = value ? (value["REFDATE"] ? value["REFDATE"] : null) : null;
            privateState.REFTIME = value ? (value["REFTIME"] ? value["REFTIME"] : null) : null;
            privateState.REF_DATE_TIME = value ? (value["REF_DATE_TIME"] ? value["REF_DATE_TIME"] : null) : null;
            privateState.REJECTED = value ? (value["REJECTED"] ? value["REJECTED"] : null) : null;
            privateState.SALES_GRP = value ? (value["SALES_GRP"] ? value["SALES_GRP"] : null) : null;
            privateState.SALES_OFFICE = value ? (value["SALES_OFFICE"] ? value["SALES_OFFICE"] : null) : null;
            privateState.SALES_ORD = value ? (value["SALES_ORD"] ? value["SALES_ORD"] : null) : null;
            privateState.SALES_ORG = value ? (value["SALES_ORG"] ? value["SALES_ORG"] : null) : null;
            privateState.SALES_ORG_LOC = value ? (value["SALES_ORG_LOC"] ? value["SALES_ORG_LOC"] : null) : null;
            privateState.SCENARIO = value ? (value["SCENARIO"] ? value["SCENARIO"] : null) : null;
            privateState.SERIALNO = value ? (value["SERIALNO"] ? value["SERIALNO"] : null) : null;
            privateState.SERVER_GROUP = value ? (value["SERVER_GROUP"] ? value["SERVER_GROUP"] : null) : null;
            privateState.SERVER_ID = value ? (value["SERVER_ID"] ? value["SERVER_ID"] : null) : null;
            privateState.SHORT_TEXT = value ? (value["SHORT_TEXT"] ? value["SHORT_TEXT"] : null) : null;
            privateState.SORTFIELD = value ? (value["SORTFIELD"] ? value["SORTFIELD"] : null) : null;
            privateState.START_POINT = value ? (value["START_POINT"] ? value["START_POINT"] : null) : null;
            privateState.STAT_PROF = value ? (value["STAT_PROF"] ? value["STAT_PROF"] : null) : null;
            privateState.STDGORD = value ? (value["STDGORD"] ? value["STDGORD"] : null) : null;
            privateState.STLMTORDER = value ? (value["STLMTORDER"] ? value["STLMTORDER"] : null) : null;
            privateState.STRMLFNDATE = value ? (value["STRMLFNDATE"] ? value["STRMLFNDATE"] : null) : null;
            privateState.STRMLFNTIME = value ? (value["STRMLFNTIME"] ? value["STRMLFNTIME"] : null) : null;
            privateState.STRML_DATE_TIME = value ? (value["STRML_DATE_TIME"] ? value["STRML_DATE_TIME"] : null) : null;
            privateState.SUB_NUMBER = value ? (value["SUB_NUMBER"] ? value["SUB_NUMBER"] : null) : null;
            privateState.SYS_STATUS = value ? (value["SYS_STATUS"] ? value["SYS_STATUS"] : null) : null;
            privateState.TECH_OBJ_DESC = value ? (value["TECH_OBJ_DESC"] ? value["TECH_OBJ_DESC"] : null) : null;
            privateState.TEXT_LENGTH = value ? (value["TEXT_LENGTH"] ? value["TEXT_LENGTH"] : null) : null;
            privateState.TIMESTAMP = value ? (value["TIMESTAMP"] ? value["TIMESTAMP"] : null) : null;
            privateState.TIME_ZONE = value ? (value["TIME_ZONE"] ? value["TIME_ZONE"] : null) : null;
            privateState.UNIT = value ? (value["UNIT"] ? value["UNIT"] : null) : null;
            privateState.USERID = value ? (value["USERID"] ? value["USERID"] : null) : null;
            privateState.USERSTATUS_TXT = value ? (value["USERSTATUS_TXT"] ? value["USERSTATUS_TXT"] : null) : null;
            privateState.USER_ST = value ? (value["USER_ST"] ? value["USER_ST"] : null) : null;
            privateState.USER_STATUS = value ? (value["USER_STATUS"] ? value["USER_STATUS"] : null) : null;
            privateState.WBS_ELEMENT = value ? (value["WBS_ELEMENT"] ? value["WBS_ELEMENT"] : null) : null;
            privateState.WC_SHORT_DESC = value ? (value["WC_SHORT_DESC"] ? value["WC_SHORT_DESC"] : null) : null;
            privateState.WORK_CENTER = value ? (value["WORK_CENTER"] ? value["WORK_CENTER"] : null) : null;
            privateState.WRRNTY_END_DT = value ? (value["WRRNTY_END_DT"] ? value["WRRNTY_END_DT"] : null) : null;
            privateState.WRRNTY_START_DT = value ? (value["WRRNTY_START_DT"] ? value["WRRNTY_START_DT"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(EAM_NOTIF);
    //Create new class level validator object
    BaseModel.Validator.call(EAM_NOTIF);
    var registerValidatorBackup = EAM_NOTIF.registerValidator;
    EAM_NOTIF.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (EAM_NOTIF.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    EAM_NOTIF.relations = relations;
    EAM_NOTIF.prototype.isValid = function() {
        return EAM_NOTIF.isValid(this);
    };
    EAM_NOTIF.prototype.objModelName = "EAM_NOTIF";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    EAM_NOTIF.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("sapobj", "EAM_NOTIF", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    EAM_NOTIF.clone = function(objectToClone) {
        var clonedObj = new EAM_NOTIF();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return EAM_NOTIF;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_NOTIFICATION_ADDRESS/MF_Config',[], function() {
    var mappings = {
        "ADDRESS_ID": "ADDRESS_ID",
        "ADDR_TYPE": "ADDR_TYPE",
        "ADDR_TYPE_ID": "ADDR_TYPE_ID",
        "CONT_SEQUENCE": "CONT_SEQUENCE",
        "COUNTER": "COUNTER",
        "DELETE_IND": "DELETE_IND",
        "DOC_NUM": "DOC_NUM",
        "OPMODE": "OPMODE",
        "PARTNER_TYPE": "PARTNER_TYPE",
        "PRIM_SEC_FLAG": "PRIM_SEC_FLAG",
        "TIMESTAMP": "TIMESTAMP",
    };
    Object.freeze(mappings);
    var typings = {
        "ADDRESS_ID": "string",
        "ADDR_TYPE": "string",
        "ADDR_TYPE_ID": "string",
        "CONT_SEQUENCE": "string",
        "COUNTER": "string",
        "DELETE_IND": "string",
        "DOC_NUM": "string",
        "OPMODE": "string",
        "PARTNER_TYPE": "string",
        "PRIM_SEC_FLAG": "string",
        "TIMESTAMP": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["ADDR_TYPE", "ADDR_TYPE_ID", "DOC_NUM", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "sapobj",
        tableName: "EAM_NOTIFICATION_ADDRESS"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_NOTIFICATION_ADDRESS/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "EAM_NOTIFICATION_ADDRESS",
        "objectService": "sapobj"
    };
    var setterFunctions = {
        ADDRESS_ID: function(val, state) {
            context["field"] = "ADDRESS_ID";
            context["metadata"] = (objectMetadata ? objectMetadata["ADDRESS_ID"] : null);
            state['ADDRESS_ID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ADDR_TYPE: function(val, state) {
            context["field"] = "ADDR_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["ADDR_TYPE"] : null);
            state['ADDR_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        ADDR_TYPE_ID: function(val, state) {
            context["field"] = "ADDR_TYPE_ID";
            context["metadata"] = (objectMetadata ? objectMetadata["ADDR_TYPE_ID"] : null);
            state['ADDR_TYPE_ID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        CONT_SEQUENCE: function(val, state) {
            context["field"] = "CONT_SEQUENCE";
            context["metadata"] = (objectMetadata ? objectMetadata["CONT_SEQUENCE"] : null);
            state['CONT_SEQUENCE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        COUNTER: function(val, state) {
            context["field"] = "COUNTER";
            context["metadata"] = (objectMetadata ? objectMetadata["COUNTER"] : null);
            state['COUNTER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DELETE_IND: function(val, state) {
            context["field"] = "DELETE_IND";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
            state['DELETE_IND'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DOC_NUM: function(val, state) {
            context["field"] = "DOC_NUM";
            context["metadata"] = (objectMetadata ? objectMetadata["DOC_NUM"] : null);
            state['DOC_NUM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OPMODE: function(val, state) {
            context["field"] = "OPMODE";
            context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
            state['OPMODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PARTNER_TYPE: function(val, state) {
            context["field"] = "PARTNER_TYPE";
            context["metadata"] = (objectMetadata ? objectMetadata["PARTNER_TYPE"] : null);
            state['PARTNER_TYPE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PRIM_SEC_FLAG: function(val, state) {
            context["field"] = "PRIM_SEC_FLAG";
            context["metadata"] = (objectMetadata ? objectMetadata["PRIM_SEC_FLAG"] : null);
            state['PRIM_SEC_FLAG'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TIMESTAMP: function(val, state) {
            context["field"] = "TIMESTAMP";
            context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
            state['TIMESTAMP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function EAM_NOTIFICATION_ADDRESS(defaultValues) {
        var privateState = {};
        context["field"] = "ADDRESS_ID";
        context["metadata"] = (objectMetadata ? objectMetadata["ADDRESS_ID"] : null);
        privateState.ADDRESS_ID = defaultValues ? (defaultValues["ADDRESS_ID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ADDRESS_ID"], context) : null) : null;
        context["field"] = "ADDR_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["ADDR_TYPE"] : null);
        privateState.ADDR_TYPE = defaultValues ? (defaultValues["ADDR_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ADDR_TYPE"], context) : null) : null;
        context["field"] = "ADDR_TYPE_ID";
        context["metadata"] = (objectMetadata ? objectMetadata["ADDR_TYPE_ID"] : null);
        privateState.ADDR_TYPE_ID = defaultValues ? (defaultValues["ADDR_TYPE_ID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["ADDR_TYPE_ID"], context) : null) : null;
        context["field"] = "CONT_SEQUENCE";
        context["metadata"] = (objectMetadata ? objectMetadata["CONT_SEQUENCE"] : null);
        privateState.CONT_SEQUENCE = defaultValues ? (defaultValues["CONT_SEQUENCE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["CONT_SEQUENCE"], context) : null) : null;
        context["field"] = "COUNTER";
        context["metadata"] = (objectMetadata ? objectMetadata["COUNTER"] : null);
        privateState.COUNTER = defaultValues ? (defaultValues["COUNTER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["COUNTER"], context) : null) : null;
        context["field"] = "DELETE_IND";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
        privateState.DELETE_IND = defaultValues ? (defaultValues["DELETE_IND"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETE_IND"], context) : null) : null;
        context["field"] = "DOC_NUM";
        context["metadata"] = (objectMetadata ? objectMetadata["DOC_NUM"] : null);
        privateState.DOC_NUM = defaultValues ? (defaultValues["DOC_NUM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DOC_NUM"], context) : null) : null;
        context["field"] = "OPMODE";
        context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
        privateState.OPMODE = defaultValues ? (defaultValues["OPMODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OPMODE"], context) : null) : null;
        context["field"] = "PARTNER_TYPE";
        context["metadata"] = (objectMetadata ? objectMetadata["PARTNER_TYPE"] : null);
        privateState.PARTNER_TYPE = defaultValues ? (defaultValues["PARTNER_TYPE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PARTNER_TYPE"], context) : null) : null;
        context["field"] = "PRIM_SEC_FLAG";
        context["metadata"] = (objectMetadata ? objectMetadata["PRIM_SEC_FLAG"] : null);
        privateState.PRIM_SEC_FLAG = defaultValues ? (defaultValues["PRIM_SEC_FLAG"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PRIM_SEC_FLAG"], context) : null) : null;
        context["field"] = "TIMESTAMP";
        context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
        privateState.TIMESTAMP = defaultValues ? (defaultValues["TIMESTAMP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TIMESTAMP"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "ADDRESS_ID": {
                get: function() {
                    context["field"] = "ADDRESS_ID";
                    context["metadata"] = (objectMetadata ? objectMetadata["ADDRESS_ID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ADDRESS_ID, context);
                },
                set: function(val) {
                    setterFunctions['ADDRESS_ID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ADDR_TYPE": {
                get: function() {
                    context["field"] = "ADDR_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["ADDR_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ADDR_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['ADDR_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "ADDR_TYPE_ID": {
                get: function() {
                    context["field"] = "ADDR_TYPE_ID";
                    context["metadata"] = (objectMetadata ? objectMetadata["ADDR_TYPE_ID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.ADDR_TYPE_ID, context);
                },
                set: function(val) {
                    setterFunctions['ADDR_TYPE_ID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "CONT_SEQUENCE": {
                get: function() {
                    context["field"] = "CONT_SEQUENCE";
                    context["metadata"] = (objectMetadata ? objectMetadata["CONT_SEQUENCE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.CONT_SEQUENCE, context);
                },
                set: function(val) {
                    setterFunctions['CONT_SEQUENCE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "COUNTER": {
                get: function() {
                    context["field"] = "COUNTER";
                    context["metadata"] = (objectMetadata ? objectMetadata["COUNTER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.COUNTER, context);
                },
                set: function(val) {
                    setterFunctions['COUNTER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DELETE_IND": {
                get: function() {
                    context["field"] = "DELETE_IND";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETE_IND, context);
                },
                set: function(val) {
                    setterFunctions['DELETE_IND'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DOC_NUM": {
                get: function() {
                    context["field"] = "DOC_NUM";
                    context["metadata"] = (objectMetadata ? objectMetadata["DOC_NUM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DOC_NUM, context);
                },
                set: function(val) {
                    setterFunctions['DOC_NUM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OPMODE": {
                get: function() {
                    context["field"] = "OPMODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OPMODE, context);
                },
                set: function(val) {
                    setterFunctions['OPMODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PARTNER_TYPE": {
                get: function() {
                    context["field"] = "PARTNER_TYPE";
                    context["metadata"] = (objectMetadata ? objectMetadata["PARTNER_TYPE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PARTNER_TYPE, context);
                },
                set: function(val) {
                    setterFunctions['PARTNER_TYPE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PRIM_SEC_FLAG": {
                get: function() {
                    context["field"] = "PRIM_SEC_FLAG";
                    context["metadata"] = (objectMetadata ? objectMetadata["PRIM_SEC_FLAG"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PRIM_SEC_FLAG, context);
                },
                set: function(val) {
                    setterFunctions['PRIM_SEC_FLAG'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TIMESTAMP": {
                get: function() {
                    context["field"] = "TIMESTAMP";
                    context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TIMESTAMP, context);
                },
                set: function(val) {
                    setterFunctions['TIMESTAMP'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.ADDRESS_ID = value ? (value["ADDRESS_ID"] ? value["ADDRESS_ID"] : null) : null;
            privateState.ADDR_TYPE = value ? (value["ADDR_TYPE"] ? value["ADDR_TYPE"] : null) : null;
            privateState.ADDR_TYPE_ID = value ? (value["ADDR_TYPE_ID"] ? value["ADDR_TYPE_ID"] : null) : null;
            privateState.CONT_SEQUENCE = value ? (value["CONT_SEQUENCE"] ? value["CONT_SEQUENCE"] : null) : null;
            privateState.COUNTER = value ? (value["COUNTER"] ? value["COUNTER"] : null) : null;
            privateState.DELETE_IND = value ? (value["DELETE_IND"] ? value["DELETE_IND"] : null) : null;
            privateState.DOC_NUM = value ? (value["DOC_NUM"] ? value["DOC_NUM"] : null) : null;
            privateState.OPMODE = value ? (value["OPMODE"] ? value["OPMODE"] : null) : null;
            privateState.PARTNER_TYPE = value ? (value["PARTNER_TYPE"] ? value["PARTNER_TYPE"] : null) : null;
            privateState.PRIM_SEC_FLAG = value ? (value["PRIM_SEC_FLAG"] ? value["PRIM_SEC_FLAG"] : null) : null;
            privateState.TIMESTAMP = value ? (value["TIMESTAMP"] ? value["TIMESTAMP"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(EAM_NOTIFICATION_ADDRESS);
    //Create new class level validator object
    BaseModel.Validator.call(EAM_NOTIFICATION_ADDRESS);
    var registerValidatorBackup = EAM_NOTIFICATION_ADDRESS.registerValidator;
    EAM_NOTIFICATION_ADDRESS.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (EAM_NOTIFICATION_ADDRESS.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    EAM_NOTIFICATION_ADDRESS.relations = relations;
    EAM_NOTIFICATION_ADDRESS.prototype.isValid = function() {
        return EAM_NOTIFICATION_ADDRESS.isValid(this);
    };
    EAM_NOTIFICATION_ADDRESS.prototype.objModelName = "EAM_NOTIFICATION_ADDRESS";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    EAM_NOTIFICATION_ADDRESS.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("sapobj", "EAM_NOTIFICATION_ADDRESS", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    EAM_NOTIFICATION_ADDRESS.clone = function(objectToClone) {
        var clonedObj = new EAM_NOTIFICATION_ADDRESS();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return EAM_NOTIFICATION_ADDRESS;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_NOTIF_DIST/MF_Config',[], function() {
    var mappings = {
        "DELETE_IND": "DELETE_IND",
        "DESSTDATE": "DESSTDATE",
        "DESSTTIME": "DESSTTIME",
        "DIST_KEY": "DIST_KEY",
        "INTERNAL_NUMBER": "INTERNAL_NUMBER",
        "NOTIF_NUM": "NOTIF_NUM",
        "OPMODE": "OPMODE",
        "PLANT": "PLANT",
        "REJECTED": "REJECTED",
        "STAT_PROF": "STAT_PROF",
        "TIMESTAMP": "TIMESTAMP",
        "USERID": "USERID",
        "USER_STATUS": "USER_STATUS",
        "WORK_CENTER": "WORK_CENTER",
    };
    Object.freeze(mappings);
    var typings = {
        "DELETE_IND": "string",
        "DESSTDATE": "string",
        "DESSTTIME": "string",
        "DIST_KEY": "string",
        "INTERNAL_NUMBER": "string",
        "NOTIF_NUM": "string",
        "OPMODE": "string",
        "PLANT": "string",
        "REJECTED": "string",
        "STAT_PROF": "string",
        "TIMESTAMP": "string",
        "USERID": "string",
        "USER_STATUS": "string",
        "WORK_CENTER": "string",
    }
    Object.freeze(typings);
    var primaryKeys = ["DIST_KEY", ];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "sapobj",
        tableName: "EAM_NOTIF_DIST"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/EAM_NOTIF_DIST/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "EAM_NOTIF_DIST",
        "objectService": "sapobj"
    };
    var setterFunctions = {
        DELETE_IND: function(val, state) {
            context["field"] = "DELETE_IND";
            context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
            state['DELETE_IND'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESSTDATE: function(val, state) {
            context["field"] = "DESSTDATE";
            context["metadata"] = (objectMetadata ? objectMetadata["DESSTDATE"] : null);
            state['DESSTDATE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DESSTTIME: function(val, state) {
            context["field"] = "DESSTTIME";
            context["metadata"] = (objectMetadata ? objectMetadata["DESSTTIME"] : null);
            state['DESSTTIME'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        DIST_KEY: function(val, state) {
            context["field"] = "DIST_KEY";
            context["metadata"] = (objectMetadata ? objectMetadata["DIST_KEY"] : null);
            state['DIST_KEY'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        INTERNAL_NUMBER: function(val, state) {
            context["field"] = "INTERNAL_NUMBER";
            context["metadata"] = (objectMetadata ? objectMetadata["INTERNAL_NUMBER"] : null);
            state['INTERNAL_NUMBER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        NOTIF_NUM: function(val, state) {
            context["field"] = "NOTIF_NUM";
            context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_NUM"] : null);
            state['NOTIF_NUM'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        OPMODE: function(val, state) {
            context["field"] = "OPMODE";
            context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
            state['OPMODE'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        PLANT: function(val, state) {
            context["field"] = "PLANT";
            context["metadata"] = (objectMetadata ? objectMetadata["PLANT"] : null);
            state['PLANT'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        REJECTED: function(val, state) {
            context["field"] = "REJECTED";
            context["metadata"] = (objectMetadata ? objectMetadata["REJECTED"] : null);
            state['REJECTED'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        STAT_PROF: function(val, state) {
            context["field"] = "STAT_PROF";
            context["metadata"] = (objectMetadata ? objectMetadata["STAT_PROF"] : null);
            state['STAT_PROF'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        TIMESTAMP: function(val, state) {
            context["field"] = "TIMESTAMP";
            context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
            state['TIMESTAMP'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        USERID: function(val, state) {
            context["field"] = "USERID";
            context["metadata"] = (objectMetadata ? objectMetadata["USERID"] : null);
            state['USERID'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        USER_STATUS: function(val, state) {
            context["field"] = "USER_STATUS";
            context["metadata"] = (objectMetadata ? objectMetadata["USER_STATUS"] : null);
            state['USER_STATUS'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
        WORK_CENTER: function(val, state) {
            context["field"] = "WORK_CENTER";
            context["metadata"] = (objectMetadata ? objectMetadata["WORK_CENTER"] : null);
            state['WORK_CENTER'] = kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, val, context);
        },
    };
    //Create the Model Class
    function EAM_NOTIF_DIST(defaultValues) {
        var privateState = {};
        context["field"] = "DELETE_IND";
        context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
        privateState.DELETE_IND = defaultValues ? (defaultValues["DELETE_IND"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DELETE_IND"], context) : null) : null;
        context["field"] = "DESSTDATE";
        context["metadata"] = (objectMetadata ? objectMetadata["DESSTDATE"] : null);
        privateState.DESSTDATE = defaultValues ? (defaultValues["DESSTDATE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESSTDATE"], context) : null) : null;
        context["field"] = "DESSTTIME";
        context["metadata"] = (objectMetadata ? objectMetadata["DESSTTIME"] : null);
        privateState.DESSTTIME = defaultValues ? (defaultValues["DESSTTIME"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DESSTTIME"], context) : null) : null;
        context["field"] = "DIST_KEY";
        context["metadata"] = (objectMetadata ? objectMetadata["DIST_KEY"] : null);
        privateState.DIST_KEY = defaultValues ? (defaultValues["DIST_KEY"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["DIST_KEY"], context) : null) : null;
        context["field"] = "INTERNAL_NUMBER";
        context["metadata"] = (objectMetadata ? objectMetadata["INTERNAL_NUMBER"] : null);
        privateState.INTERNAL_NUMBER = defaultValues ? (defaultValues["INTERNAL_NUMBER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["INTERNAL_NUMBER"], context) : null) : null;
        context["field"] = "NOTIF_NUM";
        context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_NUM"] : null);
        privateState.NOTIF_NUM = defaultValues ? (defaultValues["NOTIF_NUM"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["NOTIF_NUM"], context) : null) : null;
        context["field"] = "OPMODE";
        context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
        privateState.OPMODE = defaultValues ? (defaultValues["OPMODE"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["OPMODE"], context) : null) : null;
        context["field"] = "PLANT";
        context["metadata"] = (objectMetadata ? objectMetadata["PLANT"] : null);
        privateState.PLANT = defaultValues ? (defaultValues["PLANT"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["PLANT"], context) : null) : null;
        context["field"] = "REJECTED";
        context["metadata"] = (objectMetadata ? objectMetadata["REJECTED"] : null);
        privateState.REJECTED = defaultValues ? (defaultValues["REJECTED"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["REJECTED"], context) : null) : null;
        context["field"] = "STAT_PROF";
        context["metadata"] = (objectMetadata ? objectMetadata["STAT_PROF"] : null);
        privateState.STAT_PROF = defaultValues ? (defaultValues["STAT_PROF"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["STAT_PROF"], context) : null) : null;
        context["field"] = "TIMESTAMP";
        context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
        privateState.TIMESTAMP = defaultValues ? (defaultValues["TIMESTAMP"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["TIMESTAMP"], context) : null) : null;
        context["field"] = "USERID";
        context["metadata"] = (objectMetadata ? objectMetadata["USERID"] : null);
        privateState.USERID = defaultValues ? (defaultValues["USERID"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["USERID"], context) : null) : null;
        context["field"] = "USER_STATUS";
        context["metadata"] = (objectMetadata ? objectMetadata["USER_STATUS"] : null);
        privateState.USER_STATUS = defaultValues ? (defaultValues["USER_STATUS"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["USER_STATUS"], context) : null) : null;
        context["field"] = "WORK_CENTER";
        context["metadata"] = (objectMetadata ? objectMetadata["WORK_CENTER"] : null);
        privateState.WORK_CENTER = defaultValues ? (defaultValues["WORK_CENTER"] ? kony.mvc.util.ProcessorUtils.applyFunction(preProcessorCallback, defaultValues["WORK_CENTER"], context) : null) : null;
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {
            "DELETE_IND": {
                get: function() {
                    context["field"] = "DELETE_IND";
                    context["metadata"] = (objectMetadata ? objectMetadata["DELETE_IND"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DELETE_IND, context);
                },
                set: function(val) {
                    setterFunctions['DELETE_IND'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESSTDATE": {
                get: function() {
                    context["field"] = "DESSTDATE";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESSTDATE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESSTDATE, context);
                },
                set: function(val) {
                    setterFunctions['DESSTDATE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DESSTTIME": {
                get: function() {
                    context["field"] = "DESSTTIME";
                    context["metadata"] = (objectMetadata ? objectMetadata["DESSTTIME"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DESSTTIME, context);
                },
                set: function(val) {
                    setterFunctions['DESSTTIME'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "DIST_KEY": {
                get: function() {
                    context["field"] = "DIST_KEY";
                    context["metadata"] = (objectMetadata ? objectMetadata["DIST_KEY"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.DIST_KEY, context);
                },
                set: function(val) {
                    setterFunctions['DIST_KEY'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "INTERNAL_NUMBER": {
                get: function() {
                    context["field"] = "INTERNAL_NUMBER";
                    context["metadata"] = (objectMetadata ? objectMetadata["INTERNAL_NUMBER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.INTERNAL_NUMBER, context);
                },
                set: function(val) {
                    setterFunctions['INTERNAL_NUMBER'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "NOTIF_NUM": {
                get: function() {
                    context["field"] = "NOTIF_NUM";
                    context["metadata"] = (objectMetadata ? objectMetadata["NOTIF_NUM"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.NOTIF_NUM, context);
                },
                set: function(val) {
                    setterFunctions['NOTIF_NUM'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "OPMODE": {
                get: function() {
                    context["field"] = "OPMODE";
                    context["metadata"] = (objectMetadata ? objectMetadata["OPMODE"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.OPMODE, context);
                },
                set: function(val) {
                    setterFunctions['OPMODE'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "PLANT": {
                get: function() {
                    context["field"] = "PLANT";
                    context["metadata"] = (objectMetadata ? objectMetadata["PLANT"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.PLANT, context);
                },
                set: function(val) {
                    setterFunctions['PLANT'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "REJECTED": {
                get: function() {
                    context["field"] = "REJECTED";
                    context["metadata"] = (objectMetadata ? objectMetadata["REJECTED"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.REJECTED, context);
                },
                set: function(val) {
                    setterFunctions['REJECTED'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "STAT_PROF": {
                get: function() {
                    context["field"] = "STAT_PROF";
                    context["metadata"] = (objectMetadata ? objectMetadata["STAT_PROF"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.STAT_PROF, context);
                },
                set: function(val) {
                    setterFunctions['STAT_PROF'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "TIMESTAMP": {
                get: function() {
                    context["field"] = "TIMESTAMP";
                    context["metadata"] = (objectMetadata ? objectMetadata["TIMESTAMP"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.TIMESTAMP, context);
                },
                set: function(val) {
                    setterFunctions['TIMESTAMP'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "USERID": {
                get: function() {
                    context["field"] = "USERID";
                    context["metadata"] = (objectMetadata ? objectMetadata["USERID"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.USERID, context);
                },
                set: function(val) {
                    setterFunctions['USERID'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "USER_STATUS": {
                get: function() {
                    context["field"] = "USER_STATUS";
                    context["metadata"] = (objectMetadata ? objectMetadata["USER_STATUS"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.USER_STATUS, context);
                },
                set: function(val) {
                    setterFunctions['USER_STATUS'].call(this, val, privateState);
                },
                enumerable: true,
            },
            "WORK_CENTER": {
                get: function() {
                    context["field"] = "WORK_CENTER";
                    context["metadata"] = (objectMetadata ? objectMetadata["WORK_CENTER"] : null);
                    return kony.mvc.util.ProcessorUtils.applyFunction(postProcessorCallback, privateState.WORK_CENTER, context);
                },
                set: function(val) {
                    setterFunctions['WORK_CENTER'].call(this, val, privateState);
                },
                enumerable: true,
            },
        });
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {
            privateState.DELETE_IND = value ? (value["DELETE_IND"] ? value["DELETE_IND"] : null) : null;
            privateState.DESSTDATE = value ? (value["DESSTDATE"] ? value["DESSTDATE"] : null) : null;
            privateState.DESSTTIME = value ? (value["DESSTTIME"] ? value["DESSTTIME"] : null) : null;
            privateState.DIST_KEY = value ? (value["DIST_KEY"] ? value["DIST_KEY"] : null) : null;
            privateState.INTERNAL_NUMBER = value ? (value["INTERNAL_NUMBER"] ? value["INTERNAL_NUMBER"] : null) : null;
            privateState.NOTIF_NUM = value ? (value["NOTIF_NUM"] ? value["NOTIF_NUM"] : null) : null;
            privateState.OPMODE = value ? (value["OPMODE"] ? value["OPMODE"] : null) : null;
            privateState.PLANT = value ? (value["PLANT"] ? value["PLANT"] : null) : null;
            privateState.REJECTED = value ? (value["REJECTED"] ? value["REJECTED"] : null) : null;
            privateState.STAT_PROF = value ? (value["STAT_PROF"] ? value["STAT_PROF"] : null) : null;
            privateState.TIMESTAMP = value ? (value["TIMESTAMP"] ? value["TIMESTAMP"] : null) : null;
            privateState.USERID = value ? (value["USERID"] ? value["USERID"] : null) : null;
            privateState.USER_STATUS = value ? (value["USER_STATUS"] ? value["USER_STATUS"] : null) : null;
            privateState.WORK_CENTER = value ? (value["WORK_CENTER"] ? value["WORK_CENTER"] : null) : null;
        };
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(EAM_NOTIF_DIST);
    //Create new class level validator object
    BaseModel.Validator.call(EAM_NOTIF_DIST);
    var registerValidatorBackup = EAM_NOTIF_DIST.registerValidator;
    EAM_NOTIF_DIST.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (EAM_NOTIF_DIST.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    EAM_NOTIF_DIST.relations = relations;
    EAM_NOTIF_DIST.prototype.isValid = function() {
        return EAM_NOTIF_DIST.isValid(this);
    };
    EAM_NOTIF_DIST.prototype.objModelName = "EAM_NOTIF_DIST";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    EAM_NOTIF_DIST.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("sapobj", "EAM_NOTIF_DIST", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    EAM_NOTIF_DIST.clone = function(objectToClone) {
        var clonedObj = new EAM_NOTIF_DIST();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return EAM_NOTIF_DIST;
});

/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/abc/MF_Config',[], function() {
    var mappings = {};
    Object.freeze(mappings);
    var typings = {}
    Object.freeze(typings);
    var primaryKeys = [];
    Object.freeze(primaryKeys);
    var config = {
        mappings: mappings,
        typings: typings,
        primaryKeys: primaryKeys,
        serviceName: "sapobj",
        tableName: "abc"
    };
    Object.freeze(config);
    return config;
})
;
/*
    This is an auto generated file and any modifications to it may result in corrupted data.
*/
define('sapobj/abc/Model',[], function() {
    var BaseModel = kony.mvc.Data.BaseModel;
    var preProcessorCallback;
    var postProcessorCallback;
    var objectMetadata;
    var context = {
        "object": "abc",
        "objectService": "sapobj"
    };
    var setterFunctions = {};
    //Create the Model Class
    function abc(defaultValues) {
        var privateState = {};
        //Using parent constructor to create other properties req. to kony sdk
        BaseModel.call(this);
        //Defining Getter/Setters
        Object.defineProperties(this, {});
        //converts model object to json object.
        this.toJsonInternal = function() {
            return Object.assign({}, privateState);
        };
        //overwrites object state with provided json value in argument.
        this.fromJsonInternal = function(value) {};
    }
    //Setting BaseModel as Parent to this Model
    BaseModel.isParentOf(abc);
    //Create new class level validator object
    BaseModel.Validator.call(abc);
    var registerValidatorBackup = abc.registerValidator;
    abc.registerValidator = function() {
            var propName = arguments[0];
            if (!setterFunctions[propName].changed) {
                var setterBackup = setterFunctions[propName];
                setterFunctions[arguments[0]] = function() {
                    if (abc.isValid(this, propName, val)) {
                        return setterBackup.apply(null, arguments);
                    } else {
                        throw Error("Validation failed for " + propName + " : " + val);
                    }
                }
                setterFunctions[arguments[0]].changed = true;
            }
            return registerValidatorBackup.apply(null, arguments);
        }
        //Extending Model for custom operations
    var relations = [];
    abc.relations = relations;
    abc.prototype.isValid = function() {
        return abc.isValid(this);
    };
    abc.prototype.objModelName = "abc";
    /*This API allows registration of preprocessors and postprocessors for model.
     *It also fetches object metadata for object.
     *Options Supported
     *preProcessor  - preprocessor function for use with setters.
     *postProcessor - post processor callback for use with getters.
     *getFromServer - value set to true will fetch metadata from network else from cache.
     */
    abc.registerProcessors = function(options, successCallback, failureCallback) {
        if (!options) {
            options = {};
        }
        if (options && ((options["preProcessor"] && typeof(options["preProcessor"]) === "function") || !options["preProcessor"])) {
            preProcessorCallback = options["preProcessor"];
        }
        if (options && ((options["postProcessor"] && typeof(options["postProcessor"]) === "function") || !options["postProcessor"])) {
            postProcessorCallback = options["postProcessor"];
        }

        function metaDataSuccess(res) {
            objectMetadata = kony.mvc.util.ProcessorUtils.convertObjectMetadataToFieldMetadataMap(res);
            successCallback();
        }

        function metaDataFailure(err) {
            failureCallback(err);
        }
        kony.mvc.util.ProcessorUtils.getMetadataForObject("sapobj", "abc", options, metaDataSuccess, metaDataFailure);
    };
    //clone the object provided in argument.
    abc.clone = function(objectToClone) {
        var clonedObj = new abc();
        clonedObj.fromJsonInternal(objectToClone.toJsonInternal());
        return clonedObj;
    };
    return abc;
});

require(['AsyncTestService/File/MF_Config','AsyncTestService/File/Model','AsyncTestService/File/Repository','BooleanConversionService/designations/MF_Config','BooleanConversionService/designations/Model','BooleanConversionService/employees/MF_Config','BooleanConversionService/employees/Model','ContactOS/binaryContact/MF_Config','ContactOS/binaryContact/Model','ContactOS/binaryContact/Repository','ContactOS/contact/MF_Config','ContactOS/contact/Model','EventOS/event/MF_Config','EventOS/event/Model','EventOS/event_speaker/MF_Config','EventOS/event_speaker/Model','EventOS/speaker/MF_Config','EventOS/speaker/Model','EventOS/venue/MF_Config','EventOS/venue/Model','RDBMSHierarchy/eventhierarchy/MF_Config','RDBMSHierarchy/eventhierarchy/Model','RDBMSHierarchy/venuehierarchy/MF_Config','RDBMSHierarchy/venuehierarchy/Model','RDBMSObjectService/media/MF_Config','RDBMSObjectService/media/Model','RDBMSObjectService/media/Repository','RDBMSObjectService/product/MF_Config','RDBMSObjectService/product/Model','RepoManagerConfig','S3ObjectSvc/getBinary/MF_Config','S3ObjectSvc/getBinary/Model','S3ObjectSvc/uploadBinary/MF_Config','S3ObjectSvc/uploadBinary/Model','SalesforceDB/Category/MF_Config','SalesforceDB/Category/Model','SalesforceDB/Category2/MF_Config','SalesforceDB/Category2/Model','StorageObjectService/binary/MF_Config','StorageObjectService/binary/Model','StorageObjectService/binary/Repository','boxObjectService/image/MF_Config','boxObjectService/image/Model','sapobj/EAM_ADDRESS/MF_Config','sapobj/EAM_ADDRESS/Model','sapobj/EAM_NOTIF/MF_Config','sapobj/EAM_NOTIF/Model','sapobj/EAM_NOTIFICATION_ADDRESS/MF_Config','sapobj/EAM_NOTIFICATION_ADDRESS/Model','sapobj/EAM_NOTIF_DIST/MF_Config','sapobj/EAM_NOTIF_DIST/Model','sapobj/abc/MF_Config','sapobj/abc/Model'], function(){});

define("sparequirefileslist", function(){});

